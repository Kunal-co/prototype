'use strict';
/**
 * server.js — entry point (Node.js 22.13+).
 * Starts Express, registers middleware and routes, wires the detection
 * pipeline together and shuts down cleanly. No detection logic lives here.
 *
 *   socket reads/writes (flow.js) -> flows -> features -> detector.js/predict.py
 *     (CNN + FCNN + LSTM + autoencoder + ADWIN) -> decision.js -> events.js -> db.js
 *
 * ML_DISABLED=true starts the app in capture-only mode: flows are still measured (and written to
 * CAPTURE_DATASET if set) but nothing is scored. Use it to collect training data.
 */
// Command-line switches (work on every OS, unlike VAR=x prefixes): --capture, --dataset=FILE, --label-map=ip=label,...
for (const a of process.argv.slice(2)) {
  if (a === '--capture') process.env.ML_DISABLED = 'true';
  const m = /^--(dataset|label-map)=(.+)$/.exec(a);
  if (m) process.env[m[1] === 'dataset' ? 'CAPTURE_DATASET' : 'CAPTURE_LABEL_MAP'] = m[2];
}
const path = require('node:path');
const express = require('express');

const logger = require('./logger');
const auth = require('./auth');
const flow = require('./flow');
const detector = require('./detector');
const { decide } = require('./decision');
const events = require('./events');
const behavior = require('./behavior');
const blocklist = require('./blocklist');
const drift = require('./drift');
const routes = require('./routes');
const db = require('./db');

const sysLog = logger.child('SYS');
const httpLog = logger.child('HTTP');
const mlLog = logger.child('ML');
const decideLog = logger.child('DECIDE');
const { short, fmtBytes } = logger;

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1'; // loopback by default; cloudflared connects locally
const ML_DISABLED = process.env.ML_DISABLED === 'true';
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

const app = express();
app.disable('x-powered-by');

/** One line per request: what came in, who sent it, what went out, how long it took. */
function requestLogger(req, res, next) {
  const t0 = process.hrtime.bigint();
  res.once('close', () => {
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    const who = req.ng && req.ng.username ? `user=${req.ng.username}` : 'anonymous';
    httpLog.info(`${req.method} ${req.originalUrl.split('?')[0]} -> ${res.statusCode} ${ms.toFixed(1)}ms `
      + `${fmtBytes(Number(res.getHeader('content-length')) || 0)} from ${req.ng ? req.ng.ip : req.socket.remoteAddress} `
      + `${who} session=${short(req.ng && req.ng.sessionId)}`);
  });
  next();
}

// Order matters: identify -> log -> capture -> restrict -> serve.
app.use(auth.middleware);
app.use(requestLogger);
app.use(flow.captureMiddleware);
app.use(blocklist.middleware);
app.use('/api', routes);
app.use(express.static(FRONTEND_DIR, { extensions: ['html'] }));

/* ------------------------------------------------- detection pipeline */

const inFlight = new Set();
const stat = (n) => (typeof n === 'number' ? n.toFixed(3) : '-');

async function processFlow(report) {
  const id = short(report.flowId);
  try {
    const raw = await detector.predict(report.vector, {
      allowMissing: true, observe: true,
      source: { ip: behavior.entityKey(report), flowId: report.flowId, startedMs: report.startedAtMs }, // per-USER (or anonymous-IP) history for the LSTM
    });
    mlLog.info(`flow ${id} scores: cnn=${stat(raw.models.cnn.probability)} fcnn=${stat(raw.models.fcnn.probability)} `
      + `lstm=${stat(raw.models.lstm.probability)}${raw.sequence && raw.sequence.mode === 'sequence' ? ` (last ${raw.sequence.window} flows of ${raw.sequence.ip})` : ''} | ensemble=${stat(raw.ensemble.probability)} (${raw.ensemble.votes}/3 vote attack, `
      + `spread ${stat(raw.ensemble.disagreement)}) | novelty ${stat(raw.novelty.score)} = x${raw.novelty.ratio} of threshold `
      + `${raw.novelty.flag ? '[UNUSUAL]' : '[ok]'} | imputed ${raw.meta.imputed_count} | ${raw.meta.inference_ms}ms`);

    drift.handle(raw.drift.events); // before deciding, so a fresh alert is reflected in this verdict
    const decision = decide(raw, { driftActive: drift.isActive() });
    const line = `flow ${id} -> ${decision.status.toUpperCase()} (${decision.severity}) confidence ${decision.confidence} | ${decision.reason}`;
    (decision.status === 'normal' ? decideLog.info : decideLog.warn)(line);

    const profile = behavior.observe(report, decision); // user-level status: one flow alone does not decide it
    events.recordDetection({ flow: report, decision, behavior: profile });
  } catch (err) {
    sysLog.error(`flow ${id} not scored: ${err.message}`);
  }
}

flow.events.on('flow', (report) => {
  if (ML_DISABLED) return;
  const p = processFlow(report).finally(() => inFlight.delete(p));
  inFlight.add(p);
});

// Session ended (logout / expiry): finalize that session's remaining flows now.
auth.events.on('session-end', ({ sessionId }) => flow.finalizeSession(sessionId, 'session_end'));

/* ------------------------------------------------------------ startup */

sysLog.info(`NetGuard-AI starting on Node ${process.version} (${process.platform}), pid ${process.pid}`);
auth.start();
flow.start();
if (ML_DISABLED) {
  sysLog.warn('ML_DISABLED=true: capture-only mode, flows are measured but NOT scored');
} else {
  detector.start()
    .then((info) => {
      mlLog.info(`models ready: ${Object.entries(info.models).map(([k, v]) => `${k}=${v}`).join(', ')}; ${info.feature_count} input features; `
        + `trained on ${info.trained_on} at ${info.trained_at}`);
      mlLog.info(`thresholds: ensemble ${info.thresholds.ensemble}, novelty ${info.thresholds.novelty}; drift detector ${info.drift.detector} (delta ${info.drift.delta})`);
      if (info.holdout && info.holdout.length) mlLog.info(`attack families withheld from training (zero-day test): ${info.holdout.join(', ')}`);
      for (const w of info.warnings || []) mlLog.warn(w);
    })
    .catch((err) => mlLog.error(`ML engine NOT ready: ${err.message}. Run "python3 ml/predict.py --inspect" to diagnose.`));
}

const server = app.listen(PORT, HOST, () => {
  const sch = flow.describeSchema();
  sysLog.info(`listening on http://${HOST}:${PORT}`);
  sysLog.info(`schema: ${sch.count} model features enabled; ${sch.unavailableLive} of them cannot be measured and would be filled with 0`);
});
// Runs before Node's HTTP layer so every socket read and write is measured (see flow.attachSocket).
server.prependListener('connection', flow.attachSocket);

/* ----------------------------------------------------------- shutdown */

let closing = false;
async function shutdown(signal) {
  if (closing) return;
  closing = true;
  sysLog.info(`[${signal}] shutting down...`);
  const force = setTimeout(() => process.exit(1), 10000);
  force.unref();
  server.close();
  server.closeAllConnections();   // sockets close -> their flows finalize
  auth.stop();
  flow.shutdown();                // finalize anything still open
  await Promise.allSettled([...inFlight]);
  detector.stop();
  db.close();
  sysLog.info('bye');
  process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
