'use strict';
/**
 * drift.js — what the server does when the ADWIN monitors (ml/drift.py) report a change.
 *
 * ADWIN itself runs inside the Python worker, next to the models, because it must see every
 * scored flow. This module receives the events it returns and:
 *   1. stores each one (drift_events table) so the history survives restarts,
 *   2. logs it,
 *   3. keeps a short "drift active" state; while it is on, every verdict carries a warning.
 *
 * It does NOT retrain or adapt the models by itself. Live traffic has no labels, and retraining
 * on unlabeled data would let an attacker steer the models. The alert tells a human to
 * collect fresh labelled flows (CAPTURE_DATASET) and run ml/train.py.
 */
const db = require('./db');
const log = require('./logger').child('DRIFT');

const ACTIVE_MS = Number(process.env.DRIFT_ACTIVE_MS) || 10 * 60 * 1000;
const state = { lastAlertAt: 0, alerts: 0, notices: 0, lastEvent: null };

function handle(events) {
  for (const ev of events || []) {
    const at = Math.round((ev.at || Date.now() / 1000) * 1000);
    const saved = { ...ev, detectedAt: at };
    db.addDriftEvent(saved);
    state.lastEvent = saved;
    if (ev.level === 'alert') {
      state.alerts += 1;
      state.lastAlertAt = Date.now();
      const detail = ev.features
        ? ev.features.map((f) => `${f.name} ${f.meanBefore}->${f.meanAfter}`).join(', ')
        : `mean ${ev.meanBefore} -> ${ev.meanAfter}, window ${ev.window}`;
      log.warn(`ALERT ${ev.stream}: ${ev.message} (${detail}; after ${ev.observations} observations). `
        + 'Verdicts are flagged until the alert expires. Collect fresh labelled flows and retrain (see README).');
    } else {
      state.notices += 1;
      log.info(`notice ${ev.stream}: ${ev.message} (mean ${ev.meanBefore} -> ${ev.meanAfter})`);
    }
  }
}

const isActive = () => state.lastAlertAt > 0 && Date.now() - state.lastAlertAt < ACTIVE_MS;

function summary() {
  return {
    active: isActive(), activeWindowMs: ACTIVE_MS, alerts: state.alerts, notices: state.notices,
    lastAlertAt: state.lastAlertAt ? new Date(state.lastAlertAt).toISOString() : null,
  };
}

module.exports = { handle, isActive, summary };
