'use strict';
/**
 * logger.js — one structured console logger for the whole pipeline.
 *
 *   12:03:44.123 INFO  [FLOW   ] flow 3f9a1c2e opened 127.0.0.1:51822 -> 127.0.0.1:3000
 *
 * Every stage logs under its own category so a request can be followed from
 * the wire to the verdict:
 *   HTTP -> FLOW -> FEAT -> ML -> DECIDE -> EVENT / BLOCK / DRIFT, plus AUTH, DB, PY, SYS.
 *
 * Environment
 *   LOG_LEVEL     debug | info (default) | warn | error
 *   LOG_FEATURES  "full" prints every model-input feature of every scored flow
 *   LOG_JSON      "true" prints one JSON object per line instead of text
 *   NO_COLOR / FORCE_COLOR  override colour auto-detection
 *
 * The last LOG_BUFFER lines are kept in memory and served to the dashboard's
 * live console through GET /api/logs, so the browser shows what the terminal shows.
 */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const MIN_LEVEL = LEVELS[String(process.env.LOG_LEVEL || 'info').toLowerCase()] ?? LEVELS.info;
const AS_JSON = process.env.LOG_JSON === 'true';
const FULL_FEATURES = String(process.env.LOG_FEATURES || '').toLowerCase() === 'full';
const BUFFER_MAX = Number(process.env.LOG_BUFFER) || 800;
const COLOR = process.env.NO_COLOR ? false : (process.env.FORCE_COLOR ? true : Boolean(process.stdout.isTTY));

const ANSI = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m', blue: '\x1b[34m',
  magenta: '\x1b[35m', cyan: '\x1b[36m', gray: '\x1b[90m',
};
const LEVEL_COLOR = { debug: ANSI.gray, info: ANSI.green, warn: ANSI.yellow, error: ANSI.red };
const CAT_COLOR = {
  HTTP: ANSI.cyan, FLOW: ANSI.blue, FEAT: ANSI.magenta, ML: ANSI.yellow, DECIDE: ANSI.green,
  EVENT: ANSI.cyan, BLOCK: ANSI.red, DRIFT: ANSI.magenta, AUTH: ANSI.blue, DB: ANSI.gray,
  PY: ANSI.gray, SYS: ANSI.cyan, DATA: ANSI.gray,
};

const ring = [];
let seq = 0;

const paint = (code, text) => (COLOR ? `${code}${text}${ANSI.reset}` : text);
const pad2 = (n) => String(n).padStart(2, '0');
function clock(d = new Date()) {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}.${String(d.getMilliseconds()).padStart(3, '0')}`;
}

function write(level, cat, msg) {
  if (LEVELS[level] < MIN_LEVEL) return;
  const now = new Date();
  seq += 1;
  const entry = { seq, t: now.toISOString(), level, cat, msg: String(msg) };
  ring.push(entry);
  if (ring.length > BUFFER_MAX) ring.shift();
  let line;
  if (AS_JSON) {
    line = JSON.stringify(entry);
  } else {
    line = `${paint(ANSI.dim, clock(now))} ${paint(LEVEL_COLOR[level], level.toUpperCase().padEnd(5))} `
      + `${paint(CAT_COLOR[cat] || ANSI.cyan, `[${cat.padEnd(6)}]`)} ${entry.msg}`;
  }
  (level === 'error' || level === 'warn' ? console.error : console.log)(line);
}

/** @param {string} cat short category such as FLOW */
function child(cat) {
  return {
    debug: (m) => write('debug', cat, m),
    info: (m) => write('info', cat, m),
    warn: (m) => write('warn', cat, m),
    error: (m) => write('error', cat, m),
  };
}

/** Entries newer than `since` (a seq number), at most `limit`. */
function since(after = 0, limit = 200) {
  const out = ring.filter((e) => e.seq > after);
  return { last: seq, entries: out.slice(-Math.max(1, Math.min(limit, 500))) };
}

/* ---------------------------------------------------------- formatting helpers */

function fmtBytes(n) {
  if (!Number.isFinite(n)) return '-';
  if (n < 1024) return `${Math.round(n)}B`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)}KB`;
  return `${(n / 1048576).toFixed(2)}MB`;
}
function fmtDurUs(us) {
  if (!Number.isFinite(us)) return '-';
  if (us < 1000) return `${Math.round(us)}us`;
  if (us < 1e6) return `${(us / 1000).toFixed(1)}ms`;
  return `${(us / 1e6).toFixed(2)}s`;
}
function fmtNum(x) {
  if (x === null || x === undefined) return 'null';
  if (!Number.isFinite(x)) return String(x);
  if (Number.isInteger(x)) return String(x);
  const a = Math.abs(x);
  return a >= 1000 ? x.toFixed(1) : a >= 1 ? x.toFixed(3) : x.toPrecision(3);
}
const short = (id) => (id ? String(id).slice(0, 8) : '-');

module.exports = { child, since, fmtBytes, fmtDurUs, fmtNum, short, FULL_FEATURES, clock };
