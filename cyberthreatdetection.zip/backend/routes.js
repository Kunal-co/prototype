'use strict';
/**
 * routes.js — HTTP API. Delegates every piece of work to the owning module:
 * no ML logic and no SQL in here.
 *
 * Endpoints beyond the list in the specification (each needed by a stated requirement):
 *   POST   /api/logout          session ending (auth.js)
 *   GET    /api/session         lets pages check whether the visitor is logged in
 *   GET    /api/features        the canonical schema, so the manual-test form needs no second copy
 *   GET    /api/events/:id      "attack details" view
 *   DELETE /api/blocklist/:id   blocks must be reviewable / reversible
 *   GET    /api/timeline        activity per minute for the dashboard chart
 *   GET    /api/drift           ADWIN drift alerts, per-stream monitor state
 *   GET    /api/behavior        per-user behavioural status, recent-vs-baseline statistics (also inside /api/dashboard)
 *   GET    /api/logs            the console log, so the dashboard can show what the terminal shows
 */
const express = require('express');
const auth = require('./auth');
const flow = require('./flow');
const detector = require('./detector');
const { decide } = require('./decision');
const events = require('./events');
const behavior = require('./behavior');
const blocklist = require('./blocklist');
const drift = require('./drift');
const logger = require('./logger');
const mlLog = logger.child('ML');

const router = express.Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const scopeUser = (req) => (req.query.scope === 'me' ? req.ng.userId : null);

router.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
router.use(express.json({ limit: '100kb' })); // mounted here so parse errors reach this router's error handler

/* ------------------------------------------------------------ session */

router.post('/login', (req, res) => {
  const out = auth.login(req, (req.body || {}).username);
  if (!out.success) return res.status(400).json(out);
  return res.json({ success: true, user: out.user });
});

router.post('/logout', (req, res) => res.json(auth.logout(req, res)));

router.get('/session', (req, res) => res.json({ success: true, ...auth.whoami(req) }));

router.get('/features', auth.requireUser, (req, res) => res.json({ success: true, ...flow.describeSchema() }));

/* ---------------------------------------------------------- dashboard */

router.get('/dashboard', auth.requireUser, (req, res) => {
  const { status, stats } = events.getStats({ userId: scopeUser(req) });
  const schema = flow.describeSchema();
  res.json({
    success: true, scope: req.query.scope === 'me' ? 'me' : 'all', status, stats,
    monitoring: {
      activeFlows: flow.activeCount(),
      engine: detector.status(),
      drift: drift.summary(),
      featureCoverage: { total: schema.count, unavailable: schema.unavailableLive },
    },
    behavior: behaviorView(req),
  });
});

/** User-level behavioural aggregation: the caller's own profile plus the most severe entities (behavior.js). */
function behaviorView(req) {
  const mine = req.ng.userId ? behavior.get(`u:${req.ng.userId}`) : null;
  const scoped = req.query.scope === 'me';
  return {
    me: mine,
    entities: scoped ? (mine ? [mine] : []) : behavior.list({ limit: 25 }),
    config: behavior.config(),
  };
}

router.get('/behavior', auth.requireUser, (req, res) => {
  res.json({ success: true, ...behaviorView(req) });
});

router.get('/timeline', auth.requireUser, (req, res) => {
  res.json({ success: true, ...events.getTimeline({ minutes: Number(req.query.minutes), userId: scopeUser(req) }) });
});

router.get('/drift', auth.requireUser, wrap(async (req, res) => {
  let monitors = null;
  try { monitors = await detector.driftStatus(); } catch { monitors = null; } // engine offline: still show history
  res.json({ success: true, summary: drift.summary(), events: events.listDrift(30), monitors });
}));

router.get('/logs', auth.requireUser, (req, res) => {
  res.json({ success: true, ...logger.since(Number(req.query.since) || 0, Number(req.query.limit) || 200) });
});

router.get('/activity', auth.requireUser, (req, res) => {
  res.json({ success: true, ...events.listActivity({ page: Number(req.query.page), userId: scopeUser(req) }) });
});

router.get('/events/:id', auth.requireUser, (req, res) => {
  const event = events.getEvent(req.params.id);
  if (!event) return res.status(404).json({ success: false, error: 'Event not found' });
  return res.json({ success: true, event });
});

router.get('/attackers', auth.requireUser, (req, res) => {
  res.json({ success: true, attackers: events.getAttackers() });
});

/* Finalize the caller's active flows now (instead of waiting for timeouts). */
router.post('/analyze', auth.requireUser, (req, res) => {
  res.json({ success: true, finalizedFlows: flow.finalizeSession(req.ng.sessionId, 'manual_analyze') });
});

/* ------------------------------------------------------ manual testing */

/**
 * Same path as live traffic: validate -> canonical order -> predict.py -> decision.js.
 * The verdict is returned only. Nothing here touches events, statistics or the blocklist.
 * (The HTTP request that carries the form is itself monitored like any other traffic.)
 */
router.post('/test-detection', auth.requireUser, wrap(async (req, res) => {
  const vector = flow.manualToVector((req.body || {}).features);
  const raw = await detector.predict(vector, { allowMissing: false, observe: false });
  const result = decide(raw, { driftActive: drift.isActive() });
  mlLog.info(`manual test by ${req.ng.username}: cnn=${raw.models.cnn.probability} fcnn=${raw.models.fcnn.probability} `
    + `lstm=${raw.models.lstm.probability} novelty x${raw.novelty.ratio} -> ${result.status} (not stored, drift monitors untouched)`);
  res.json({ success: true, stored: false, featureCount: vector.length, result });
}));

/* ----------------------------------------------------------- blocklist */

router.get('/blocklist', auth.requireUser, (req, res) => res.json({ success: true, enforcing: blocklist.enforcing, blocks: blocklist.list() }));

router.delete('/blocklist/:id', auth.requireUser, (req, res) => {
  const lifted = blocklist.lift(req.params.id);
  return lifted ? res.json({ success: true }) : res.status(404).json({ success: false, error: 'Active block not found' });
});

/* -------------------------------------------------------------- errors */

router.use((req, res) => res.status(404).json({ success: false, error: 'Unknown endpoint' }));

// eslint-disable-next-line no-unused-vars
router.use((err, req, res, next) => {
  if (err instanceof flow.ValidationError) {
    return res.status(400).json({ success: false, error: err.message, details: err.details });
  }
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ success: false, error: 'Malformed JSON body' });
  if (err && err.type === 'entity.too.large') return res.status(413).json({ success: false, error: 'Request body too large' });
  if (err && (err.type === 'request.aborted' || err.code === 'ECONNRESET')) { // the client hung up mid-request
    logger.child('HTTP').warn(`client aborted the request: ${err.message}`);
    return res.headersSent ? undefined : res.status(400).end();
  }
  logger.child('SYS').error(`route error: ${err && err.message}`);
  return res.status(503).json({ success: false, error: 'Detection engine unavailable', detail: err && err.message });
});

module.exports = router;
