'use strict';
/**
 * auth.js — prototype authentication and session management.
 *
 * Monitoring starts on the first visit, so an anonymous session is created for
 * every new browser. Logging in attaches a user to that session. Sessions live
 * in memory (they end on restart); users are persisted through db.js.
 * This is NOT production authentication: there is no password.
 */
const { randomUUID } = require('node:crypto');
const { EventEmitter } = require('node:events');
const db = require('./db');
const log = require('./logger').child('AUTH');

const numEnv = (name, dflt) => {
  const raw = process.env[name];
  const n = Number(raw);
  return raw !== undefined && raw !== '' && Number.isFinite(n) ? n : dflt;
};

const IDLE_MS = numEnv('SESSION_IDLE_MS', 30 * 60 * 1000);
const MAX_AGE_MS = numEnv('SESSION_MAX_MS', 8 * 60 * 60 * 1000);
const MAX_SESSIONS = 20000;
const TRUST_PROXY_HEADERS = process.env.TRUST_PROXY_HEADERS === 'true';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const USERNAME_RE = /^[A-Za-z0-9_.\- ]{1,32}$/;

const sessions = new Map(); // sessionId -> { id, userId, username, deviceId, createdAt, lastSeen }
const events = new EventEmitter(); // 'session-end' -> { sessionId, userId, reason }
let sweeper = null;

/* --------------------------------------------------------------- helpers */

function normalizeIp(addr) {
  if (!addr) return 'unknown';
  return addr.startsWith('::ffff:') ? addr.slice(7) : addr;
}

function isLoopback(ip) {
  return ip === '127.0.0.1' || ip === '::1' || ip.startsWith('127.');
}

/** Real client IP. Proxy headers are honoured ONLY if enabled and the TCP peer is loopback (e.g. cloudflared). */
function clientIp(req) {
  const remote = normalizeIp(req.socket.remoteAddress);
  if (TRUST_PROXY_HEADERS && isLoopback(remote)) {
    const fwd = req.headers['cf-connecting-ip'] || String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (fwd) return normalizeIp(fwd);
  }
  return remote;
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function setCookie(req, res, name, value, maxAgeSec) {
  const secure = req.headers['x-forwarded-proto'] === 'https' || req.secure ? '; Secure' : '';
  res.append('Set-Cookie', `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`);
}

const expired = (s, now = Date.now()) => now - s.lastSeen > IDLE_MS || now - s.createdAt > MAX_AGE_MS;

/* -------------------------------------------------------------- sessions */

function createSession(deviceId) {
  if (sessions.size >= MAX_SESSIONS) {
    const oldest = sessions.values().next().value;
    if (oldest) endSession(oldest, 'evicted');
  }
  const now = Date.now();
  const s = { id: randomUUID(), userId: null, username: null, deviceId, createdAt: now, lastSeen: now };
  sessions.set(s.id, s);
  log.debug(`session ${s.id.slice(0, 8)} created (device ${deviceId.slice(0, 8)}), ${sessions.size} active`);
  return s;
}

function endSession(s, reason) {
  if (!sessions.delete(s.id)) return;
  log.info(`session ${s.id.slice(0, 8)} ended (${reason})${s.username ? ` user ${s.username}` : ''}; ${sessions.size} active`);
  events.emit('session-end', { sessionId: s.id, userId: s.userId, reason });
}

/** Express middleware: identify (or create) the session and device for every request. */
function middleware(req, res, next) {
  const cookies = parseCookies(req.headers.cookie);
  let deviceId = cookies.ng_did;
  let newDevice = false;
  if (!UUID_RE.test(deviceId || '')) {
    deviceId = randomUUID();
    newDevice = true;
    setCookie(req, res, 'ng_did', deviceId, 365 * 24 * 3600);
  }
  let s = sessions.get(cookies.ng_sid);
  if (s && expired(s)) { endSession(s, 'expired'); s = null; }
  if (!s) {
    s = createSession(deviceId);
    setCookie(req, res, 'ng_sid', s.id, Math.floor(MAX_AGE_MS / 1000));
  }
  s.lastSeen = Date.now();
  req.ng = { ip: clientIp(req), deviceId, newDevice, sessionId: s.id, userId: s.userId, username: s.username };
  next();
}

/* ------------------------------------------------------------ operations */

function login(req, rawUsername) {
  const username = typeof rawUsername === 'string' ? rawUsername.trim() : '';
  if (!USERNAME_RE.test(username)) {
    return { success: false, error: 'Username must be 1-32 characters: letters, digits, space, dot, dash or underscore.' };
  }
  const s = sessions.get(req.ng.sessionId);
  if (!s) return { success: false, error: 'No active session' };
  const user = db.upsertUser(username);
  s.userId = user.id;
  s.username = user.username;
  req.ng.userId = user.id;
  req.ng.username = user.username;
  log.info(`login: user "${user.username}" (${user.id.slice(0, 8)}) on session ${s.id.slice(0, 8)} from ${req.ng.ip}`);
  return { success: true, user: { id: user.id, username: user.username }, sessionId: s.id };
}

function logout(req, res) {
  const s = sessions.get(req.ng.sessionId);
  if (s) endSession(s, 'logout');
  res.append('Set-Cookie', 'ng_sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
  return { success: true };
}

function whoami(req) {
  return req.ng && req.ng.userId
    ? { authenticated: true, user: { id: req.ng.userId, username: req.ng.username } }
    : { authenticated: false, user: null };
}

function requireUser(req, res, next) {
  if (req.ng && req.ng.userId) return next();
  return res.status(401).json({ success: false, error: 'Login required' });
}

function start() {
  if (sweeper) return;
  sweeper = setInterval(() => {
    const now = Date.now();
    for (const s of [...sessions.values()]) if (expired(s, now)) endSession(s, 'expired');
  }, 30000);
  sweeper.unref();
}

function stop() {
  if (sweeper) clearInterval(sweeper);
  sweeper = null;
}

module.exports = {
  events, middleware, login, logout, whoami, requireUser, start, stop,
  normalizeIp, isLoopback, clientIp, sessionCount: () => sessions.size,
};
