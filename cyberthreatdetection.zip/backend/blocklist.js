'use strict';
/**
 * blocklist.js — time-limited, reviewable restrictions.
 *
 * Identity is matched on user id, device cookie and session id. The IP is
 * recorded for attribution but is only used to match requests that carry NO
 * device cookie (typical of scripted attackers), and never for loopback
 * addresses unless BLOCK_LOOPBACK=true, so one shared address cannot lock out
 * every legitimate user behind it.
 *
 * Enforcement is OFF by default (BLOCK_ENFORCE=true to enable): blocks are recorded and
 * shown for review but requests are not refused. Live features are approximations (see
 * flow.js), so automatic lock-outs must be a deliberate choice, not a default.
 *
 * Only repeated, high-confidence known attacks create a block. Possible
 * zero-days are never blocked automatically; they need human review.
 */
const db = require('./db');
const { isLoopback } = require('./auth');
const log = require('./logger').child('BLOCK');

const numEnv = (name, dflt) => {
  const raw = process.env[name];
  const n = Number(raw);
  return raw !== undefined && raw !== '' && Number.isFinite(n) ? n : dflt;
};
const MIN_CONFIDENCE = numEnv('BLOCK_MIN_CONFIDENCE', 0.9);
const MIN_DETECTIONS = numEnv('BLOCK_MIN_DETECTIONS', 3);
const TTL_MS = numEnv('BLOCK_TTL_MS', 15 * 60 * 1000);
const BLOCK_LOOPBACK = process.env.BLOCK_LOOPBACK === 'true';
const ENFORCE = process.env.BLOCK_ENFORCE === 'true';
const iso = (ms) => (ms == null ? null : new Date(ms).toISOString());

/** @param event aggregated event in API shape (events.js). Returns the new block or null. */
function consider(event) {
  if (event.status !== 'attack') return null;
  if (event.detectionCount < MIN_DETECTIONS || event.confidence < MIN_CONFIDENCE) return null;
  const now = Date.now();
  if (db.hasActiveBlockForEvent(event.eventId, now)) return null;
  const block = {
    userId: event.userId, sessionId: event.sessionId, deviceId: event.deviceId, ip: event.sourceIp,
    eventId: event.eventId, reason: `Repeated known attack (${event.detectionCount} detections, confidence ${event.confidence})`,
    createdAt: now, expiresAt: now + TTL_MS,
  };
  const id = db.addBlock(block);
  log.warn(`restriction ${id.slice(0, 8)} created for ${event.userId ? `user ${event.userId.slice(0, 8)}` : `ip ${event.sourceIp}`} `
    + `until ${new Date(block.expiresAt).toISOString()} (${ENFORCE ? 'ENFORCED' : 'recording only'})`);
  return { id, ...block };
}

function lookup(req) {
  if (!req.ng) return null;
  const ip = req.ng.ip;
  const ipEligible = req.ng.newDevice && (BLOCK_LOOPBACK || !isLoopback(ip));
  return db.isBlocked({ userId: req.ng.userId, sessionId: req.ng.sessionId, deviceId: req.ng.deviceId, ip, ipEligible });
}

/** Express middleware: refuse restricted clients. Runs after capture so blocked traffic is still observed. */
function middleware(req, res, next) {
  if (!ENFORCE) return next();
  const block = lookup(req);
  if (!block) return next();
  log.warn(`refused ${req.method} ${req.path} from ${req.ng.ip} (restriction ${block.id.slice(0, 8)})`);
  const body = { success: false, error: 'Access restricted', reason: block.reason, until: iso(block.expires_at) };
  if (req.path.startsWith('/api')) return res.status(403).json(body);
  return res.status(403).type('text/plain').send(`Access restricted until ${body.until}.`);
}

function list() {
  const now = Date.now();
  return db.getBlocks().map((b) => ({
    id: b.id, userId: b.user_id, sessionId: b.session_id, deviceId: b.device_id, ip: b.ip,
    eventId: b.event_id, reason: b.reason, createdAt: iso(b.created_at), expiresAt: iso(b.expires_at),
    liftedAt: iso(b.lifted_at),
    state: !b.active ? 'lifted' : b.expires_at <= now ? 'expired' : 'active',
  }));
}

const lift = (id) => {
  const ok = db.liftBlock(id);
  if (ok) log.info(`restriction ${String(id).slice(0, 8)} lifted`);
  return ok;
};

module.exports = { consider, middleware, list, lift, enforcing: ENFORCE };
