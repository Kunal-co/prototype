'use strict';
/**
 * detector.js — bridge between Node.js and ml/predict.py.
 *
 * A single long-lived Python worker keeps the CNN, FCNN, LSTM and autoencoder in memory and
 * exchanges one JSON object per line over stdin/stdout (contract in predict.py). Models are
 * loaded once, not once per prediction. The worker also owns the ADWIN drift monitors, so
 * every live flow it scores can raise drift events (returned with the prediction).
 */
const { spawn } = require('node:child_process');
const readline = require('node:readline');
const path = require('node:path');
const log = require('./logger').child('PY');

const ML_DIR = path.join(__dirname, '..', 'ml');
const PYTHON = process.env.PYTHON_BIN || (process.platform === 'win32' ? 'python' : 'python3');
const TIMEOUT_MS = Number(process.env.PREDICT_TIMEOUT_MS) || 15000;
const START_TIMEOUT_MS = Number(process.env.ML_START_TIMEOUT_MS) || 180000; // TensorFlow takes a few seconds to import
const RETRY_AFTER_FAILURE_MS = 30000;
const MAX_PENDING = 500;

let child = null;
let startPromise = null;
let ready = false;
let info = null;
let lastError = null;
let lastFailAt = 0;
let nextId = 1;
const pending = new Map();

function failAll(err) {
  for (const [id, p] of pending) { clearTimeout(p.timer); p.reject(err); pending.delete(id); }
}

function start() {
  if (startPromise) return startPromise;
  startPromise = new Promise((resolve, reject) => {
    let settled = false;
    const settle = (fn, value) => { if (!settled) { settled = true; clearTimeout(timer); fn(value); } };
    const timer = setTimeout(() => {
      lastError = 'Python worker did not become ready in time';
      if (child) child.kill();
      settle(reject, new Error(lastError));
    }, START_TIMEOUT_MS);

    log.info(`starting ML worker: ${PYTHON} ml/predict.py --serve`);
    const proc = spawn(PYTHON, ['-u', path.join(ML_DIR, 'predict.py'), '--serve'], {
      cwd: ML_DIR, stdio: ['pipe', 'pipe', 'pipe'], env: process.env,
    });
    child = proc;
    proc.stdin.on('error', () => { /* worker died; 'exit' handler reports it */ });
    readline.createInterface({ input: proc.stderr }).on('line', (line) => {
      if (!line.trim()) return;
      if (/traceback|error|exception/i.test(line)) log.error(line); else log.debug(line);
    });
    proc.on('error', (err) => {
      lastError = `Cannot start "${PYTHON}": ${err.message}`;
      lastFailAt = Date.now(); ready = false; startPromise = null; child = null;
      failAll(new Error(lastError));
      settle(reject, new Error(lastError));
    });

    const rl = readline.createInterface({ input: proc.stdout });
    rl.on('line', (line) => {
      let msg;
      try { msg = JSON.parse(line); } catch { log.warn(`non-JSON from worker: ${line.slice(0, 200)}`); return; }
      if (Object.prototype.hasOwnProperty.call(msg, 'ready')) {
        if (msg.ready) { ready = true; info = msg.info; lastError = null; settle(resolve, info); }
        else { lastError = msg.error; settle(reject, new Error(msg.error)); }
        return;
      }
      const p = pending.get(msg.id);
      if (!p) return;
      pending.delete(msg.id);
      clearTimeout(p.timer);
      if (msg.ok) p.resolve(msg);
      else p.reject(new Error(msg.error || 'prediction failed'));
    });

    proc.on('exit', (code, signal) => {
      const err = new Error(`Python worker exited (code ${code}, signal ${signal})`);
      if (!lastError) lastError = err.message;
      log.error(err.message);
      lastFailAt = Date.now(); ready = false; startPromise = null; child = null;
      failAll(err);
      settle(reject, new Error(lastError));
    });
  });
  startPromise.catch(() => { /* callers handle; avoid unhandled rejection */ });
  return startPromise;
}

async function request(payload) {
  if (process.env.ML_DISABLED === 'true') throw new Error('ML engine disabled (capture-only mode)');
  if (!ready) {
    if (Date.now() - lastFailAt < RETRY_AFTER_FAILURE_MS && lastError) throw new Error(`ML engine unavailable: ${lastError}`);
    await start();
  }
  if (pending.size >= MAX_PENDING) throw new Error('prediction queue is full');
  return new Promise((resolve, reject) => {
    const id = nextId++;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('prediction timed out')); }, TIMEOUT_MS);
    pending.set(id, { resolve, reject, timer });
    child.stdin.write(`${JSON.stringify({ id, ...payload })}\n`);
  });
}

/**
 * @param {Array<number|null>} vector ordered exactly like ml/features.json
 * @param {{allowMissing?: boolean, observe?: boolean, source?: {ip: string, flowId?: string, startedMs?: number}}} opts
 *        live flows may contain nulls and feed the drift monitors and the per-IP history the LSTM reads;
 *        manual tests may not do either. `source` tells the LSTM which IP's behaviour this flow belongs to
 *        (optional: without it the LSTM sees just this flow).
 */
async function predict(vector, { allowMissing = false, observe = false, source = null } = {}) {
  if (!Array.isArray(vector)) throw new TypeError('vector must be an array');
  if (vector.some((v) => v !== null && !Number.isFinite(v))) throw new TypeError('vector contains a non-finite value');
  const wire = source && source.ip ? { ip: String(source.ip), flow_id: source.flowId, started_ms: source.startedMs } : undefined;
  const msg = await request({ features: vector, allow_missing: allowMissing, observe, source: wire });
  return { models: msg.models, ensemble: msg.ensemble, novelty: msg.novelty, drift: msg.drift, sequence: msg.sequence, meta: msg.meta };
}

/** Per-stream state of the ADWIN monitors (window length, mean, detections). */
async function driftStatus() {
  const msg = await request({ cmd: 'drift' });
  return msg.drift_status;
}

const status = () => ({
  ready, info,
  error: ready ? null : (process.env.ML_DISABLED === 'true' ? 'capture-only mode (ML_DISABLED)' : lastError),
});

function stop() {
  if (child) child.kill();
  failAll(new Error('detector stopped'));
}

module.exports = { start, predict, driftStatus, status, stop };
