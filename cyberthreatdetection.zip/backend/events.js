'use strict';
/**
 * events.js — security event management.
 *
 * Normal flows: one row per finalized flow.
 * Attacks / possible zero-days: ONE aggregated event per offender and status.
 * Repeated detections inside AGG_WINDOW_MS update that event (request_count,
 * detection_count, last_seen) instead of creating new rows.
 */
const { randomUUID } = require('node:crypto');
const db = require('./db');
const blocklist = require('./blocklist');
const behavior = require('./behavior');
const log = require('./logger').child('EVENT');
const { short } = require('./logger');

const numEnv = (name, dflt) => {
  const raw = process.env[name];
  const n = Number(raw);
  return raw !== undefined && raw !== '' && Number.isFinite(n) ? n : dflt;
};
const AGG_WINDOW_MS = numEnv('EVENT_AGG_WINDOW_MS', 5 * 60 * 1000);
const STATUS_WINDOW_MS = numEnv('STATUS_WINDOW_MS', 5 * 60 * 1000);
const PAGE_SIZE = 20;

const iso = (ms) => (ms == null ? null : new Date(ms).toISOString());

function toApi(row) {
  if (!row) return null;
  let flow = null;
  try { flow = row.flow_info ? JSON.parse(row.flow_info) : null; } catch { flow = null; }
  return {
    eventId: row.id,
    userId: row.user_id,
    sessionId: row.session_id,
    deviceId: row.device_id,
    sourceIp: row.source_ip,
    destinationIp: row.dest_ip,
    sourcePort: row.source_port,
    destinationPort: row.dest_port,
    protocol: row.protocol,
    status: row.status,
    severity: row.severity,
    confidence: row.confidence,
    reason: row.reason,
    models: {
      cnn: { probability: row.cnn_prob },
      fcnn: { probability: row.fcnn_prob },
      lstm: { probability: row.lstm_prob },
      ensemble: { probability: row.ensemble_prob, votes: row.votes },
      novelty: { flag: row.novelty_flag === 1 || row.if_label === 'anomaly', score: row.novelty_score, ratio: row.novelty_ratio },
    },
    legacy: row.xgb_label ? { xgboost: { label: row.xgb_label, confidence: row.xgb_confidence }, isolationForest: { label: row.if_label, anomalyScore: row.if_score } } : null,
    driftActive: row.drift_active === 1,
    firstSeen: iso(row.first_seen),
    lastSeen: iso(row.last_seen),
    timestamp: iso(row.last_seen),
    requestCount: row.request_count,
    detectionCount: row.detection_count,
    length: row.total_bytes,
    missingFeatures: row.missing_features,
    flow,
  };
}

/**
 * Persist the outcome for one flow report.
 * @param {{flow: object, decision: object, behavior?: object}} p flow = report emitted by flow.js,
 *        behavior = the user-level aggregate for this flow's owner (behavior.js)
 */
function recordDetection({ flow, decision, behavior: profile = null }) {
  const m = decision.models;
  const common = {
    sourceIp: flow.sourceIp, destIp: flow.destIp, sourcePort: flow.sourcePort, destPort: flow.destPort,
    protocol: flow.protocol, status: decision.status, severity: decision.severity,
    confidence: decision.confidence, reason: decision.reason,
    cnnProb: m.cnn.probability, fcnnProb: m.fcnn.probability, lstmProb: m.lstm.probability,
    ensembleProb: m.ensemble.probability, votes: m.ensemble.votes,
    noveltyScore: m.novelty.score, noveltyRatio: m.novelty.ratio, noveltyFlag: m.novelty.flag,
    driftActive: decision.driftActive,
    userId: flow.userId, sessionId: flow.sessionId, deviceId: flow.deviceId,
    missingFeatures: flow.missing.length,
    flowInfo: JSON.stringify({
      flowId: flow.flowId, closeReason: flow.reason, durationUs: flow.durationUs,
      requests: flow.requests, bytesForward: flow.bytesFwd, bytesBackward: flow.bytesBwd,
      missingFeatureNames: flow.missing,
    }),
  };

  if (decision.status === 'normal') {
    if (!flow.final) return null; // early snapshots that look normal are not stored
    const id = randomUUID();
    db.saveEvent({
      id, ...common, aggKey: null, firstSeen: flow.startedAtMs, lastSeen: flow.endedAtMs,
      requestCount: flow.requests, detectionCount: 1, totalBytes: flow.totalBytes,
    });
    log.info(`stored normal flow ${short(flow.flowId)} as event ${short(id)} (${flow.requests} request(s), ${flow.totalBytes} bytes)`);
    return { event: toApi(db.getEvent(id)), created: true, block: null };
  }

  const aggKey = flow.userId ? `u:${flow.userId}` : `ip:${flow.sourceIp}`;
  const open = db.findOpenEvent(aggKey, decision.status, Date.now() - AGG_WINDOW_MS);
  let id; let created = false;
  if (open) {
    id = open.id;
    db.updateEvent(id, {
      lastSeen: flow.endedAtMs, addRequests: flow.requestsDelta, addBytes: flow.bytesDelta, confidence: decision.confidence,
      severity: decision.severity, reason: decision.reason,
      cnnProb: common.cnnProb, fcnnProb: common.fcnnProb, lstmProb: common.lstmProb,
      ensembleProb: common.ensembleProb, votes: common.votes, noveltyScore: common.noveltyScore,
      noveltyRatio: common.noveltyRatio, noveltyFlag: common.noveltyFlag, driftActive: common.driftActive,
      missingFeatures: common.missingFeatures, flowInfo: common.flowInfo,
      userId: flow.userId, sessionId: flow.sessionId, deviceId: flow.deviceId,
    });
  } else {
    id = randomUUID();
    created = true;
    db.saveEvent({
      id, ...common, aggKey, firstSeen: flow.startedAtMs, lastSeen: flow.endedAtMs,
      requestCount: flow.requestsDelta, detectionCount: 1, totalBytes: flow.bytesDelta,
    });
  }
  const event = toApi(db.getEvent(id));
  log.warn(`${created ? 'NEW' : 'updated'} ${decision.status} event ${short(id)} for ${aggKey}: `
    + `${event.requestCount} request(s), ${event.detectionCount} detection(s), confidence ${event.confidence}`);
  // A restriction needs the USER-level status to be 'attack' too (immediate high-confidence, or repeated attacks):
  // one flagged flow from an otherwise normal user is not enough. Without a profile the old rule applies.
  const block = decision.status === 'attack' && (!profile || profile.status === 'attack') ? blocklist.consider(event) : null;
  return { event, created, block };
}

/* Read side — routes.js goes through these, never through db.js directly. */

function listActivity({ page = 1, userId = null } = {}) {
  const safePage = Math.max(1, Math.floor(page) || 1);
  const { rows, total } = db.getRecentEvents({ limit: PAGE_SIZE, offset: (safePage - 1) * PAGE_SIZE, userId });
  return { page: safePage, pageSize: PAGE_SIZE, total, totalPages: Math.max(1, Math.ceil(total / PAGE_SIZE)), records: rows.map(toApi) };
}

function getEvent(id) { return toApi(db.getEvent(id)); }

function getStats({ userId = null } = {}) {
  const s = db.getDashboardStats({ userId, threatSince: Date.now() - STATUS_WINDOW_MS });
  // The headline state is the worst USER-level status (behavior.js), not "any flagged flow in the last minutes".
  const o = behavior.overview({ keys: userId ? [`u:${userId}`] : null });
  return {
    status: { state: o.state, windowSeconds: STATUS_WINDOW_MS / 1000, lastThreat: iso(s.recent.lastThreat),
      behavior: { counts: o.counts, entities: o.entities, worst: o.worst } },
    stats: {
      totalActivity: s.totalActivity, totalRequests: s.totalRequests, attacks: s.attacks,
      anomalies: s.anomalies, possibleZeroDays: s.possibleZeroDays, attackRequests: s.attackRequests,
    },
  };
}

function getAttackers() {
  return db.getAttackers(50).map((a) => ({
    identifier: a.agg_key, userId: a.user_id, username: a.username, sourceIp: a.source_ip,
    deviceId: a.device_id, events: a.events, requestCount: a.requests, maxConfidence: a.max_confidence,
    worstStatus: a.worst === 2 ? 'attack' : 'possible_zero_day',
    firstSeen: iso(a.first_seen), lastSeen: iso(a.last_seen), latestEventId: a.latest_event_id,
  }));
}

function getTimeline({ minutes = 60, userId = null } = {}) {
  const span = Math.max(5, Math.min(1440, Math.floor(minutes) || 60));
  const bucketMs = span <= 120 ? 60000 : span <= 720 ? 300000 : 900000;
  const end = Math.ceil(Date.now() / bucketMs) * bucketMs;
  const start = end - Math.ceil((span * 60000) / bucketMs) * bucketMs;
  const by = new Map();
  for (const r of db.getTimeline({ since: start, bucketMs, userId })) {
    const b = by.get(r.bucket) || { normal: 0, attack: 0, possible_zero_day: 0 };
    b[r.status] = r.n; by.set(r.bucket, b);
  }
  const buckets = [];
  for (let t = start; t < end; t += bucketMs) {
    const b = by.get(t) || { normal: 0, attack: 0, possible_zero_day: 0 };
    buckets.push({ t: new Date(t).toISOString(), ...b });
  }
  return { bucketSeconds: bucketMs / 1000, buckets };
}

function listDrift(limit = 30) {
  return db.getDriftEvents(limit).map((r) => {
    let features = null;
    try { features = r.details ? JSON.parse(r.details) : null; } catch { features = null; }
    return { id: r.id, detectedAt: iso(r.detected_at), stream: r.stream, kind: r.kind, level: r.level, message: r.message,
      meanBefore: r.mean_before, meanAfter: r.mean_after, window: r.window, observations: r.observations, features };
  });
}

module.exports = { recordDetection, getTimeline, listDrift, listActivity, getEvent, getStats, getAttackers, PAGE_SIZE };
