'use strict';
/**
 * behavior.js — user-level behavioural aggregation.
 *
 * decision.js still judges ONE flow. This module remembers what each user (or, for anonymous traffic,
 * each source IP) has been doing and turns the stream of flow verdicts into a status for that user:
 *
 *   normal             nothing suspicious in the recent window
 *   watch              suspicious flow(s), but isolated or in line with this user's own history
 *   possible_zero_day  repeated/sustained unusual flows that stand out from the user's baseline
 *   attack             a genuinely high-confidence attack flow (immediate), or repeated/sustained attack flows
 *
 * One possible_zero_day or one ordinary attack flow only makes a user 'watch'. Escalation needs repetition.
 * An attack flow where ALL models agree with ensemble >= IMMEDIATE_PROB escalates at once and is held for HOLD_MS.
 *
 * History is a ring buffer per entity, in memory only (like the drift monitors: restarts start empty).
 * "Recent" = the last RECENT_FLOWS flows within RECENT_MS. "Baseline" = older flows within BASELINE_MS,
 * so the baseline never contains the behaviour being judged. Until BASELINE_MIN older flows exist there is
 * no baseline and only the absolute thresholds apply.
 *
 * The LSTM: when the model is the per-IP SEQUENCE variant (ml/train.py with source IP + timestamps),
 * predict.py reads this entity's last flows (server.js passes the entity key as the sequence owner) and the
 * LSTM vote is already a judgement of the user's sequence. Its hostile votes then count as corroboration here
 * (REPEAT_MIN drops by one). With the legacy single-flow LSTM the vote is per flow and is reported as such.
 *
 * Pure bookkeeping: no I/O, no dependencies. Every time-dependent function takes `now` so it can be tested.
 */
const log = require('./logger').child('BEHAV');

const numEnv = (name, dflt) => {
  const raw = process.env[name];
  const n = Number(raw);
  return raw !== undefined && raw !== '' && Number.isFinite(n) ? n : dflt;
};

const CFG = {
  recentFlows: numEnv('BEHAVIOR_RECENT_FLOWS', 20),
  recentMs: numEnv('BEHAVIOR_RECENT_MS', 10 * 60 * 1000),
  baselineMs: numEnv('BEHAVIOR_BASELINE_MS', 24 * 60 * 60 * 1000),
  baselineMin: numEnv('BEHAVIOR_BASELINE_MIN', 10),       // older flows needed before a baseline exists
  deviation: numEnv('BEHAVIOR_DEVIATION', 0.25),          // recent ratio must exceed the baseline ratio by this much
  repeatMin: numEnv('BEHAVIOR_REPEAT_MIN', 3),            // suspicious flows needed for 'repeated'
  repeatRatio: numEnv('BEHAVIOR_REPEAT_RATIO', 0.4),      // ...and this share of the recent window (or a run, below)
  sustainRun: numEnv('BEHAVIOR_SUSTAIN_RUN', 5),          // consecutive suspicious flows = 'sustained'
  hardRatio: numEnv('BEHAVIOR_HARD_RATIO', 0.8),          // at/above this (with >= 6 flows) the baseline is ignored
  immediateProb: numEnv('BEHAVIOR_IMMEDIATE_PROB', 0.95), // ensemble probability for an immediate alert
  holdMs: numEnv('BEHAVIOR_HOLD_MS', 5 * 60 * 1000),      // how long an immediate alert keeps the user at 'attack'
  historyMax: numEnv('BEHAVIOR_HISTORY_MAX', 300),
  maxEntities: numEnv('BEHAVIOR_MAX_ENTITIES', 2000),
};

const CLASS = { normal: 0, possible_zero_day: 1, attack: 2 };
const LEVEL = { normal: 0, watch: 1, possible_zero_day: 2, attack: 3 };
const round = (x, d = 3) => (x == null ? null : Math.round(x * 10 ** d) / 10 ** d);

const entities = new Map(); // key -> { key, userId, ip, history: [], immediateUntil, immediateAt, statusSince, last }

/** Same convention as events.js aggregation: a logged-in user is one entity, anonymous traffic is one entity per IP. */
const entityKey = ({ userId, sourceIp }) => (userId ? `u:${userId}` : `ip:${sourceIp || 'unknown'}`);

function touch(key, flow, now) {
  let e = entities.get(key);
  if (!e) {
    e = { key, userId: flow.userId || null, ip: flow.sourceIp || null, history: [], immediateUntil: 0, immediateAt: 0,
      statusSince: now, lastStatus: 'normal', flows: 0, first: now, last: now, lastLstm: null };
    entities.set(key, e);
    if (entities.size > CFG.maxEntities) { // evict the least recently seen entity
      let oldest = null;
      for (const x of entities.values()) if (!oldest || x.last < oldest.last) oldest = x;
      if (oldest && oldest !== e) entities.delete(oldest.key);
    }
  } else {
    entities.delete(key); entities.set(key, e); // keep Map order = recency
  }
  if (flow.userId) e.userId = flow.userId;
  if (flow.sourceIp) e.ip = flow.sourceIp;
  return e;
}

/** Counts of the three verdicts in a list of history entries. */
function tally(list) {
  const t = { n: list.length, normal: 0, zd: 0, attack: 0 };
  for (const h of list) { if (h.cls === 2) t.attack += 1; else if (h.cls === 1) t.zd += 1; else t.normal += 1; }
  t.suspicious = t.zd + t.attack;
  t.ratio = t.n ? t.suspicious / t.n : null;
  t.attackRatio = t.n ? t.attack / t.n : null;
  return t;
}

function runLength(list, test) {
  let n = 0;
  for (let i = list.length - 1; i >= 0 && test(list[i]); i--) n += 1;
  return n;
}

/**
 * Evaluate one entity at time `now`. Deterministic; does not modify history.
 * Returns the full statistics block that the API and dashboard show.
 */
function evaluate(e, now = Date.now()) {
  const inRecent = e.history.filter((h) => now - h.t <= CFG.recentMs).slice(-CFG.recentFlows);
  const recentStart = inRecent.length ? inRecent[0].t : now;
  const older = e.history.filter((h) => h.t < recentStart && now - h.t <= CFG.baselineMs);
  const recent = tally(inRecent);
  const base = tally(older);
  const hasBaseline = base.n >= CFG.baselineMin;
  const baselineRatio = hasBaseline ? base.ratio : null;
  const baselineAttackRatio = hasBaseline ? base.attackRatio : null;
  const deviationOf = (cur, ref) => (ref == null || cur == null ? null : cur - ref);
  const devSuspicious = deviationOf(recent.ratio, baselineRatio);
  const devAttack = deviationOf(recent.attackRatio, baselineAttackRatio);
  const suspiciousRun = runLength(inRecent, (h) => h.cls > 0);
  const attackRun = runLength(inRecent, (h) => h.cls === 2);

  // LSTM corroboration, only meaningful when the LSTM reads this entity's sequence
  const seq = inRecent.filter((h) => h.lstmWindow > 1);
  const lstmHostile = seq.filter((h) => h.lstm >= 0.5).length;
  const lstmSequence = e.lastLstm ? e.lastLstm.sequence : false;
  const lstmCorroborates = lstmSequence && lstmHostile >= 2 && lstmHostile / Math.max(1, seq.length) >= 0.5;
  const repeatMin = Math.max(2, CFG.repeatMin - (lstmCorroborates ? 1 : 0));

  // a class of suspicious behaviour is 'repeated' when it is frequent enough in the window (or a run),
  // and 'significant' when it also departs from this user's own baseline (or no baseline exists yet)
  const verdictFor = (count, ratio, run, deviation) => {
    const repeated = count >= repeatMin && (ratio >= CFG.repeatRatio || run >= repeatMin);
    const hard = recent.n >= 6 && ratio >= CFG.hardRatio;
    const significant = deviation == null || deviation >= CFG.deviation || hard;
    return { repeated, significant, sustained: repeated && significant && (run >= CFG.sustainRun || hard) };
  };
  const atk = verdictFor(recent.attack, recent.attackRatio || 0, attackRun, devAttack);
  const sus = verdictFor(recent.suspicious, recent.ratio || 0, suspiciousRun, devSuspicious);

  let status = 'normal'; let pattern = 'none'; let reason = 'No suspicious flows in the recent window';
  if (now < e.immediateUntil) {
    status = 'attack'; pattern = 'immediate';
    reason = `High-confidence attack flow at ${new Date(e.immediateAt).toISOString()} (all models agree, ensemble >= ${CFG.immediateProb})`;
  } else if (atk.repeated && atk.significant) {
    status = 'attack'; pattern = atk.sustained ? 'sustained' : 'repeated';
    reason = `${recent.attack} attack flows in the last ${recent.n} (${Math.round(100 * recent.attackRatio)}%)`
      + (baselineAttackRatio == null ? ', no baseline yet' : `, baseline ${Math.round(100 * baselineAttackRatio)}%`);
  } else if (sus.repeated && sus.significant && recent.zd >= 2) {
    status = 'possible_zero_day'; pattern = sus.sustained ? 'sustained' : 'repeated';
    reason = `${recent.suspicious} unusual or attack flows in the last ${recent.n} (${Math.round(100 * recent.ratio)}%)`
      + (baselineRatio == null ? ', no baseline yet' : `, baseline ${Math.round(100 * baselineRatio)}%`);
  } else if (recent.suspicious > 0) {
    status = 'watch'; pattern = 'isolated';
    reason = sus.repeated && !sus.significant
      ? `${recent.suspicious} of ${recent.n} recent flows suspicious, but in line with this user's own baseline (${Math.round(100 * baselineRatio)}%)`
      : `${recent.suspicious} of ${recent.n} recent flows suspicious: isolated, below the escalation thresholds`;
  }
  const severity = status === 'normal' ? 'low' : status === 'watch' ? 'medium'
    : (pattern === 'sustained' || pattern === 'immediate') ? 'critical' : 'high';

  return {
    key: e.key, userId: e.userId, ip: e.ip,
    status, level: LEVEL[status], pattern, severity, reason,
    since: new Date(e.statusSince).toISOString(), firstSeen: new Date(e.first).toISOString(), lastSeen: new Date(e.last).toISOString(),
    totalFlows: e.flows,
    recent: { flows: recent.n, normal: recent.normal, possibleZeroDay: recent.zd, attack: recent.attack,
      suspiciousRatio: round(recent.ratio), attackRatio: round(recent.attackRatio), suspiciousRun, attackRun },
    baseline: { flows: base.n, available: hasBaseline, suspiciousRatio: round(baselineRatio), attackRatio: round(baselineAttackRatio),
      deviation: round(devSuspicious), attackDeviation: round(devAttack) },
    lstm: { mode: lstmSequence ? 'sequence' : 'single-flow', latest: e.lastLstm ? round(e.lastLstm.p) : null,
      window: e.lastLstm ? e.lastLstm.window : null, hostileVotes: lstmHostile, corroborates: lstmCorroborates },
  };
}

/**
 * Record one scored flow and return the entity's updated aggregate.
 * @param flow     the report emitted by flow.js (needs flowId, userId, sourceIp)
 * @param decision the verdict from decision.js
 */
function observe(flow, decision, now = Date.now()) {
  const key = entityKey(flow);
  const e = touch(key, flow, now);
  const m = decision.models;
  const cls = CLASS[decision.status] || 0;
  const lstmWindow = Number.isFinite(m.lstm.window) ? m.lstm.window : null;
  const entry = { t: now, flowId: flow.flowId, cls, p: m.ensemble.probability, ratio: m.novelty.ratio,
    lstm: m.lstm.probability, lstmWindow };
  // a flow that reports again (snapshot -> final) replaces its earlier entry instead of counting twice
  const i = flow.flowId ? e.history.findIndex((h) => h.flowId === flow.flowId) : -1;
  if (i >= 0) { entry.t = e.history[i].t; e.history[i] = entry; } else { e.history.push(entry); e.flows += 1; }
  if (e.history.length > CFG.historyMax) e.history.splice(0, e.history.length - CFG.historyMax);
  e.last = now;
  e.lastLstm = { p: m.lstm.probability, window: lstmWindow, sequence: lstmWindow !== null };

  if (cls === 2 && m.ensemble.probability >= CFG.immediateProb && m.ensemble.votes >= 3) {
    e.immediateUntil = now + CFG.holdMs; e.immediateAt = now;
  }
  const out = evaluate(e, now);
  if (out.status !== e.lastStatus) {
    const up = LEVEL[out.status] > LEVEL[e.lastStatus];
    (up && out.level >= 2 ? log.warn : log.info)(`${key} ${e.lastStatus} -> ${out.status} (${out.pattern}): ${out.reason}`);
    e.lastStatus = out.status; e.statusSince = now; out.since = new Date(now).toISOString();
  }
  return out;
}

const get = (key, now = Date.now()) => { const e = entities.get(key); return e ? evaluate(e, now) : null; };

/** All entities active within the baseline horizon, most severe first. */
function list({ limit = 50, now = Date.now() } = {}) {
  const out = [];
  for (const e of entities.values()) if (now - e.last <= CFG.baselineMs) out.push(evaluate(e, now));
  out.sort((a, b) => b.level - a.level || (b.recent.suspiciousRatio || 0) - (a.recent.suspiciousRatio || 0) || b.lastSeen.localeCompare(a.lastSeen));
  return out.slice(0, limit);
}

/** Worst current status for the dashboard band. `keys` limits it to specific entities (e.g. "my activity"). */
function overview({ keys = null, now = Date.now() } = {}) {
  const rows = list({ limit: Infinity, now }).filter((r) => !keys || keys.includes(r.key));
  const counts = { normal: 0, watch: 0, possible_zero_day: 0, attack: 0 };
  for (const r of rows) counts[r.status] += 1;
  const worst = rows.reduce((w, r) => (!w || r.level > w.level ? r : w), null);
  const state = worst ? worst.status : 'normal';
  return { state, counts, entities: rows.length, worst: worst && { key: worst.key, reason: worst.reason, pattern: worst.pattern, lastSeen: worst.lastSeen } };
}

const config = () => ({ ...CFG });
const reset = () => entities.clear();

module.exports = { observe, evaluate, get, list, overview, entityKey, config, reset, CFG };
