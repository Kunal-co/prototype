'use strict';
/**
 * flow.js — capture, flow construction and feature extraction.
 *
 * WHAT IS MEASURED (and how faithfully)
 * A Node process cannot see IP packets, but it can see every TCP read and write
 * its sockets perform. A flow here is one TCP connection (5-tuple). Every socket
 * read is a forward (client -> server) burst and every socket write a backward
 * burst, each stamped with a monotonic microsecond clock. A burst of n bytes is
 * split into ceil(n / MSS) packets (MSS = 1460, FLOW_MSS) because that is iwhat the
 * wire carries; all packets of one burst share its timestamp (their true spacing
 * is unobservable, so no spacing is invented).
 *
 * Guarantees, enforced by tests/flow.test.js:
 *   1. Forward bytes == socket.bytesRead and backward bytes == socket.bytesWritten
 *      (reconciled on every request, response and close, so nothing is lost even if
 *      a read path bypasses JS events).
 *   2. Every statistic matches an independent numpy reference implementation.
 *   3. A feature that cannot be measured is NEVER invented: it is sent as null,
 *      reported as missing, and imputed with 0 by the ML worker (counted per event).
 *
 * NOT_AVAILABLE (needs TCP/IP headers): flags, header lengths, window sizes, bulk
 * transfer, min_seg_size_forward. The training script never uses them.
 *
 * Items marked VERIFY follow CICFlowMeter conventions as recalled; check them
 * against the tool that produced your CSV if you train on CICIDS2017.
 */
const fs = require('node:fs');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { performance } = require('node:perf_hooks');
const { randomUUID } = require('node:crypto');
const logger = require('./logger');
const dataset = require('./dataset');

const log = logger.child('FLOW');
const flog = logger.child('FEAT');
const { fmtBytes, fmtDurUs, fmtNum, short } = logger;

const numEnv = (name, dflt) => {
  const raw = process.env[name];
  const n = Number(raw);
  return raw !== undefined && raw !== '' && Number.isFinite(n) ? n : dflt;
};

const CFG = {
  flowTimeoutMs: numEnv('FLOW_TIMEOUT_MS', 120000),        // max flow lifetime (CICFlowMeter default, VERIFY)
  inactivityMs: numEnv('FLOW_INACTIVITY_MS', 30000),       // finalize a flow idle for this long
  activityTimeoutUs: 5000000,                              // active/idle split, 5 s (VERIFY)
  subflowGapUs: 1000000,                                   // new subflow after a 1 s gap (VERIFY)
  snapshotEveryRequests: numEnv('SNAPSHOT_EVERY_REQUESTS', 50), // early evaluation of busy flows
  snapshotEveryMs: numEnv('FLOW_SNAPSHOT_MS', 10000),      // early evaluation of long-lived flows
  maxActiveFlows: numEnv('MAX_ACTIVE_FLOWS', 5000),
  sweepMs: numEnv('FLOW_SWEEP_MS', 2000),
  mss: numEnv('FLOW_MSS', 1460),                           // TCP payload per packet on Ethernet
  rawReads: process.env.FLOW_RAW_READS !== 'false',        // see attachSocket()
};

/* ------------------------------------------------- canonical feature schema */

class ValidationError extends Error {
  constructor(message, details = []) {
    super(message);
    this.name = 'ValidationError';
    this.details = details;
  }
}

function loadSchema() {
  const file = path.join(__dirname, '..', 'ml', 'features.json');
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const features = raw.features.filter((f) => f.enabled !== false);
  const names = features.map((f) => f.name);
  if (new Set(names).size !== names.length) throw new Error('features.json has duplicate names');
  if (names.includes('Label')) throw new Error("features.json must not contain 'Label'");
  if (!names.length) throw new Error('features.json has no enabled features');
  const unavailable = features.filter((f) => f.availability === 'NOT_AVAILABLE').length;
  // Every feature this extractor can really measure, enabled or not (used by dataset capture).
  const measurable = raw.features
    .filter((f) => f.availability !== 'NOT_AVAILABLE' && !f.duplicateOf).map((f) => f.name);
  return { version: raw.schemaVersion, features, names, unavailable, measurable };
}

const SCHEMA = loadSchema();

function describeSchema() {
  return {
    version: SCHEMA.version,
    count: SCHEMA.names.length,
    unavailableLive: SCHEMA.unavailable,
    features: SCHEMA.features.map((f) => ({ name: f.name, availability: f.availability })),
  };
}

/** Manual-test input (object keyed by feature name) -> ordered vector. Strict: nothing is dropped or reordered silently. */
function manualToVector(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new ValidationError('"features" must be an object keyed by feature name');
  }
  const errors = [];
  const known = new Set(SCHEMA.names);
  for (const key of Object.keys(input)) {
    if (key === 'Label') errors.push('"Label" is the target and is not a model input');
    else if (!known.has(key)) errors.push(`Unknown feature "${key}"`);
  }
  const numRe = /^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/;
  const vector = SCHEMA.names.map((name) => {
    const v = input[name];
    if (v === undefined || v === null || v === '') { errors.push(`Missing value for "${name}"`); return null; }
    const n = typeof v === 'number' ? v : (typeof v === 'string' && numRe.test(v.trim()) ? Number(v) : NaN);
    if (!Number.isFinite(n)) { errors.push(`"${name}" must be a finite number`); return null; }
    return n;
  });
  if (errors.length) {
    throw new ValidationError(`Invalid feature input (${errors.length} problem${errors.length > 1 ? 's' : ''})`, errors.slice(0, 20));
  }
  return vector;
}

/** Feature map (name -> number|null) -> ordered vector + names that are missing. NOT_AVAILABLE is always null. */
function buildVector(map) {
  const vector = [];
  const missing = [];
  for (const feat of SCHEMA.features) {
    let v = null;
    if (feat.availability !== 'NOT_AVAILABLE') v = feat.duplicateOf ? map[feat.duplicateOf] : map[feat.name];
    if (typeof v !== 'number' || !Number.isFinite(v)) { v = null; missing.push(feat.name); }
    vector.push(v);
  }
  return { vector, missing };
}

/* --------------------------------------------------------- running stats */

class Stats {
  constructor() { this.n = 0; this.sum = 0; this.mean = 0; this.m2 = 0; this.min = Infinity; this.max = -Infinity; }
  add(x) { this.addRepeated(x, 1); }
  /** Add the value x, k times, in O(1) (parallel Welford merge of a constant block). */
  addRepeated(x, k) {
    if (!(k >= 1)) return;
    const n2 = this.n + k;
    const d = x - this.mean;
    this.mean += (d * k) / n2;
    this.m2 += (d * d * this.n * k) / n2;
    this.n = n2;
    this.sum += x * k;
    if (x < this.min) this.min = x;
    if (x > this.max) this.max = x;
  }
  clone() { return Object.assign(new Stats(), this); }
  // Empty sets report 0, the dataset convention. Std/variance use the sample (n-1) form (VERIFY).
  get meanV() { return this.n ? this.mean : 0; }
  get varV() { return this.n > 1 ? Math.max(0, this.m2 / (this.n - 1)) : 0; }
  get stdV() { return Math.sqrt(this.varV); }
  get minV() { return this.n ? this.min : 0; }
  get maxV() { return this.n ? this.max : 0; }
}

const newDirection = () => ({ count: 0, bytes: 0, dataPkts: 0, len: new Stats(), iat: new Stats(), lastT: null });
const nowUs = () => performance.now() * 1000;

/* ------------------------------------------------------------------ flow */

class Flow {
  constructor(key, ep) {
    this.id = randomUUID();
    this.key = key;
    // The endpoint given first is the forward (client) side.
    this.srcIp = ep.srcIp; this.srcPort = ep.srcPort;
    this.dstIp = ep.dstIp; this.dstPort = ep.dstPort;
    this.protocol = ep.protocol;
    this.startedAtMs = Date.now();
    this.lastWallMs = this.startedAtMs;
    this.lastReportWallMs = this.startedAtMs;
    this.firstT = null; this.lastT = null;
    this.all = new Stats();
    this.allIat = new Stats();
    this.dir = { fwd: newDirection(), bwd: newDirection() };
    this.subflows = 1;
    this.startActive = null; this.endActive = null;
    this.active = new Stats(); this.idle = new Stats();
    this.ctx = { sessionId: null, userId: null, deviceId: null, clientIp: null, label: null };
    this.httpRequests = 0;
    this.reportedRequests = 0;
    this.reportedBytes = 0;
    this.requestsSinceSnapshot = 0;
    this.dirty = false;
  }

  /**
   * Record k packets of `len` payload bytes each, all observed at time t (microseconds).
   * The first packet of the burst is spaced from the previous packet; the other k-1 follow it at the same instant.
   */
  addPackets(t, dirName, len, k = 1) {
    if (!(k >= 1)) return;
    if (this.firstT === null) {
      this.firstT = t; this.startActive = t; this.endActive = t;
    } else {
      if (t < this.lastT) t = this.lastT;                  // never let the clock run backwards
      const gap = t - this.lastT;
      this.allIat.add(gap);
      if (gap > CFG.subflowGapUs) this.subflows += 1;
      if (t - this.endActive > CFG.activityTimeoutUs) {
        if (this.endActive - this.startActive > 0) this.active.add(this.endActive - this.startActive);
        this.idle.add(t - this.endActive);
        this.startActive = t; this.endActive = t;
      } else {
        this.endActive = t;
      }
    }
    if (k > 1) this.allIat.addRepeated(0, k - 1);
    this.lastT = t;
    const d = this.dir[dirName];
    if (d.lastT !== null) d.iat.add(t - d.lastT);
    if (k > 1) d.iat.addRepeated(0, k - 1);
    d.lastT = t;
    d.count += k; d.bytes += len * k; d.len.addRepeated(len, k);
    if (len > 0) d.dataPkts += k;
    this.all.addRepeated(len, k);
    this.lastWallMs = Date.now();
    this.dirty = true;
  }
}

/** Feature name -> value. Only features that can genuinely be derived appear here. */
function computeFeatures(fl) {
  const f = fl.dir.fwd; const b = fl.dir.bwd;
  const dur = fl.lastT - fl.firstT;               // microseconds (dataset unit, VERIFY)
  const sec = dur / 1e6;
  const per = (x) => (sec > 0 ? x / sec : null);   // zero duration -> null (reported missing), never a made-up rate
  // CICFlowMeter only records an active period when it is CLOSED by an idle gap longer than the activity timeout.
  // The period still open when the flow ends is never added. In the CICIDS2017 Wednesday data this is why Active Max
  // (and Idle Max) are exactly 0 for ~80% of benign flows. Adding the trailing period made Active Max equal the
  // flow duration on every live flow, which the models had never seen (it was the biggest single driver of
  // 'possible_zero_day' on normal traffic). Keep this identical to tests/feature_reference.py.
  const act = fl.active;
  const sf = fl.subflows;
  const totalBytes = f.bytes + b.bytes;
  const totalPkts = f.count + b.count;

  return {
    'Destination Port': fl.dstPort,
    'Flow Duration': Math.round(dur),
    'Total Fwd Packets': f.count,
    'Total Backward Packets': b.count,
    'Total Length of Fwd Packets': f.bytes,
    'Total Length of Bwd Packets': b.bytes,
    'Fwd Packet Length Max': f.len.maxV, 'Fwd Packet Length Min': f.len.minV,
    'Fwd Packet Length Mean': f.len.meanV, 'Fwd Packet Length Std': f.len.stdV,
    'Bwd Packet Length Max': b.len.maxV, 'Bwd Packet Length Min': b.len.minV,
    'Bwd Packet Length Mean': b.len.meanV, 'Bwd Packet Length Std': b.len.stdV,
    'Flow Bytes/s': per(totalBytes),
    'Flow Packets/s': per(totalPkts),
    'Flow IAT Mean': fl.allIat.meanV, 'Flow IAT Std': fl.allIat.stdV,
    'Flow IAT Max': fl.allIat.maxV, 'Flow IAT Min': fl.allIat.minV,
    'Fwd IAT Total': f.iat.sum, 'Fwd IAT Mean': f.iat.meanV, 'Fwd IAT Std': f.iat.stdV,
    'Fwd IAT Max': f.iat.maxV, 'Fwd IAT Min': f.iat.minV,
    'Bwd IAT Total': b.iat.sum, 'Bwd IAT Mean': b.iat.meanV, 'Bwd IAT Std': b.iat.stdV,
    'Bwd IAT Max': b.iat.maxV, 'Bwd IAT Min': b.iat.minV,
    'Fwd Packets/s': per(f.count),
    'Bwd Packets/s': per(b.count),
    'Min Packet Length': fl.all.minV, 'Max Packet Length': fl.all.maxV,
    'Packet Length Mean': fl.all.meanV, 'Packet Length Std': fl.all.stdV,
    'Packet Length Variance': fl.all.varV,
    // CICFlowMeter divides two integer packet counts, so the dataset holds whole numbers (VERIFY).
    'Down/Up Ratio': f.count > 0 ? Math.trunc(b.count / f.count) : 0,
    'Average Packet Size': fl.all.meanV,
    'Avg Fwd Segment Size': f.len.meanV,
    'Avg Bwd Segment Size': b.len.meanV,
    'Subflow Fwd Packets': f.count / sf,                          // totals / subflow count (VERIFY)
    'Subflow Fwd Bytes': f.bytes / sf,
    'Subflow Bwd Packets': b.count / sf,
    'Subflow Bwd Bytes': b.bytes / sf,
    'act_data_pkt_fwd': f.dataPkts,
    'Active Mean': act.meanV, 'Active Std': act.stdV, 'Active Max': act.maxV, 'Active Min': act.minV,
    'Idle Mean': fl.idle.meanV, 'Idle Std': fl.idle.stdV, 'Idle Max': fl.idle.maxV, 'Idle Min': fl.idle.minV,
  };
}

/* ---------------------------------------------------------- flow registry */

const emitter = new EventEmitter(); // 'flow' -> report object
const active = new Map();           // canonical key -> Flow
let sweeper = null;

const endpoint = (ip, port) => `${ip}:${port}`;
function flowKey(p) {
  const [a, b] = [endpoint(p.srcIp, p.srcPort), endpoint(p.dstIp, p.dstPort)].sort();
  return `${a}|${b}|${p.protocol}`;
}

function logFeatures(fl, rep, featureMap) {
  const tag = rep.final ? `CLOSED(${rep.reason})` : `SNAPSHOT(${rep.reason})`;
  const f = fl.dir.fwd; const b = fl.dir.bwd;
  flog.info(
    `flow ${short(fl.id)} ${tag} ${rep.sourceIp}:${rep.sourcePort} -> ${rep.destIp}:${rep.destPort} `
    + `| req=${rep.requests} fwd=${f.count}p/${fmtBytes(f.bytes)} bwd=${b.count}p/${fmtBytes(b.bytes)} `
    + `dur=${fmtDurUs(rep.durationUs)} | ${SCHEMA.names.length} model features, ${rep.missing.length} missing`
    + `${rep.missing.length ? ` (${rep.missing.join(', ')})` : ''}`,
  );
  if (logger.FULL_FEATURES) {
    const lines = SCHEMA.names.map((n, i) => `      ${n.padEnd(30)} ${rep.vector[i] === null ? 'null (missing)' : fmtNum(rep.vector[i])}`);
    flog.info(`flow ${short(fl.id)} model-input vector:\n${lines.join('\n')}`);
  } else if (featureMap) {
    flog.debug(`flow ${short(fl.id)} key features: Flow Duration=${fmtNum(featureMap['Flow Duration'])}us `
      + `Flow Bytes/s=${fmtNum(featureMap['Flow Bytes/s'])} Flow Packets/s=${fmtNum(featureMap['Flow Packets/s'])} `
      + `Flow IAT Mean=${fmtNum(featureMap['Flow IAT Mean'])} Packet Length Mean=${fmtNum(featureMap['Packet Length Mean'])}`);
  }
}

function report(fl, reason, final) {
  if (fl.all.n === 0) return; // nothing observed yet: no features exist
  const featureMap = computeFeatures(fl);
  const { vector, missing } = buildVector(featureMap);
  const requestsDelta = fl.httpRequests - fl.reportedRequests;
  fl.reportedRequests = fl.httpRequests;
  const bytesNow = fl.dir.fwd.bytes + fl.dir.bwd.bytes;
  const bytesDelta = bytesNow - fl.reportedBytes;
  fl.reportedBytes = bytesNow;
  fl.dirty = false;
  fl.requestsSinceSnapshot = 0;
  fl.lastReportWallMs = Date.now();
  const rep = {
    flowId: fl.id, reason, final,
    sessionId: fl.ctx.sessionId, userId: fl.ctx.userId, deviceId: fl.ctx.deviceId,
    // The real client address (behind a trusted proxy it differs from the TCP peer).
    sourceIp: fl.ctx.clientIp || fl.srcIp, sourcePort: fl.srcPort,
    destIp: fl.dstIp, destPort: fl.dstPort, protocol: fl.protocol,
    startedAtMs: fl.startedAtMs, endedAtMs: fl.lastWallMs,
    durationUs: Math.round(fl.lastT - fl.firstT),
    requests: fl.httpRequests, requestsDelta,
    packetsFwd: fl.dir.fwd.count, packetsBwd: fl.dir.bwd.count,
    bytesFwd: fl.dir.fwd.bytes, bytesBwd: fl.dir.bwd.bytes,
    totalBytes: bytesNow, bytesDelta,
    vector, missing,
    features: featureMap, // every measurable feature (enabled or not)
  };
  logFeatures(fl, rep, featureMap);
  if (dataset.enabled()) {
    dataset.append({ label: dataset.resolveLabel(fl.srcIp, fl.ctx.label), rep, features: featureMap });
  }
  emitter.emit('flow', rep);
}

function finalize(fl, reason) {
  if (active.get(fl.key) !== fl) return;
  active.delete(fl.key);
  log.info(`flow ${short(fl.id)} finalized (${reason}) after ${fl.httpRequests} request(s); ${active.size} flow(s) still open`);
  report(fl, reason, true);
}

function getOrCreateFlow(key, ep, tUs) {
  let fl = active.get(key);
  if (fl && fl.firstT !== null && (tUs - fl.firstT) / 1000 > CFG.flowTimeoutMs) { finalize(fl, 'timeout'); fl = null; }
  if (!fl) {
    if (active.size >= CFG.maxActiveFlows) {
      const oldest = active.values().next().value;
      if (oldest) finalize(oldest, 'evicted');
    }
    fl = new Flow(key, ep);
    active.set(key, fl);
    log.info(`flow ${short(fl.id)} opened ${fl.srcIp}:${fl.srcPort} -> ${fl.dstIp}:${fl.dstPort} (${active.size} open)`);
  }
  return fl;
}

/**
 * Ingest ONE packet-like event (also the entry point for feeding a real packet capture).
 * pkt: { srcIp, srcPort, dstIp, dstPort, protocol, t (microseconds), len, ctx? }
 * Returns the canonical flow key.
 */
function ingestPacket(pkt) {
  const key = flowKey(pkt);
  const fl = getOrCreateFlow(key, pkt, pkt.t);
  const dirName = pkt.srcIp === fl.srcIp && pkt.srcPort === fl.srcPort ? 'fwd' : 'bwd';
  if (pkt.ctx) for (const k of Object.keys(fl.ctx)) if (pkt.ctx[k]) fl.ctx[k] = pkt.ctx[k];
  fl.addPackets(pkt.t, dirName, pkt.len, 1);
  return key;
}

/** Ingest a burst of `bytes` TCP payload bytes, split into MSS-sized packets. `fwd` = client -> server. */
function ingestBytes(st, dirName, bytes, tUs) {
  if (!(bytes > 0)) return;
  const fl = getOrCreateFlow(st.key, st.ep, tUs);
  const mss = CFG.mss;
  if (mss > 0 && bytes > mss) {
    const full = Math.floor(bytes / mss);
    const rem = bytes - full * mss;
    fl.addPackets(tUs, dirName, mss, full);
    if (rem > 0) fl.addPackets(tUs, dirName, rem, 1);
  } else {
    fl.addPackets(tUs, dirName, bytes, 1);
  }
}

/* ----------------------------------------------------------- socket capture */

const socketState = new WeakMap(); // socket -> { ep, key, readSeen, writtenSeen, closed }

const normalizeIp = (a) => String(a || 'unknown').replace(/^::ffff:/, '');
const chunkBytes = (chunk, enc) => {
  if (chunk == null) return 0;
  if (typeof chunk === 'string') return Buffer.byteLength(chunk, typeof enc === 'string' ? enc : 'utf8');
  return chunk.length >>> 0;
};

/**
 * Start measuring a TCP connection. Register with
 *   server.prependListener('connection', flow.attachSocket)
 * so it runs before Node's HTTP layer. By default Node hands the raw socket straight to its C++
 * HTTP parser, which hides individual reads from JavaScript. Marking the handle as already
 * consumed makes Node fall back to normal 'data' events, which lets us see each read and its
 * timing (e.g. a client trickling bytes). This touches an internal flag, so it is guarded: if it
 * has no effect, reads are still counted exactly through bytesRead reconciliation, only with
 * coarser timing. Disable with FLOW_RAW_READS=false.
 */
function attachSocket(sock) {
  let st = socketState.get(sock);
  if (st) return st;
  const ep = {
    srcIp: normalizeIp(sock.remoteAddress), srcPort: sock.remotePort,
    dstIp: normalizeIp(sock.localAddress), dstPort: sock.localPort, protocol: 'TCP',
  };
  st = { ep, key: flowKey(ep), readSeen: 0, writtenSeen: 0, closed: false, sock, rawReads: false };
  socketState.set(sock, st);

  if (CFG.rawReads) {
    try {
      if (sock._handle && !sock._handle._consumed) sock._handle._consumed = true;
      sock.on('data', (chunk) => {
        st.rawReads = true;
        const n = chunk.length;
        st.readSeen += n;
        ingestBytes(st, 'fwd', n, nowUs());
      });
    } catch (err) {
      log.warn(`raw read capture unavailable (${err.message}); using byte-count reconciliation only`);
    }
  }

  const origWrite = sock.write;
  sock.write = function patchedWrite(chunk, encoding) {
    try {
      if (!this.destroyed && this.writable) {
        const n = chunkBytes(chunk, encoding);
        if (n > 0) { st.writtenSeen += n; ingestBytes(st, 'bwd', n, nowUs()); }
      }
    } catch (err) { log.error(`write capture error: ${err.message}`); }
    return origWrite.apply(this, arguments);
  };

  sock.once('close', () => {
    try { reconcile(st); } catch (err) { log.error(`close reconcile error: ${err.message}`); }
    st.closed = true;
    const fl = active.get(st.key);
    if (fl) finalize(fl, 'closed');
  });
  log.debug(`socket ${st.key} attached`);
  return st;
}

/** Make the flow's byte totals equal the kernel counters; any bytes no event reported are added now. */
function reconcile(st) {
  const t = nowUs();
  const missedRead = st.sock.bytesRead - st.readSeen;
  if (missedRead > 0) { st.readSeen += missedRead; ingestBytes(st, 'fwd', missedRead, t); }
  const missedWrite = st.sock.bytesWritten - st.writtenSeen;
  if (missedWrite > 0) { st.writtenSeen += missedWrite; ingestBytes(st, 'bwd', missedWrite, t); }
}

/** Express middleware. Must run after auth.middleware so req.ng is populated. */
function captureMiddleware(req, res, next) {
  const sock = req.socket;
  const st = attachSocket(sock);
  try {
    reconcile(st);
    const fl = getOrCreateFlow(st.key, st.ep, nowUs());
    if (req.ng) for (const k of ['sessionId', 'userId', 'deviceId']) if (req.ng[k]) fl.ctx[k] = req.ng[k];
    // Real client address: Cloudflare's header first, then the address auth.js resolved. Normalised and capped because
    // it becomes the flow's sourceIp (events, blocklist) and predict.py rejects identifiers longer than 64 characters.
    const cip = req.headers['cf-connecting-ip'] || (req.ng && req.ng.ip) || null;
    fl.ctx.clientIp = cip ? normalizeIp(String(cip).trim()).slice(0, 64) : null;
    if (dataset.enabled() && req.headers['x-ng-label']) fl.ctx.label = String(req.headers['x-ng-label']);
    fl.httpRequests += 1;
    fl.requestsSinceSnapshot += 1;
  } catch (err) {
    log.error(`capture error: ${err.message}`);
  }

  res.once('close', () => {
    try {
      reconcile(st);
      const fl = active.get(st.key);
      if (fl && fl.requestsSinceSnapshot >= CFG.snapshotEveryRequests) report(fl, 'snapshot', false);
    } catch (err) {
      log.error(`capture error: ${err.message}`);
    }
  });
  next();
}

/* --------------------------------------------------------------- lifecycle */

function sweep() {
  const now = Date.now();
  for (const fl of [...active.values()]) {
    if (now - fl.lastWallMs > CFG.inactivityMs) finalize(fl, 'inactivity');
    else if (now - fl.startedAtMs > CFG.flowTimeoutMs) finalize(fl, 'timeout');
    else if (fl.dirty && now - fl.lastReportWallMs >= CFG.snapshotEveryMs) report(fl, 'snapshot', false);
  }
}

function start() {
  if (sweeper) return;
  dataset.init(SCHEMA.measurable);
  sweeper = setInterval(sweep, CFG.sweepMs);
  sweeper.unref();
  log.info(`flow engine ready: MSS=${CFG.mss}, inactivity=${CFG.inactivityMs}ms, lifetime=${CFG.flowTimeoutMs}ms, `
    + `snapshot every ${CFG.snapshotEveryRequests} requests or ${CFG.snapshotEveryMs}ms, raw reads ${CFG.rawReads ? 'on' : 'off'}`);
}

function finalizeSession(sessionId, reason = 'session_end') {
  let n = 0;
  for (const fl of [...active.values()]) {
    if (fl.ctx.sessionId === sessionId) { finalize(fl, reason); n += 1; }
  }
  return n;
}

function shutdown() {
  if (sweeper) clearInterval(sweeper);
  sweeper = null;
  for (const fl of [...active.values()]) finalize(fl, 'shutdown');
  dataset.close();
}

module.exports = {
  events: emitter, SCHEMA, ValidationError, describeSchema, manualToVector, buildVector,
  ingestPacket, attachSocket, captureMiddleware, finalizeSession, shutdown, start,
  activeCount: () => active.size,
  _internals: { Flow, Stats, computeFeatures, CFG },
};
