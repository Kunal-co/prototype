'use strict';
/**
 * db.js — the ONLY module that talks to the database.
 *
 * Uses Node's built-in `node:sqlite` (no native package to compile).
 * It is still flagged experimental in some Node releases and prints a one-line
 * ExperimentalWarning; this is expected. Timestamps are stored as epoch
 * milliseconds (UTC) everywhere.
 */
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const log = require('./logger').child('DB');

const DB_PATH = process.env.NETGUARD_DB || path.join(__dirname, '..', 'data', 'events.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA synchronous = NORMAL;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id         TEXT PRIMARY KEY,
  username   TEXT NOT NULL UNIQUE COLLATE NOCASE,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
  id              TEXT PRIMARY KEY,
  user_id         TEXT,
  session_id      TEXT,
  device_id       TEXT,
  agg_key         TEXT,
  source_ip       TEXT,
  dest_ip         TEXT,
  source_port     INTEGER,
  dest_port       INTEGER,
  protocol        TEXT,
  status          TEXT NOT NULL CHECK (status IN ('normal','attack','possible_zero_day')),
  severity        TEXT NOT NULL,
  confidence      REAL NOT NULL,
  reason          TEXT,
  xgb_label       TEXT,   -- legacy (XGBoost prototype); unused by new rows
  xgb_confidence  REAL,   -- legacy
  if_label        TEXT,   -- legacy (Isolation Forest prototype)
  if_score        REAL,   -- legacy
  first_seen      INTEGER NOT NULL,
  last_seen       INTEGER NOT NULL,
  request_count   INTEGER NOT NULL DEFAULT 0,
  detection_count INTEGER NOT NULL DEFAULT 1,
  total_bytes     INTEGER NOT NULL DEFAULT 0,
  missing_features INTEGER NOT NULL DEFAULT 0,
  flow_info       TEXT,
  cnn_prob        REAL,
  fcnn_prob       REAL,
  lstm_prob       REAL,
  ensemble_prob   REAL,
  votes           INTEGER,
  novelty_score   REAL,
  novelty_ratio   REAL,
  novelty_flag    INTEGER NOT NULL DEFAULT 0,
  drift_active    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_events_last_seen ON events(last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_events_user      ON events(user_id, last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_events_agg       ON events(agg_key, status, last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_events_status    ON events(status, last_seen DESC);

CREATE TABLE IF NOT EXISTS blocks (
  id         TEXT PRIMARY KEY,
  user_id    TEXT,
  session_id TEXT,
  device_id  TEXT,
  ip         TEXT,
  event_id   TEXT,
  reason     TEXT,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  active     INTEGER NOT NULL DEFAULT 1,
  lifted_at  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_blocks_active ON blocks(active, expires_at);
`);

/* Additive migration: databases written by the XGBoost/Isolation-Forest prototype keep working.
   Their xgb_* / if_* columns stay (legacy, read-only); the neural-network columns are added. */
function ensureColumn(table, column, ddl) {
  const have = db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column);
  if (!have) { db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`); log.info(`migrated: ${table}.${column} added`); }
}
for (const [col, ddl] of [
  ['cnn_prob', 'REAL'], ['fcnn_prob', 'REAL'], ['lstm_prob', 'REAL'], ['ensemble_prob', 'REAL'],
  ['votes', 'INTEGER'], ['novelty_score', 'REAL'], ['novelty_ratio', 'REAL'],
  ['novelty_flag', 'INTEGER NOT NULL DEFAULT 0'], ['drift_active', 'INTEGER NOT NULL DEFAULT 0'],
]) ensureColumn('events', col, ddl);

db.exec(`
CREATE TABLE IF NOT EXISTS drift_events (
  id           TEXT PRIMARY KEY,
  detected_at  INTEGER NOT NULL,
  stream       TEXT NOT NULL,
  kind         TEXT NOT NULL,
  level        TEXT NOT NULL,
  message      TEXT,
  mean_before  REAL,
  mean_after   REAL,
  window       INTEGER,
  observations INTEGER,
  details      TEXT
);
CREATE INDEX IF NOT EXISTS idx_drift_time ON drift_events(detected_at DESC);
`);
log.info(`database ready at ${DB_PATH}`);

/* ------------------------------------------------------------------ users */

function upsertUser(username) {
  const existing = db.prepare('SELECT id, username FROM users WHERE username = ?').get(username);
  if (existing) return { id: existing.id, username: existing.username };
  const user = { id: randomUUID(), username };
  db.prepare('INSERT INTO users (id, username, created_at) VALUES (?, ?, ?)')
    .run(user.id, user.username, Date.now());
  return user;
}

/* ----------------------------------------------------------------- events */

function saveEvent(e) {
  db.prepare(`
    INSERT INTO events (id, user_id, session_id, device_id, agg_key, source_ip, dest_ip, source_port,
      dest_port, protocol, status, severity, confidence, reason,
      cnn_prob, fcnn_prob, lstm_prob, ensemble_prob, votes, novelty_score, novelty_ratio, novelty_flag, drift_active,
      first_seen, last_seen, request_count, detection_count, total_bytes, missing_features, flow_info)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    e.id, e.userId ?? null, e.sessionId ?? null, e.deviceId ?? null, e.aggKey ?? null,
    e.sourceIp ?? null, e.destIp ?? null, e.sourcePort ?? null, e.destPort ?? null, e.protocol ?? null,
    e.status, e.severity, e.confidence, e.reason ?? null,
    e.cnnProb ?? null, e.fcnnProb ?? null, e.lstmProb ?? null, e.ensembleProb ?? null, e.votes ?? null,
    e.noveltyScore ?? null, e.noveltyRatio ?? null, e.noveltyFlag ? 1 : 0, e.driftActive ? 1 : 0,
    e.firstSeen, e.lastSeen, e.requestCount ?? 0,
    e.detectionCount ?? 1, e.totalBytes ?? 0, e.missingFeatures ?? 0, e.flowInfo ?? null);
  return e.id;
}

/** Merge a new detection into an existing (aggregated) event. */
function updateEvent(id, p) {
  db.prepare(`
    UPDATE events SET
      last_seen = ?, request_count = request_count + ?, detection_count = detection_count + 1,
      total_bytes = total_bytes + ?, confidence = MAX(confidence, ?), severity = ?, reason = ?,
      cnn_prob = ?, fcnn_prob = ?, lstm_prob = ?, ensemble_prob = ?, votes = ?,
      novelty_score = ?, novelty_ratio = ?, novelty_flag = ?, drift_active = MAX(drift_active, ?),
      missing_features = ?, flow_info = ?, user_id = COALESCE(?, user_id), session_id = ?, device_id = ?
    WHERE id = ?`).run(
    p.lastSeen, p.addRequests, p.addBytes, p.confidence, p.severity, p.reason ?? null,
    p.cnnProb ?? null, p.fcnnProb ?? null, p.lstmProb ?? null, p.ensembleProb ?? null, p.votes ?? null,
    p.noveltyScore ?? null, p.noveltyRatio ?? null, p.noveltyFlag ? 1 : 0, p.driftActive ? 1 : 0,
    p.missingFeatures ?? 0, p.flowInfo ?? null, p.userId ?? null, p.sessionId ?? null,
    p.deviceId ?? null, id);
}

function getEvent(id) {
  return db.prepare('SELECT * FROM events WHERE id = ?').get(id) || null;
}

function findOpenEvent(aggKey, status, since) {
  return db.prepare(`SELECT * FROM events WHERE agg_key = ? AND status = ? AND last_seen >= ?
                     ORDER BY last_seen DESC LIMIT 1`).get(aggKey, status, since) || null;
}

function getRecentEvents({ limit = 20, offset = 0, userId = null } = {}) {
  const total = db.prepare('SELECT COUNT(*) AS c FROM events WHERE (? IS NULL OR user_id = ?)')
    .get(userId, userId).c;
  const rows = db.prepare(`SELECT * FROM events WHERE (? IS NULL OR user_id = ?)
                           ORDER BY last_seen DESC, id LIMIT ? OFFSET ?`)
    .all(userId, userId, limit, offset);
  return { rows, total };
}

function getUserEvents(userId, limit = 20, offset = 0) {
  return getRecentEvents({ limit, offset, userId });
}

function getDashboardStats({ userId = null, threatSince = 0 } = {}) {
  const s = db.prepare(`
    SELECT COUNT(*) AS total,
           COALESCE(SUM(request_count), 0) AS requests,
           COALESCE(SUM(status = 'attack'), 0) AS attacks,
           COALESCE(SUM(status = 'possible_zero_day'), 0) AS zero_days,
           COALESCE(SUM(novelty_flag = 1 OR if_label = 'anomaly'), 0) AS anomalies,
           COALESCE(SUM(CASE WHEN status = 'attack' THEN request_count END), 0) AS attack_requests
    FROM events WHERE (? IS NULL OR user_id = ?)`).get(userId, userId);
  const t = db.prepare(`
    SELECT COALESCE(SUM(status = 'attack'), 0) AS attacks,
           COALESCE(SUM(status = 'possible_zero_day'), 0) AS zero_days,
           MAX(CASE WHEN status != 'normal' THEN last_seen END) AS last_threat
    FROM events WHERE last_seen >= ? AND (? IS NULL OR user_id = ?)`).get(threatSince, userId, userId);
  return {
    totalActivity: s.total, totalRequests: s.requests, attacks: s.attacks,
    anomalies: s.anomalies, possibleZeroDays: s.zero_days, attackRequests: s.attack_requests,
    recent: { attacks: t.attacks, possibleZeroDays: t.zero_days, lastThreat: t.last_threat },
  };
}

function getAttackers(limit = 50) {
  return db.prepare(`
    SELECT e.agg_key AS agg_key, MAX(e.user_id) AS user_id, MAX(u.username) AS username,
           MAX(e.source_ip) AS source_ip, MAX(e.device_id) AS device_id,
           COUNT(*) AS events, SUM(e.request_count) AS requests, MAX(e.confidence) AS max_confidence,
           MIN(e.first_seen) AS first_seen, MAX(e.last_seen) AS last_seen,
           MAX(CASE e.status WHEN 'attack' THEN 2 ELSE 1 END) AS worst,
           (SELECT e2.id FROM events e2 WHERE e2.agg_key = e.agg_key AND e2.status != 'normal'
              ORDER BY e2.last_seen DESC LIMIT 1) AS latest_event_id
    FROM events e LEFT JOIN users u ON u.id = e.user_id
    WHERE e.status != 'normal' AND e.agg_key IS NOT NULL
    GROUP BY e.agg_key ORDER BY last_seen DESC LIMIT ?`).all(limit);
}

/* ------------------------------------------------------------------ drift */

function addDriftEvent(d) {
  const id = randomUUID();
  db.prepare(`INSERT INTO drift_events (id, detected_at, stream, kind, level, message, mean_before, mean_after,
                                        window, observations, details) VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
    id, d.detectedAt, d.stream, d.kind, d.level, d.message ?? null, d.meanBefore ?? null, d.meanAfter ?? null,
    d.window ?? null, d.observations ?? null, d.features ? JSON.stringify(d.features) : null);
  return id;
}

function getDriftEvents(limit = 50) {
  return db.prepare('SELECT * FROM drift_events ORDER BY detected_at DESC LIMIT ?').all(limit);
}

/** Events per time bucket and status, for the dashboard timeline. */
function getTimeline({ since, bucketMs, userId = null }) {
  return db.prepare(`
    SELECT CAST(last_seen / ? AS INTEGER) * ? AS bucket, status, COUNT(*) AS n
    FROM events WHERE last_seen >= ? AND (? IS NULL OR user_id = ?)
    GROUP BY bucket, status ORDER BY bucket`).all(bucketMs, bucketMs, since, userId, userId);
}

/* ----------------------------------------------------------------- blocks */

function addBlock(b) {
  const id = randomUUID();
  db.prepare(`INSERT INTO blocks (id, user_id, session_id, device_id, ip, event_id, reason, created_at, expires_at)
              VALUES (?,?,?,?,?,?,?,?,?)`).run(
    id, b.userId ?? null, b.sessionId ?? null, b.deviceId ?? null, b.ip ?? null,
    b.eventId ?? null, b.reason ?? null, b.createdAt, b.expiresAt);
  return id;
}

function hasActiveBlockForEvent(eventId, now) {
  return !!db.prepare('SELECT 1 FROM blocks WHERE event_id = ? AND active = 1 AND expires_at > ? LIMIT 1')
    .get(eventId, now);
}

/**
 * identity: { userId, sessionId, deviceId, ip, ipEligible }
 * IP only participates when ipEligible is true (see blocklist.js) so one shared
 * address never blocks every user behind it.
 */
function isBlocked(identity, now = Date.now()) {
  return db.prepare(`
    SELECT * FROM blocks WHERE active = 1 AND expires_at > ? AND (
         (user_id    IS NOT NULL AND user_id    = ?)
      OR (device_id  IS NOT NULL AND device_id  = ?)
      OR (session_id IS NOT NULL AND session_id = ?)
      OR (? = 1 AND ip IS NOT NULL AND ip = ?)
    ) LIMIT 1`).get(now, identity.userId ?? null, identity.deviceId ?? null,
    identity.sessionId ?? null, identity.ipEligible ? 1 : 0, identity.ip ?? null) || null;
}

function getBlocks(limit = 100) {
  return db.prepare('SELECT * FROM blocks ORDER BY created_at DESC LIMIT ?').all(limit);
}

function liftBlock(id, now = Date.now()) {
  return db.prepare('UPDATE blocks SET active = 0, lifted_at = ? WHERE id = ? AND active = 1')
    .run(now, id).changes > 0;
}

function close() {
  try { db.close(); } catch { /* already closed */ }
}

module.exports = {
  upsertUser, saveEvent, updateEvent, getEvent, findOpenEvent, getRecentEvents, getUserEvents,
  getDashboardStats, getAttackers, addBlock, hasActiveBlockForEvent, isBlocked, getBlocks,
  addDriftEvent, getDriftEvents, getTimeline, liftBlock, close, DB_PATH,
};
