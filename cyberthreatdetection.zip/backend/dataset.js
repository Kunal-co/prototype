'use strict';
/**
 * dataset.js — optional labelled capture of everything flow.js measures.
 *
 * Why this exists: models score best when trained on features produced by the
 * SAME extractor that feeds them at run time. Starting the server with
 *
 *   CAPTURE_DATASET=data/captured_flows.csv  CAPTURE_LABEL_MAP="127.0.0.2=http_flood"
 *
 * appends one CSV row per scored flow report (all measurable features, not only
 * the ones currently enabled) so `python ml/train.py --source captured` can
 * train on it. Disabled unless CAPTURE_DATASET is set.
 *
 * Labels: a flow is "benign" unless its client address appears in
 * CAPTURE_LABEL_MAP ("ip=label,ip=label") or a request carried the header
 * X-NG-Label (only honoured while capture is on).
 */
const fs = require('node:fs');
const path = require('node:path');
const log = require('./logger').child('DATA');

const FILE = process.env.CAPTURE_DATASET || '';
const LABEL_MAP = new Map(
  String(process.env.CAPTURE_LABEL_MAP || '').split(',').map((s) => s.trim()).filter(Boolean)
    .map((pair) => pair.split('=').map((x) => x.trim())).filter((p) => p.length === 2 && p[0] && p[1]),
);

let out = null;
let columns = null;
let rows = 0;

const enabled = () => FILE !== '';

function init(featureNames) {
  if (!enabled() || out) return;
  columns = featureNames;
  fs.mkdirSync(path.dirname(path.resolve(FILE)), { recursive: true });
  const header = ['label', 'final', 'reason', 'flow_id', 'ts_ms', 'requests', 'src_ip', 'started_ms', ...columns].join(',');
  let exists = fs.existsSync(FILE) && fs.statSync(FILE).size > 0;
  if (exists) {
    // src_ip / started_ms feed the per-IP sequence LSTM. A file written without them cannot be appended to
    // (columns would misalign), so it is kept aside untouched and a new file is started.
    const first = fs.readFileSync(FILE, 'utf8').split('\n', 1)[0].trim();
    if (first !== header) {
      const aside = `${FILE}.${Date.now()}.old`;
      fs.renameSync(FILE, aside);
      log.warn(`existing ${FILE} has a different column layout; moved to ${aside}, starting a new file`);
      exists = false;
    }
  }
  out = fs.createWriteStream(FILE, { flags: 'a' });
  if (!exists) out.write(`${header}\n`);
  log.info(`dataset capture ON -> ${FILE} (${columns.length} feature columns, ${LABEL_MAP.size} labelled sources)`);
}

function resolveLabel(srcIp, headerLabel) {
  if (headerLabel && /^[a-z0-9_\-]{1,32}$/i.test(headerLabel)) return headerLabel;
  return LABEL_MAP.get(srcIp) || 'benign';
}

/** @param {{label:string, rep:object, features:Object<string,number|null>}} p */
function append({ label, rep, features }) {
  if (!out) return;
  const cells = columns.map((n) => {
    const v = features[n];
    return typeof v === 'number' && Number.isFinite(v) ? String(v) : '';
  });
  out.write(`${[label, rep.final ? 1 : 0, rep.reason, rep.flowId, Date.now(), rep.requests, rep.sourceIp, rep.startedAtMs, ...cells].join(',')}\n`);
  rows += 1;
  if (rows % 500 === 0) log.info(`dataset capture: ${rows} rows written`);
}

function close() {
  if (out) { out.end(); log.info(`dataset capture closed (${rows} rows)`); out = null; }
}

module.exports = { enabled, init, append, resolveLabel, close };
