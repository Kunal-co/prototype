'use strict';
/**
 * decision.js — turns the neural-network outputs into one verdict.
 * Pure and deterministic: no I/O, no training. The returned object is a stable API contract.
 *
 *   ensemble (mean of CNN, FCNN, LSTM) says attack            -> attack            (severity high)
 *   ensemble says normal + autoencoder says "never seen this" -> possible_zero_day (severity critical)
 *   ensemble says normal + autoencoder is satisfied           -> normal            (severity low)
 *
 * confidence
 *   attack            the ensemble's probability of attack
 *   normal            the ensemble's probability of normal
 *   possible_zero_day 0.5 at the novelty threshold, approaching 1 as the reconstruction error grows
 *                     (0.5 + 0.5 * (1 - threshold/error)); it measures how unusual the flow is, not a class probability
 *
 * The LSTM reads the last few flows of the SAME source IP (see ml/predict.py), so its vote reflects how that
 * address has been behaving over time. When it votes attack on a multi-flow window the reason says so.
 *
 * When the drift monitor has an active alert, the reason says so: the models may be out of date.
 */
const MODELS = ['cnn', 'fcnn', 'lstm'];

function assertShape(r) {
  const finite = (x) => typeof x === 'number' && Number.isFinite(x);
  const ok = r && r.models && MODELS.every((m) => r.models[m] && finite(r.models[m].probability))
    && r.ensemble && ['normal', 'attack'].includes(r.ensemble.label) && finite(r.ensemble.probability)
    && r.novelty && finite(r.novelty.score) && finite(r.novelty.ratio) && typeof r.novelty.flag === 'boolean';
  if (!ok) throw new TypeError('Prediction result does not match the expected schema');
}

const labelOf = (p) => (p >= 0.5 ? 'attack' : 'normal');
const round = (x, d = 4) => Math.round(x * 10 ** d) / 10 ** d;

function decide(result, { driftActive = false } = {}) {
  assertShape(result);
  const e = result.ensemble;
  const n = result.novelty;

  let status; let severity; let reason; let confidence;
  if (e.label === 'attack') {
    status = 'attack';
    severity = 'high';
    confidence = e.probability;
    reason = `Known attack pattern: ${e.votes} of ${MODELS.length} models agree`
      + (n.flag ? ' (also unlike normal traffic)' : '');
    const w = result.models.lstm.window;
    if (w > 1 && result.models.lstm.probability >= 0.5) reason += `; this source's behaviour over its last ${w} flows looks hostile`;
  } else if (n.flag) {
    status = 'possible_zero_day';
    severity = 'critical';
    confidence = round(0.5 + 0.5 * (1 - 1 / n.ratio));
    reason = `Traffic does not resemble learned normal behavior (error ${round(n.ratio, 2)}x the threshold)`;
  } else {
    status = 'normal';
    severity = 'low';
    confidence = round(1 - e.probability, 6);
    reason = 'Traffic appears normal';
  }
  if (driftActive) reason += '. Model drift is suspected, so treat this verdict with caution';

  const model = (m) => ({
    label: labelOf(result.models[m].probability), probability: result.models[m].probability,
    ...(Number.isFinite(result.models[m].window) ? { window: result.models[m].window } : {}), // flows in the LSTM's per-IP window
  });
  return {
    status,
    severity,
    confidence,
    reason,
    driftActive: Boolean(driftActive),
    models: {
      cnn: model('cnn'),
      fcnn: model('fcnn'),
      lstm: model('lstm'),
      ensemble: { label: e.label, probability: e.probability, votes: e.votes, disagreement: e.disagreement },
      novelty: { flag: n.flag, score: n.score, threshold: n.threshold, ratio: n.ratio },
    },
  };
}

module.exports = { decide };
