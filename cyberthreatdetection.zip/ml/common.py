"""
Shared helpers for train.py, predict.py and drift_demo.py.

Everything that must be IDENTICAL between training and live scoring lives here:
the feature schema, the preprocessing (signed log1p then z-score) and the artifact layout.
"""
import json
import os
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ARTIFACT_DIR = Path(os.environ.get("NETGUARD_MODEL_DIR", HERE / "artifacts"))
SCHEMA_PATH = HERE / "features.json"

MODEL_FILES = {
    "cnn": "cnn.keras",
    "fcnn": "fcnn.keras",
    "lstm": "lstm.keras",
    "autoencoder": "autoencoder.keras",
}
MAX_ABS_VALUE = 1.0e15   # anything larger is a bug upstream, not traffic
Z_CLIP = 8.0             # standardised values are clipped to +-8 sigma so one huge value cannot dominate


def quiet_tensorflow():
    """Keep TensorFlow's chatter off stdout and out of the way. Call BEFORE importing tensorflow/keras."""
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
    os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
    os.environ.setdefault("KERAS_BACKEND", "tensorflow")


def load_schema(path=SCHEMA_PATH):
    """Returns (all_entries, enabled_names). Order in the file is canonical."""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    entries = raw["features"]
    names = [f["name"] for f in entries if f.get("enabled", True)]
    if "Label" in names:
        raise ValueError("features.json must not contain 'Label' (it is the target, not an input)")
    if len(set(names)) != len(names):
        raise ValueError("features.json contains duplicate feature names")
    return entries, names


def measurable_names(entries):
    """Features the Node extractor can really compute (never the NOT_AVAILABLE ones)."""
    return [f["name"] for f in entries if f["availability"] != "NOT_AVAILABLE" and not f.get("duplicateOf")]


def signed_log1p(x):
    x = np.asarray(x, dtype=np.float64)
    return np.sign(x) * np.log1p(np.abs(x))


class Preprocessor:
    """signed log1p -> z-score -> clip. Stores only plain numbers, never pickles."""

    def __init__(self, names, mean, std):
        self.names = list(names)
        self.mean = np.asarray(mean, dtype=np.float64)
        self.std = np.asarray(std, dtype=np.float64)

    @classmethod
    def fit(cls, names, X):
        T = signed_log1p(X)
        mean = T.mean(axis=0)
        std = T.std(axis=0)
        std = np.where(std < 1e-6, 1.0, std)  # constant column: leave centred, do not blow up
        return cls(names, mean, std)

    def transform(self, X):
        X = np.asarray(X, dtype=np.float64)
        if X.ndim == 1:
            X = X[None, :]
        z = (signed_log1p(X) - self.mean) / self.std
        return np.clip(z, -Z_CLIP, Z_CLIP).astype(np.float32)

    def to_dict(self):
        return {"names": self.names, "mean": self.mean.tolist(), "std": self.std.tolist(),
                "transform": "signed_log1p then (x-mean)/std, clipped to +-%s" % Z_CLIP}

    @classmethod
    def from_dict(cls, d):
        return cls(d["names"], d["mean"], d["std"])


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False), encoding="utf-8")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


# ------------------------------------------------------------ per-IP sequences
# The LSTM reads the last SEQ_LEN flows of ONE source IP in time order. Each step is
#   [ z-scored flow features (same schema, same preprocessing as CNN/FCNN) | gap | valid ]
# gap   = log1p(seconds since the previous flow of this IP began), clipped; 0 for the first flow
# valid = 1 for a real flow, 0 for left padding when the IP has fewer than SEQ_LEN flows so far
# Training (train.py) and live scoring (predict.py) both build windows ONLY through make_window,
# so the two cannot drift apart.
SEQ_LEN = 10
GAP_CLIP = 10.0


def step_dim(n_features):
    return n_features + 2


def gap_feature(seconds):
    return np.clip(np.log1p(np.maximum(np.asarray(seconds, dtype=np.float64), 0.0)), 0.0, GAP_CLIP)


def make_window(z_rows, t_seconds, seq_len=SEQ_LEN):
    """z_rows: (k, n) standardised flows of one IP in chronological order (k >= 1), t_seconds: (k,) their start times.
    Returns the (seq_len, n + 2) window ending at the LAST row (older rows are cut, missing ones are zero padded)."""
    z_rows = np.asarray(z_rows, dtype=np.float32)[-seq_len:]
    t = np.asarray(t_seconds, dtype=np.float64)[-seq_len:]
    k, n = z_rows.shape
    win = np.zeros((seq_len, n + 2), dtype=np.float32)
    gaps = np.zeros(k)
    if k > 1:
        gaps[1:] = gap_feature(np.diff(t))
    win[seq_len - k:, :n] = z_rows
    win[seq_len - k:, n] = gaps
    win[seq_len - k:, n + 1] = 1.0
    return win
