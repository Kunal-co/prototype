"""
drift.py — concept/data drift monitoring with ADWIN (the only non-neural component allowed).

ADWIN keeps an adaptive window over a numeric stream and shrinks it when two sub-windows have
significantly different means (Hoeffding-style bound controlled by `delta`). Live traffic has no
ground-truth labels, so ADWIN watches LABEL-FREE signals produced by the networks themselves:

  clean-traffic streams  (only flows judged normal AND familiar: neither attack nor flagged unusual).
                         This is "silent drift": the models stay confident while the inputs move.
      ensemble_probability   the mean P(attack) of CNN/FCNN/LSTM; creeping up = decision boundary erosion
      novelty_ratio          autoencoder error / threshold; rising = traffic is moving away from the training data
      one stream per model input (z-scored); a shift = that input itself changed
  rate streams           (all flows, so they see what the clean streams filter out)
      novelty_rate           1 if the flow was flagged unusual (and not an attack): the share of traffic unlike
                             anything in training changed. A new kind of traffic, benign or hostile, shows up here.
      attack_rate            1 if the flow was classified as an attack: the attack/benign mix changed

Alerting (kept deliberately conservative so a noisy signal cannot cry wolf):
  * a drift in a clean-traffic score stream or in novelty_rate -> ALERT  (kind "score")
  * >= min_features distinct input streams drifting within `vote_window` observations -> ALERT (kind "data")
  * a drift in attack_rate                                     -> NOTICE (kind "traffic")
  * practical significance: ADWIN only says a change is statistically real; a change smaller than the stream's
    `min_shift` (e.g. 0.25 standard deviations for an input) is ignored.
  * nothing is alerted during the first `warmup` observations of a stream.

When ground-truth labels are available (offline evaluation, analyst feedback), `ErrorMonitor`
runs ADWIN on the 0/1 prediction error: the textbook concept-drift test (see drift_demo.py).
"""
import os
import time
from collections import deque

from river import drift as river_drift

DEFAULT_DELTA = float(os.environ.get("ADWIN_DELTA", "0.002"))


def _adwin(delta):
    return river_drift.ADWIN(delta=delta)


class Stream:
    """One ADWIN instance plus the bookkeeping needed to describe a detection."""

    def __init__(self, name, kind, delta, min_shift=0.0):
        self.name, self.kind, self.min_shift = name, kind, min_shift
        self.adwin = _adwin(delta)
        self.n = 0
        self.detections = 0
        self.last_detection_at = None
        self._ref = None          # stable mean: follows the window while nothing happens, frozen once ADWIN cuts
        self._cut_pending = False
        self._last_cut_n = 0

    STABLE_AFTER = 300   # observations without a cut before the window counts as settled again

    def update(self, x):
        """Feed one value. Returns (mean_before, mean_after, width_before) when a drift is confirmed, else None.

        ADWIN trims its window in several small cuts while a change is under way, so one cut can move the mean very
        little. The reference mean therefore follows the window while the stream is quiet, freezes at the first cut,
        and the drift is confirmed once the window's mean has moved by at least `min_shift` from that reference
        (on a cut, or once the window has settled). A cut that never moves the mean far enough is treated as noise.
        """
        before_width = self.adwin.width
        self.adwin.update(float(x))
        self.n += 1
        est = self.adwin.estimation
        cut = self.adwin.drift_detected
        if self._ref is None:
            if self.n >= 30:
                self._ref = est
            return None
        if cut:
            self._cut_pending = True
            self._last_cut_n = self.n
        moved = abs(est - self._ref) >= self.min_shift
        settled = self.n - self._last_cut_n > self.STABLE_AFTER
        if self._cut_pending and moved and (cut or settled):
            ref, self._ref, self._cut_pending = self._ref, est, False
            self.detections += 1
            self.last_detection_at = time.time()
            return ref, est, before_width
        if not self._cut_pending or (settled and not moved):
            self._ref, self._cut_pending = est, False
        return None

    def describe(self):
        return {"name": self.name, "kind": self.kind, "observations": self.n, "window": int(self.adwin.width),
                "mean": round(float(self.adwin.estimation), 6), "detections": self.detections,
                "lastDetectionAt": self.last_detection_at}


class DriftMonitor:
    def __init__(self, feature_names, delta=DEFAULT_DELTA, warmup=100, min_features=3, vote_window=300):
        self.delta, self.warmup, self.min_features, self.vote_window = delta, warmup, min_features, vote_window
        self.score = {
            "ensemble_probability": Stream("ensemble_probability", "score", delta, min_shift=0.02),
            "novelty_ratio": Stream("novelty_ratio", "score", delta, min_shift=0.15),
        }
        self.novelty_rate = Stream("novelty_rate", "score", delta, min_shift=0.05)
        self.traffic = Stream("attack_rate", "traffic", delta, min_shift=0.05)
        self.features = {n: Stream(f"feature:{n}", "feature", delta, min_shift=0.25) for n in feature_names}
        self.benign_observations = 0
        self.total_observations = 0
        self._recent_feature_hits = deque()   # (benign_observation_index, feature name)
        self._cooldown_until = 0

    def observe(self, z_row, ensemble_probability, novelty_ratio, is_attack, is_threat):
        """Feed one scored flow. Returns a list of drift event dicts (usually empty)."""
        events = []
        self.total_observations += 1
        flagged_unusual = bool(is_threat) and not is_attack

        hit = self.traffic.update(1.0 if is_attack else 0.0)
        if hit and self.traffic.n > self.warmup:
            events.append(self._event(self.traffic, "notice", hit, "Share of attack flows changed"))
        if is_attack:
            return events  # an attack must never be mistaken for model drift
        hit = self.novelty_rate.update(1.0 if flagged_unusual else 0.0)
        if hit and self.novelty_rate.n > self.warmup:
            events.append(self._event(self.novelty_rate, "alert", hit,
                                      "The share of flows unlike the training data changed"))
        if flagged_unusual:
            return events  # unusual flows are counted above; the streams below describe accepted-as-normal traffic

        self.benign_observations += 1
        i = self.benign_observations
        for key, value in (("ensemble_probability", ensemble_probability), ("novelty_ratio", min(novelty_ratio, 5.0))):
            s = self.score[key]
            hit = s.update(value)
            if hit and s.n > self.warmup:
                events.append(self._event(s, "alert", hit, {
                    "ensemble_probability": "Models are scoring normal traffic differently than before",
                    "novelty_ratio": "Normal traffic is drifting away from the training data"}[key]))
        return events + self._observe_features(z_row, i)

    def _observe_features(self, z_row, i):
        events = []
        for j, (name, s) in enumerate(self.features.items()):
            hit = s.update(max(-5.0, min(5.0, float(z_row[j]))))
            if hit and s.n > self.warmup:
                self._recent_feature_hits.append((i, name, hit))
        while self._recent_feature_hits and i - self._recent_feature_hits[0][0] > self.vote_window:
            self._recent_feature_hits.popleft()
        distinct = {n for _, n, _ in self._recent_feature_hits}
        if len(distinct) >= self.min_features and i >= self._cooldown_until:
            names = sorted(distinct)
            moved = {n: h for _, n, h in self._recent_feature_hits}
            ev = {
                "stream": "input_features", "kind": "data", "level": "alert",
                "message": f"{len(names)} model inputs changed distribution",
                "features": [{"name": n, "meanBefore": round(float(moved[n][0]), 4),
                              "meanAfter": round(float(moved[n][1]), 4)} for n in names],
                "meanBefore": None, "meanAfter": None, "window": None,
                "observations": self.benign_observations, "at": time.time(),
            }
            events.append(ev)
            self._recent_feature_hits.clear()
            self._cooldown_until = i + self.vote_window
        return events

    def _event(self, stream, level, hit, message):
        before, after, width = hit
        return {"stream": stream.name, "kind": stream.kind, "level": level, "message": message, "features": None,
                "meanBefore": round(float(before), 6), "meanAfter": round(float(after), 6), "window": int(width),
                "observations": stream.n, "at": time.time()}

    def status(self):
        feats = sorted((s.describe() for s in self.features.values()), key=lambda d: -d["detections"])
        return {
            "delta": self.delta, "warmup": self.warmup, "totalObservations": self.total_observations,
            "benignObservations": self.benign_observations,
            "streams": [s.describe() for s in (*self.score.values(), self.novelty_rate, self.traffic)],
            "features": feats,
        }


class ErrorMonitor:
    """ADWIN over the 0/1 prediction error, for use when true labels are known (offline / analyst feedback)."""

    def __init__(self, delta=DEFAULT_DELTA):
        self.stream = Stream("prediction_error", "error", delta)

    def update(self, y_true, y_pred):
        return self.stream.update(0.0 if int(y_true) == int(y_pred) else 1.0)
