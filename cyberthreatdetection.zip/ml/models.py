"""
The three neural networks NetGuard-AI is allowed to use, plus the autoencoder that supplies the
"possible zero-day" signal. Keras 3 / TensorFlow.

  FCNN         fully connected network                    -> P(attack)
  CNN          1-D convolution over the ordered features  -> P(attack)
  LSTM         recurrent network over the last SEQ_LEN flows of ONE source IP (time ordered): learns how
               that IP normally behaves and flags changes (bursts, repeated logins, probing) -> P(attack)
               (build_lstm, the old one-flow variant, is kept only for models trained before this change)
  Autoencoder  fully connected, trained on NORMAL traffic only; a large reconstruction error
               means "this does not look like anything normal" (it is an FCNN, not a 4th model family)

The feature order of ml/features.json is the sequence order for the CNN and the LSTM, so the
schema keeps related features (counts, lengths, timing) next to each other.
"""
from common import quiet_tensorflow

quiet_tensorflow()
import keras  # noqa: E402
from keras import layers  # noqa: E402


def build_fcnn(n):
    return keras.Sequential([
        layers.Input(shape=(n,)),
        layers.Dense(128, activation="relu"), layers.BatchNormalization(), layers.Dropout(0.25),
        layers.Dense(64, activation="relu"), layers.Dropout(0.2),
        layers.Dense(32, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ], name="fcnn")


def build_cnn(n):
    return keras.Sequential([
        layers.Input(shape=(n,)),
        layers.Reshape((n, 1)),
        layers.Conv1D(32, 3, padding="same", activation="relu"), layers.BatchNormalization(),
        layers.Conv1D(64, 3, padding="same", activation="relu"),
        layers.MaxPooling1D(2),
        layers.Conv1D(64, 3, padding="same", activation="relu"),
        layers.Flatten(),
        layers.Dense(64, activation="relu"), layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid"),
    ], name="cnn")


def build_lstm(n):
    return keras.Sequential([
        layers.Input(shape=(n,)),
        layers.Reshape((n, 1)),
        layers.LSTM(48, return_sequences=True),
        layers.LSTM(24),
        layers.Dense(32, activation="relu"), layers.Dropout(0.2),
        layers.Dense(1, activation="sigmoid"),
    ], name="lstm")


def build_lstm_sequence(seq_len, step_dim):
    """Per-IP behaviour model: reads the last `seq_len` flows of one source IP (time order) and outputs
    P(this IP's behaviour is hostile). Replaces the old 'features of one flow as a sequence' LSTM."""
    return keras.Sequential([
        layers.Input(shape=(seq_len, step_dim)),
        layers.LSTM(48, return_sequences=True),
        layers.LSTM(24),
        layers.Dense(32, activation="relu"), layers.Dropout(0.2),
        layers.Dense(1, activation="sigmoid"),
    ], name="lstm")


def build_autoencoder(n):
    bottleneck = max(4, n // 4)
    return keras.Sequential([
        layers.Input(shape=(n,)),
        layers.Dense(max(16, n), activation="relu"),
        layers.Dense(max(8, n // 2), activation="relu"),
        layers.Dense(bottleneck, activation="relu"),
        layers.Dense(max(8, n // 2), activation="relu"),
        layers.Dense(max(16, n), activation="relu"),
        layers.Dense(n, activation="linear"),
    ], name="autoencoder")


CLASSIFIERS = {"fcnn": build_fcnn, "cnn": build_cnn, "lstm": build_lstm}  # lstm: legacy flow mode only
