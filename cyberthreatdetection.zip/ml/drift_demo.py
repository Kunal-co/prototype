#!/usr/bin/env python3
"""
drift_demo.py — shows that the drift monitor really reacts, using the trained models.

It streams held-out test flows (ml/artifacts/reference_sample.npz) through the models:

  phase 1  stable traffic, no change                     -> should raise NO alert
  phase 2  the same traffic after a shift in the inputs  -> should raise alerts

and reports, for each ADWIN stream, whether and how many observations after the change it fired.
Two views are shown:
  * label-free signals (what runs live): ensemble probability, novelty ratio, input features
  * labelled error (what you can run offline / with analyst feedback): ADWIN on the 0/1 error

  python ml/drift_demo.py [--shift 1.5] [--features 4] [--n 1500]
"""
import argparse

import numpy as np

import common
from common import ARTIFACT_DIR, MODEL_FILES, load_json

common.quiet_tensorflow()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1500, help="observations per phase")
    ap.add_argument("--shift", type=float, default=1.5, help="shift added (in standard deviations) to the chosen inputs")
    ap.add_argument("--features", type=int, default=4, help="how many inputs to shift")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()

    import keras
    from drift import DriftMonitor, ErrorMonitor
    meta = load_json(ARTIFACT_DIR / "meta.json")
    names = meta["feature_names"]
    ref = np.load(ARTIFACT_DIR / "reference_sample.npz")
    Z, y = ref["z"], ref["y"]
    nets = {k: keras.models.load_model(ARTIFACT_DIR / MODEL_FILES[k], compile=False) for k in ("cnn", "fcnn", "lstm", "autoencoder")}
    thr = meta["thresholds"]["novelty"]
    rng = np.random.default_rng(a.seed)

    def score(z):
        p = np.mean([np.asarray(nets[k](z, training=False)).ravel() for k in ("cnn", "fcnn", "lstm")], axis=0)
        e = np.mean((z - np.asarray(nets["autoencoder"](z, training=False))) ** 2, axis=1)
        return p, e / thr

    normal_idx = np.where(y == 0)[0]
    shifted_cols = rng.choice(len(names), size=min(a.features, len(names)), replace=False)

    def run(label, shift):
        mon = DriftMonitor(names)
        err = ErrorMonitor()
        fired, first_err = {}, None
        total = 2 * a.n
        idx = rng.choice(normal_idx, size=total, replace=True)
        Zs = Z[idx].copy()
        Zs[a.n:, shifted_cols] += shift          # phase 2 inputs move
        p, ratio = score(Zs)
        for i in range(total):
            attack = p[i] >= 0.5
            for ev in mon.observe(Zs[i], float(p[i]), float(ratio[i]), bool(attack), bool(attack or ratio[i] > 1)):
                if ev["level"] == "alert":
                    key = ev["stream"]
                    fired.setdefault(key, []).append(i)
            # labelled view: every row here is truly normal, so predicting "attack" is an error
            if err.update(0, int(attack)) and first_err is None and i >= 100:
                first_err = i
        phase = lambda lst: ([x for x in lst if x < a.n], [x for x in lst if x >= a.n])
        print(f"\n[{label}]  shift = {shift} sd on {len(shifted_cols)} inputs after observation {a.n}")
        if not fired:
            print("  label-free alerts: none")
        for k, lst in fired.items():
            before, after = phase(lst)
            delay = (after[0] - a.n) if after else None
            print(f"  label-free alert  {k:22s} before change: {len(before):2d}   after change: {len(after):2d}"
                  + (f"   first fired {delay} observations after the change" if delay is not None else ""))
        print(f"  labelled error ADWIN: " + ("no drift" if first_err is None else
              f"drift at observation {first_err}" + (f" ({first_err - a.n:+d} vs change)" if first_err >= a.n else " (BEFORE the change: false alarm)")))
        return fired

    def concept_drift():
        """Attackers start imitating normal traffic: 25% of flows are attacks, then their features become normal-looking."""
        mon, err = DriftMonitor(names), ErrorMonitor()
        attack_idx = np.where(y == 1)[0]
        total = 2 * a.n
        truth = rng.random(total) < 0.25
        idx = np.where(truth, rng.choice(attack_idx, total), rng.choice(normal_idx, total))
        Zs = Z[idx].copy()
        mimic = truth.copy(); mimic[:a.n] = False
        Zs[mimic] = Z[rng.choice(normal_idx, int(mimic.sum()))]   # after the change, "attacks" look normal
        p, ratio = score(Zs)
        first_err, notices = None, []
        for i in range(total):
            att = p[i] >= 0.5
            for ev in mon.observe(Zs[i], float(p[i]), float(ratio[i]), bool(att), bool(att or ratio[i] > 1)):
                notices.append((ev["stream"], ev["level"], i))
            if err.update(int(truth[i]), int(att)) and first_err is None and i >= 100:
                first_err = i
        print(f"\n[concept drift: attackers imitate normal traffic after observation {a.n}]")
        print("  labelled error ADWIN: " + ("no drift" if first_err is None else
              f"drift at observation {first_err} ({first_err - a.n:+d} vs change): the models now miss attacks"))
        for s_, lv, i in notices:
            print(f"  label-free {lv:6s} {s_:16s} at observation {i} ({i - a.n:+d} vs change)")
        return first_err is not None and first_err >= a.n

    print(f"models trained on {meta['source']} data; {len(names)} inputs; ADWIN delta {DriftMonitor(names).delta}")
    quiet = run("control: no change", 0.0)
    moved = run("drift: inputs shifted", a.shift)
    false_alarms = sum(len(v) for v in quiet.values())
    detected = any(i >= a.n for v in moved.values() for i in v)
    concept = concept_drift()
    print(f"\nresult: control false alerts = {false_alarms}; input shift detected label-free = {detected}; "
          f"concept drift detected from labelled error = {concept}")
    print("note: an input shift can leave accuracy untouched (error test silent) while the label-free signals fire;")
    print("      real concept drift needs labels to confirm, which live traffic does not have.")
    raise SystemExit(0 if (false_alarms == 0 and detected and concept) else 1)


if __name__ == "__main__":
    main()
