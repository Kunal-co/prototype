#!/usr/bin/env python3
"""
Read-only diagnostic: how do LIVE flows (data/captured_flows.csv) compare with the data the models were trained on?

Uses only saved artifacts (meta.json, preprocess.json, reference_sample.npz, the four .keras files) - no training CSV.
It changes nothing. Run it after any change to backend/flow.js or after retraining.

  python ml/diagnose_live.py [--csv data/captured_flows.csv] [--benign-label benign] [--legacy-active]

--legacy-active  replay captures made BEFORE the Active-Max fix: those rows hold the trailing active period, so
                 Active Max is zeroed on rows with Idle Max == 0 (what the fixed extractor would have written).
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

import common
from common import ARTIFACT_DIR, MODEL_FILES, Preprocessor, load_json

common.quiet_tensorflow()
import keras  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=str(common.HERE.parent / "data" / "captured_flows.csv"))
    ap.add_argument("--benign-label", default="benign")
    ap.add_argument("--legacy-active", action="store_true")
    a = ap.parse_args()

    meta = load_json(ARTIFACT_DIR / "meta.json")
    pre = Preprocessor.from_dict(load_json(ARTIFACT_DIR / "preprocess.json"))
    names = meta["feature_names"]
    assert pre.names == names, "preprocess.json and meta.json disagree on feature order"
    thr = meta["thresholds"]["novelty"]
    models = {n: keras.models.load_model(ARTIFACT_DIR / f, compile=False) for n, f in MODEL_FILES.items()}
    ref = np.load(ARTIFACT_DIR / "reference_sample.npz")
    rz, ry = ref["z"], ref["y"]

    df = pd.read_csv(a.csv)
    X = df[names].fillna(0.0).copy()
    if a.legacy_active:
        X.loc[df["Idle Max"].fillna(0).values == 0, "Active Max"] = 0.0
    Z = pre.transform(X.values)

    def score(z):
        p = np.mean([models[k].predict(z, verbose=0).ravel() for k in ("cnn", "fcnn", "lstm")], axis=0)
        e = ((z - models["autoencoder"].predict(z, verbose=0)) ** 2).mean(axis=1)
        return p, e

    # 1. Sanity: the models on data they know (held-out CICIDS reference sample)
    rp, re_ = score(rz)
    print(f"reference sample (CICIDS held-out) benign: attack {np.mean(rp[ry == 0] >= .5):.1%}, "
          f"novelty {np.mean(re_[ry == 0] > thr):.1%}; attacks caught {np.mean(rp[ry == 1] >= .5):.1%}")

    # 2. Per-feature parity on benign flows
    ben = (df["label"] == a.benign_label).values
    if ben.sum() == 0:
        sys.exit(f"no rows labelled '{a.benign_label}' in {a.csv}")
    zero_z = (0 - pre.mean) / pre.std
    rb = rz[ry == 0]
    lo, hi = np.percentile(rb, 1, axis=0), np.percentile(rb, 99, axis=0)
    rows = []
    for i, n in enumerate(names):
        rows.append((n,
                     float(np.mean(np.isclose(rb[:, i], np.clip(zero_z[i], -8, 8), atol=1e-3))),
                     float(np.mean(X[n].values[ben] == 0)),
                     float(np.mean((Z[ben, i] < lo[i]) | (Z[ben, i] > hi[i])))))
    t = pd.DataFrame(rows, columns=["feature", "CIC_benign_zero", "live_benign_zero", "live_outside_CIC_1-99pct"])
    print("\nper-feature parity (live benign vs CICIDS benign):")
    print(t.round(3).to_string(index=False))

    # 3. Verdicts per label under the shipped decision rule
    p, e = score(Z)
    atk, zd = p >= .5, (p < .5) & (e > thr)
    out = pd.DataFrame({"label": df["label"], "attack": atk, "possible_zero_day": zd, "normal": ~(atk | zd)})
    print("\nverdict share per label:")
    print(out.groupby("label").mean().round(3).to_string())
    print(f"\nlive benign novelty ratio (error/threshold) p10/p50/p90: "
          f"{np.percentile(e[ben] / thr, [10, 50, 90]).round(2).tolist()}  (CICIDS benign p50: {np.median(re_[ry == 0] / thr):.2f})")


if __name__ == "__main__":
    main()
