#!/usr/bin/env python3
"""
NetGuard-AI offline training: CNN + FCNN + LSTM classifiers and a FCNN autoencoder.

Run this on your own machine, not inside the deployed app.

  # (recommended) train on flows measured by the app's own extractor, so training and live
  # features are produced by the same code:
  python ml/train.py --source captured --data data/captured_flows.csv

  # train on CICIDS2017 (folder of CSVs or one CSV). Its features come from CICFlowMeter on real
  # packets while the app measures TCP reads/writes, so expect a distribution shift (see README):
  python ml/train.py --source cicids --data "C:/path/MachineLearningCVE" --top 20

Steps
  1  load + clean (strip header spaces, inf/NaN, label -> normal=0 / attack=1)
  2  candidate features = those the app can really measure (never the NOT_AVAILABLE ones);
     'Destination Port' is excluded (live it is always the server's own port) unless --keep-port
  3  rank candidates by mutual information, drop near-duplicates (|corr| > 0.95), keep the top N
  4  fit the preprocessor (signed log1p + z-score) on the training split only
  5  train FCNN, CNN (binary: normal vs attack, one flow at a time) and the autoencoder (normal rows only).
     The LSTM is a per-IP behaviour model (--lstm-mode sequence, default): flows are grouped by source IP, ordered by
     start time, cut into windows of the last --seq-len flows, and the LSTM learns how each IP behaves over time.
     It needs the columns src_ip and started_ms (written by the capture since this feature was added).
     --lstm-mode auto (default) picks sequence when src_ip + started_ms/Timestamp exist, else flow.
     --lstm-mode flow reproduces the old behaviour (one flow's features read as a sequence).
  6  evaluate on a held-out split; --holdout NAME[,NAME] removes attack families from training
     and reports how often the autoencoder flags them (the zero-day check)
  7  save artifacts to ml/artifacts and enable exactly the selected features in features.json
"""
import argparse
import glob
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

import common
from common import ARTIFACT_DIR, MODEL_FILES, SCHEMA_PATH, Preprocessor, load_schema, measurable_names, save_json

LABEL_COL = "Label"


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--source", choices=["captured", "cicids"], required=True)
    p.add_argument("--data", required=True, help="CSV file or folder of CSVs")
    p.add_argument("--out", default=str(ARTIFACT_DIR))
    p.add_argument("--features-json", default=str(SCHEMA_PATH))
    p.add_argument("--top", type=int, default=20, help="number of input features to keep")
    p.add_argument("--keep-port", action="store_true")
    p.add_argument("--holdout", default="", help="comma-separated attack labels withheld from training (zero-day test)")
    p.add_argument("--finals-only", action="store_true", help="captured data: ignore early snapshots")
    p.add_argument("--max-per-label", type=int, default=0,
                   help="cap rows per label (0 = off) so one noisy attack family cannot dominate")
    p.add_argument("--max-rows", type=int, default=300000, help="stratified cap on rows used")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch", type=int, default=256)
    p.add_argument("--novelty-quantile", type=float, default=0.995,
                   help="share of normal validation flows the autoencoder must accept (sets its threshold)")
    p.add_argument("--lstm-mode", choices=["auto", "sequence", "flow"], default="auto",
                   help="auto (default): sequence if the data has source-IP + timestamp columns, else flow; "
                        "sequence: per-source-IP windows of consecutive flows (error if columns missing); flow: single-flow LSTM")
    p.add_argument("--seq-len", type=int, default=common.SEQ_LEN, help="flows per LSTM window")
    p.add_argument("--splice-frac", type=float, default=0.25,
                   help="extra training windows that start as one IP's normal behaviour and turn hostile (0 = off)")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


# ----------------------------------------------------------------------- data

def read_csvs(path):
    p = Path(path)
    files = sorted(glob.glob(str(p / "*.csv"))) if p.is_dir() else [str(p)]
    if not files:
        sys.exit(f"No CSV files found in {path}")
    frames = []
    for f in files:
        print(f"reading {Path(f).name}")
        frames.append(pd.read_csv(f, low_memory=False, encoding="latin1"))
    df = pd.concat(frames, ignore_index=True)
    df.columns = [str(c).strip() for c in df.columns]  # raw CICIDS headers carry leading spaces
    return df


def load(args, candidates):
    df = read_csvs(args.data)
    if args.source == "captured":
        if "label" not in df.columns:
            sys.exit("Captured CSV has no 'label' column. Was it written by CAPTURE_DATASET?")
        df = df.rename(columns={"label": LABEL_COL})
        if args.finals_only and "final" in df.columns:
            df = df[df["final"] == 1]
    elif LABEL_COL not in df.columns:
        sys.exit("No 'Label' column found")
    meta_cols = []
    if args.source == "captured":
        meta_cols = [c for c in ("src_ip", "started_ms", "flow_id", "ts_ms") if c in df.columns]
    else:  # CICIDS2017 'GeneratedLabelledFlows' variants carry these; the plain MachineLearningCVE CSVs do not
        df = df.rename(columns={"Source IP": "src_ip", "Src IP": "src_ip"})
        if "Timestamp" in df.columns:
            ts = pd.to_datetime(df["Timestamp"], errors="coerce")
            df["started_ms"] = (ts - pd.Timestamp("1970-01-01")) // pd.Timedelta(milliseconds=1)  # NaT -> NaN
        meta_cols = [c for c in ("src_ip", "started_ms") if c in df.columns]
    missing = [c for c in candidates if c not in df.columns]
    if missing:
        sys.exit(f"CSV is missing expected columns: {missing[:6]} ...")
    n0 = len(df)
    df = df[candidates + [LABEL_COL] + meta_cols].copy()
    df[LABEL_COL] = df[LABEL_COL].astype(str).str.strip()
    df[candidates] = df[candidates].apply(pd.to_numeric, errors="coerce")
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    if args.source == "captured":
        df[candidates] = df[candidates].fillna(0.0)  # same imputation the live worker applies (null -> 0)
    else:
        df.dropna(subset=candidates + [LABEL_COL], inplace=True)
        df.drop_duplicates(subset=candidates + [LABEL_COL], inplace=True)
    df = df[(df[candidates].abs() < common.MAX_ABS_VALUE).all(axis=1)]
    df[candidates] = df[candidates].astype("float64")
    print(f"rows: {n0} raw -> {len(df)} clean")
    if "flow_id" not in df.columns:
        df["flow_id"] = [f"row{i}" for i in df.index]
    return df.reset_index(drop=True)


def cap_per_label(df, args):
    """Applied to the flow-level data only: sequences need every flow of an IP, so they use the uncapped frame."""
    if args.max_per_label > 0:
        df = pd.concat([g.sample(min(len(g), args.max_per_label), random_state=args.seed)
                        for _, g in df.groupby(LABEL_COL)])
        print(f"capped to {args.max_per_label} rows per label -> {len(df)} rows")
    return df.reset_index(drop=True)


def has_sequence_columns(df):
    return all(c in df.columns and df[c].notna().any() for c in ("src_ip", "started_ms"))


def is_normal(label):
    return label.strip().lower() in {"benign", "normal"}


# ------------------------------------------------------------------- features

def select_features(Xtr, ytr, candidates, top, seed):
    """Mutual information ranking + redundancy pruning. Order of the result follows the canonical schema."""
    from sklearn.feature_selection import mutual_info_classif
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(Xtr), size=min(60000, len(Xtr)), replace=False)
    T = common.signed_log1p(Xtr[idx])
    mi = mutual_info_classif(T, ytr[idx], random_state=seed, discrete_features=False)
    order = np.argsort(-mi)
    with np.errstate(invalid="ignore", divide="ignore"):  # constant columns have no correlation
        corr = np.nan_to_num(np.corrcoef(T, rowvar=False))
    floor = 0.05 * float(mi.max())  # a feature must carry at least 5% of the best feature's information
    kept = []
    for j in order:
        if mi[j] < max(floor, 1e-12):
            break
        if any(abs(corr[j, k]) > 0.95 for k in kept):
            continue
        kept.append(j)
        if len(kept) == top:
            break
    selected = [candidates[j] for j in sorted(kept)]  # canonical order, never re-ordered
    ranking = {candidates[j]: float(mi[j]) for j in order}
    return selected, ranking


# --------------------------------------------------------------------- models

def class_weights(y):
    n, pos = len(y), int(y.sum())
    return {0: n / (2.0 * max(1, n - pos)), 1: n / (2.0 * max(1, pos))}


def fit_classifier(name, builder, Ztr, ytr, Zva, yva, args):
    import keras
    print(f"\n== training {name.upper()} ==")
    model = builder(Ztr.shape[1])
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy",
                  metrics=["accuracy", keras.metrics.AUC(name="auc")])
    t0 = time.time()
    model.fit(Ztr, ytr, validation_data=(Zva, yva), epochs=args.epochs, batch_size=args.batch,
              class_weight=class_weights(ytr), verbose=2,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    print(f"{name} trained in {time.time() - t0:.0f}s")
    return model


def predict_p(model, Z, batch=2048):
    return np.concatenate([np.asarray(model(Z[i:i + batch], training=False)).ravel() for i in range(0, len(Z), batch)])


def recon_error(ae, Z, batch=2048):
    out = []
    for i in range(0, len(Z), batch):
        zb = Z[i:i + batch]
        out.append(np.mean((zb - np.asarray(ae(zb, training=False))) ** 2, axis=1))
    return np.concatenate(out)


def binary_report(y, p, thr=0.5):
    from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)),
            "f1": float(f1_score(y, pred, zero_division=0)),
            "auc": float(roc_auc_score(y, p)) if len(set(y)) == 2 else None,
            "false_positive_rate": float(fp / max(1, fp + tn)),
            "confusion": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}}


# ------------------------------------------------------------- per-IP sequences

def sequence_data(frame, selected, pre, seq_len):
    """One row per flow (the latest report of each flow_id), grouped by source IP, ordered by flow start time.
    Returns a dict with a window per flow, its label, the chronological fold of its IP's history
    (first 60% of that IP's flows = train, next 20% = val, last 20% = test) and the per-IP series for splicing."""
    if "src_ip" not in frame.columns or "started_ms" not in frame.columns:
        sys.exit("The data has no source-IP / start-time columns, so per-IP sequences cannot be built. "
                 "Capture new data with the current app (it writes src_ip and started_ms), or train the "
                 "legacy single-flow LSTM with --lstm-mode flow.")
    f = frame.dropna(subset=["src_ip", "started_ms"])
    if "ts_ms" in f.columns:
        f = f.sort_values("ts_ms")
    f = f.drop_duplicates("flow_id", keep="last")  # snapshots collapse into the flow's latest report
    f = f.sort_values(["src_ip", "started_ms"], kind="stable").reset_index(drop=True)
    Z = pre.transform(f[selected].to_numpy())
    t = f["started_ms"].to_numpy(dtype=np.float64) / 1000.0
    lab = f[LABEL_COL].to_numpy()
    y = (~f[LABEL_COL].map(is_normal)).astype(int).to_numpy()
    n = len(f)
    W = np.zeros((n, seq_len, len(selected) + 2), dtype=np.float32)
    fold = np.zeros(n, dtype=np.int8)  # 0 train, 1 val, 2 test
    series = []  # (start, stop) row ranges, one per IP
    for _, g in f.groupby("src_ip", sort=False).indices.items():
        lo, hi = int(g.min()), int(g.max()) + 1  # rows of one IP are contiguous after the sort
        m = hi - lo
        for k in range(m):
            first = max(lo, lo + k - seq_len + 1)
            W[lo + k] = common.make_window(Z[first:lo + k + 1], t[first:lo + k + 1], seq_len)
            fold[lo + k] = 0 if k / m < 0.6 else (1 if k / m < 0.8 else 2)
        series.append((lo, hi))
    return {"W": W, "y": y, "lab": lab, "fold": fold, "fid": f["flow_id"].to_numpy(), "Z": Z, "t": t,
            "series": series, "ips": f["src_ip"].to_numpy()}


def spliced_windows(sd, rows_ok, seq_len, count, rng, attack_suffix_min=2, fixed_suffix=None):
    """Windows that begin as ONE normal IP's recent behaviour and continue as an attacking IP's flows.
    Teaches the LSTM the *change*, which labelled-by-IP data alone never shows. rows_ok marks the usable rows."""
    normal, attack = [], []
    for lo, hi in sd["series"]:
        idx = np.arange(lo, hi)[rows_ok[lo:hi]]
        if len(idx) < 3:
            continue
        (attack if sd["y"][idx[0]] == 1 else normal).append(idx)
    attack = [a for a in attack if len(a) >= attack_suffix_min]
    normal = [a for a in normal if len(a) >= 2]
    if not normal or not attack or count <= 0:
        return np.zeros((0, seq_len, sd["W"].shape[2]), np.float32), np.zeros(0, int)
    out = []
    for _ in range(count):
        a = normal[rng.integers(len(normal))]
        b = attack[rng.integers(len(attack))]
        s = fixed_suffix or int(rng.integers(attack_suffix_min, max(attack_suffix_min, seq_len - 2) + 1))
        s = min(s, len(b))
        p = int(rng.integers(2, seq_len - s + 1)) if seq_len - s >= 2 else 1
        end = int(rng.integers(min(p, len(a)) - 1, len(a)))
        ia = a[max(0, end - p + 1):end + 1]
        start = int(rng.integers(0, len(b) - s + 1))
        ib = b[start:start + s]
        tb = sd["t"][ib] - sd["t"][ib[0]] + sd["t"][ia[-1]] + float(rng.uniform(0.05, 5.0))
        out.append(common.make_window(np.vstack([sd["Z"][ia], sd["Z"][ib]]), np.concatenate([sd["t"][ia], tb]), seq_len))
    return np.stack(out), np.ones(len(out), dtype=int)


# ----------------------------------------------------------------------- main

def main():
    args = parse_args()
    import keras
    import models as nets
    keras.utils.set_random_seed(args.seed)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    entries, _ = load_schema(args.features_json)
    candidates = [n for n in measurable_names(entries) if args.keep_port or n != "Destination Port"]
    print(f"candidate pool: {len(candidates)} features the app can measure")
    if args.source == "cicids":
        print("WARNING: CICIDS2017 features come from CICFlowMeter on real packets; the app measures TCP "
              "reads/writes. Live accuracy will be lower than the numbers below. See README, 'Training data'.")

    full = load(args, candidates)  # every flow, uncapped: the per-IP sequences need the complete history
    if args.lstm_mode == "auto":
        args.lstm_mode = "sequence" if has_sequence_columns(full) else "flow"
        print(f"LSTM mode (auto): {args.lstm_mode}" + ("" if args.lstm_mode == "sequence" else
              " (no usable source-IP / timestamp columns -> single-flow LSTM)"))
    df = cap_per_label(full, args)
    labels = df[LABEL_COL]
    holdout = {h.strip() for h in args.holdout.split(",") if h.strip()}
    unknown = holdout - set(labels.unique())
    if unknown:
        sys.exit(f"--holdout label(s) not in data: {sorted(unknown)}. Present: {sorted(labels.unique())}")
    y_all = (~labels.map(is_normal)).astype(int).to_numpy()
    print("labels:", labels.value_counts().to_dict(), f"| attack share {y_all.mean():.3f}")
    if len(set(y_all)) < 2:
        sys.exit("Need both normal and attack rows")

    held = labels.isin(holdout).to_numpy()
    X_all = df[candidates].to_numpy()
    Xh, lh = X_all[held], labels[held].to_numpy()
    X, y, lab = X_all[~held], y_all[~held], labels[~held].to_numpy()
    fid_h, fid = df["flow_id"].to_numpy()[held], df["flow_id"].to_numpy()[~held]

    from sklearn.model_selection import train_test_split
    if len(X) > args.max_rows:
        keep, _ = train_test_split(np.arange(len(X)), train_size=args.max_rows, stratify=y, random_state=args.seed)
        X, y, lab, fid = X[keep], y[keep], lab[keep], fid[keep]
    i_tr, i_tmp = train_test_split(np.arange(len(X)), test_size=0.4, stratify=y, random_state=args.seed)
    i_va, i_te = train_test_split(i_tmp, test_size=0.5, stratify=y[i_tmp], random_state=args.seed)
    print(f"split: train {len(i_tr)} / val {len(i_va)} / test {len(i_te)}"
          + (f" / held-out family rows {len(Xh)}" if holdout else ""))

    selected, ranking = select_features(X[i_tr], y[i_tr], candidates, args.top, args.seed)
    print(f"\nselected {len(selected)} features (mutual information, redundancy pruned):")
    for n in selected:
        print(f"  {n:32s} MI={ranking.get(n, 0):.4f}")
    cols = [candidates.index(n) for n in selected]
    X, Xh = X[:, cols], Xh[:, cols]

    pre = Preprocessor.fit(selected, X[i_tr])
    Z = pre.transform(X)
    Zh = pre.transform(Xh) if len(Xh) else np.zeros((0, len(selected)), np.float32)
    Ztr, Zva, Zte = Z[i_tr], Z[i_va], Z[i_te]
    ytr, yva, yte = y[i_tr], y[i_va], y[i_te]

    seq_mode = args.lstm_mode == "sequence"
    flow_nets = {k: b for k, b in nets.CLASSIFIERS.items() if not (seq_mode and k == "lstm")}
    trained = {name: fit_classifier(name, b, Ztr, ytr, Zva, yva, args) for name, b in flow_nets.items()}

    sd = seq_report = None
    if seq_mode:
        T = args.seq_len
        sd = sequence_data(full, selected, pre, T)
        ok = ~np.isin(sd["lab"], list(holdout))  # held-out families are never trained on (or validated on)
        W, ys, fold = sd["W"], sd["y"], sd["fold"]
        rng = np.random.default_rng(args.seed)
        parts = {}
        for k, name in enumerate(("train", "val", "test")):
            m = ok & (fold == k)
            parts[name] = (W[m], ys[m])
        print(f"\nper-IP sequences: {len(sd['series'])} source IPs, {len(W)} flows -> windows of {T} flows; "
              f"train {len(parts['train'][1])} / val {len(parts['val'][1])} / test {len(parts['test'][1])} "
              f"(chronological split inside each IP; attack share train {parts['train'][1].mean():.3f})")
        if len(set(parts["train"][1])) < 2 or len(set(parts["test"][1])) < 2:
            sys.exit("Sequence data needs both normal and attack windows in the train and test folds. "
                     "Capture more traffic (or fewer/longer-lived IPs per class).")
        n_aug = int(args.splice_frac * parts["train"][1].sum())
        for name, k, cnt in (("train", 0, n_aug), ("val", 1, n_aug // 4)):
            Wa, ya = spliced_windows(sd, ok & (fold == k), T, cnt, rng)
            if len(ya):
                parts[name] = (np.concatenate([parts[name][0], Wa]), np.concatenate([parts[name][1], ya]))
                print(f"  + {len(ya)} spliced {name} windows (normal behaviour turning hostile)")
        trained["lstm"] = fit_classifier("lstm", lambda _n: nets.build_lstm_sequence(T, W.shape[2]),
                                         *parts["train"], *parts["val"], args)
        Wte, yte_s = parts["test"]
        p_all = predict_p(trained["lstm"], W)
        p_by_flow = dict(zip(sd["fid"], p_all))
        mte = ok & (fold == 2)
        # per-family recall: how often the LSTM flags each kind of IP behaviour
        per_family = {str(l): {"windows": int((sd["lab"][mte] == l).sum()),
                               "flagged": float((p_all[mte & (sd["lab"] == l)] >= 0.5).mean())}
                      for l in sorted(set(sd["lab"][mte]))}
        # change detection: 6 normal flows from a quiet IP, then s hostile flows. How many does the LSTM need to see?
        onset = {}
        for s_len in range(1, min(6, T - 2) + 1):
            Wc, _ = spliced_windows(sd, ok & (fold == 2), T, 300, np.random.default_rng(args.seed + s_len), fixed_suffix=s_len)
            onset[str(s_len)] = float((predict_p(trained["lstm"], Wc) >= 0.5).mean()) if len(Wc) else None
        seq_report = {"mode": "sequence", "seq_len": T, "step_dim": int(W.shape[2]), "ips": len(sd["series"]),
                      "windows": {k: int(len(v[1])) for k, v in parts.items()},
                      "per_family_flag_rate_test": per_family, "flag_rate_by_hostile_flows_after_change": onset}
        print("LSTM per-family flag rate on its chronological test fold:",
              {k: f"{v['flagged']:.1%} of {v['windows']}" for k, v in per_family.items()})
        print("LSTM change detection (normal history, then N hostile flows):",
              {k: (None if v is None else f"{v:.0%}") for k, v in onset.items()})

    print("\n== training AUTOENCODER (normal traffic only) ==")
    ae = nets.build_autoencoder(len(selected))
    ae.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse")
    ae.fit(Ztr[ytr == 0], Ztr[ytr == 0], validation_data=(Zva[yva == 0], Zva[yva == 0]), epochs=args.epochs,
           batch_size=args.batch, verbose=2,
           callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    novelty_thr = float(np.quantile(recon_error(ae, Zva[yva == 0]), args.novelty_quantile))
    novelty_thr = max(novelty_thr, 1e-6)

    # ------------------------------------------------------------- evaluation
    probs = {n: predict_p(m, Zte) for n, m in trained.items() if n != "lstm" or not seq_mode}
    metrics = {}
    if seq_mode:
        # CNN/FCNN: flow-level test split (unchanged). LSTM: its own chronological per-IP test windows.
        # Ensemble: only flows that are test data for ALL three (flow-level test AND the LSTM's test fold), so no model is scored on its training data.
        in_test = {f for f, m in zip(sd["fid"], mte) if m}
        sel = np.array([f in in_test for f in fid[i_te]])
        p_l = np.array([p_by_flow.get(f, 0.0) for f in fid[i_te]])
        probs["lstm"] = p_l
        metrics["lstm"] = binary_report(yte_s, predict_p(trained["lstm"], Wte))
        if sel.sum() and len(set(yte[sel])) == 2:
            probs["ensemble"] = np.mean([probs[n] for n in ("cnn", "fcnn", "lstm")], axis=0)
            metrics["ensemble"] = binary_report(yte[sel], probs["ensemble"][sel])
            metrics["ensemble"]["rows"] = int(sel.sum())
        else:
            print("NOTE: too few flows are test data for all three models; ensemble metrics skipped. Capture more traffic.")
            probs["ensemble"] = np.mean([probs[n] for n in ("cnn", "fcnn", "lstm")], axis=0)
        for n in ("cnn", "fcnn"):
            metrics[n] = binary_report(yte, probs[n])
    else:
        probs["ensemble"] = np.mean([probs[n] for n in trained], axis=0)
        metrics = {n: binary_report(yte, p) for n, p in probs.items()}
    err = recon_error(ae, Zte)
    ens_attack = probs["ensemble"] >= 0.5
    novel = err > novelty_thr
    metrics["novelty"] = {
        "threshold": novelty_thr, "quantile": args.novelty_quantile,
        "flag_rate_on_normal": float(novel[yte == 0].mean()),
        "flag_rate_on_known_attacks": float(novel[yte == 1].mean()),
        "zero_day_candidates_missed_by_ensemble": float((novel & ~ens_attack)[yte == 1].mean()),
    }
    print("\n== held-out test results ==")
    for n in ("fcnn", "cnn", "lstm", "ensemble"):
        if n not in metrics:
            continue
        m = metrics[n]
        print(f"{n:9s} precision {m['precision']:.4f}  recall {m['recall']:.4f}  f1 {m['f1']:.4f}  "
              f"auc {m['auc'] if m['auc'] is None else round(m['auc'], 4)}  FPR {m['false_positive_rate']:.4f}  {m['confusion']}")
    print(f"autoencoder flags {metrics['novelty']['flag_rate_on_normal']:.3%} of normal and "
          f"{metrics['novelty']['flag_rate_on_known_attacks']:.3%} of known-attack test flows")

    zero_day = None
    if len(Zh):
        flow_p = [predict_p(m, Zh) for n, m in trained.items() if not (seq_mode and n == "lstm")]
        if seq_mode:  # the held-out family's LSTM score comes from its per-IP windows (never trained on)
            flow_p.append(np.array([p_by_flow.get(f, 0.0) for f in fid_h]))
        p_h = np.mean(flow_p, axis=0)
        e_h = recon_error(ae, Zh)
        per = {}
        for fam in sorted(holdout):
            sel = lh == fam
            caught_known = float((p_h[sel] >= 0.5).mean())
            flagged_novel = float(((e_h[sel] > novelty_thr) & (p_h[sel] < 0.5)).mean())
            per[fam] = {"rows": int(sel.sum()), "caught_as_known_attack": caught_known,
                        "flagged_possible_zero_day": flagged_novel,
                        "missed_entirely": float(max(0.0, 1 - caught_known - flagged_novel))}
        zero_day = per
        print("\n== zero-day check on attack families the models never saw ==")
        for fam, r in per.items():
            print(f"{fam:16s} rows {r['rows']:5d}  known-attack {r['caught_as_known_attack']:.1%}  "
                  f"possible zero-day {r['flagged_possible_zero_day']:.1%}  missed {r['missed_entirely']:.1%}")

    # ------------------------------------------------------------------- save
    for name, model in {**trained, "autoencoder": ae}.items():
        model.save(out / MODEL_FILES[name])
    save_json(out / "preprocess.json", pre.to_dict())
    meta = {
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "source": args.source, "feature_names": selected,
        "thresholds": {"ensemble": 0.5, "novelty": novelty_thr}, "novelty_quantile": args.novelty_quantile,
        "models": MODEL_FILES, "rows": {"train": int(len(i_tr)), "val": int(len(i_va)), "test": int(len(i_te))},
        "labels": {k: int(v) for k, v in labels.value_counts().items()}, "holdout": sorted(holdout),
        "metrics": metrics, "zero_day_check": zero_day, "mutual_information": ranking,
        "lstm": seq_report or {"mode": "flow"},
        "lstm_mode": "sequence" if seq_mode else "flow",
    }
    save_json(out / "meta.json", meta)
    rng = np.random.default_rng(args.seed)
    pick = rng.choice(len(i_te), size=min(4000, len(i_te)), replace=False)
    np.savez_compressed(out / "reference_sample.npz", z=Zte[pick], y=yte[pick])

    target = Path(args.features_json)
    raw = json.loads(target.read_text(encoding="utf-8"))
    backup = target.with_name("features.full.json")
    if not backup.exists():
        shutil.copy(target, backup)  # one-time backup of the schema as it was
    for f in raw["features"]:
        f["enabled"] = f["name"] in selected
    target.write_text(json.dumps(raw, indent=2), encoding="utf-8")

    # self-check: reloaded models must reproduce in-memory predictions
    for name, model in trained.items():
        again = keras.models.load_model(out / MODEL_FILES[name])
        probe = Wte[:64] if (seq_mode and name == "lstm") else Zte[:64]
        assert np.allclose(predict_p(again, probe), predict_p(model, probe), atol=1e-5), f"{name} reload mismatch"
    print(f"\nSaved models, preprocess.json, meta.json to {out}; {len(selected)} features enabled in {target.name}.")
    print("Next: python ml/predict.py --inspect")


if __name__ == "__main__":
    main()
