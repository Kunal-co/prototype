#!/usr/bin/env python3
"""
NetGuard-AI prediction worker. Loads trained networks and scores flows. It never trains.

Modes
  python predict.py --serve     long-running worker used by backend/detector.js
                                (one JSON request per stdin line, one JSON response per stdout line)
  python predict.py --inspect   loads everything, verifies it against features.json, prints a report

Request  : {"id": 1, "features": [<N numbers or null>], "allow_missing": false, "observe": true,
            "source": {"ip": "1.2.3.4", "flow_id": "...", "started_ms": 1700000000000}}   # source is optional
           {"id": 2, "cmd": "drift"}                     -> drift monitor status
Response : {"id": 1, "ok": true,
            "models":   {"cnn": {"probability": p}, "fcnn": {...}, "lstm": {...}},   # P(attack)
            "ensemble": {"probability": p, "label": "normal"|"attack", "votes": 0-3, "disagreement": sd},
            "novelty":  {"score": err, "threshold": t, "ratio": err/t, "flag": bool},
            "drift":    {"events": [...]},
            "sequence": {"mode": "sequence"|"flow", "ip": str|null, "window": flows in the LSTM window, "seq_len": int},
            "meta":     {"imputed_count": int}}
Error    : {"id": 1, "ok": false, "error": "..."}

`observe` decides whether the sample updates the ADWIN drift monitors AND the per-IP flow history
the LSTM reads (live flows: true; manual tests: false). The CNN, FCNN and autoencoder always score
the single flow; the LSTM scores the last seq_len flows of `source.ip` (just this flow when no source
is given, or for models trained in the legacy single-flow mode). Field names never change between
predictions. stdout carries ONLY these lines.
"""
import json
import math
import os
import sys
import time
from collections import OrderedDict

# stdout is the protocol channel: capture it, then point everything else at stderr.
_PROTO = sys.stdout
sys.stdout = sys.stderr

import numpy as np  # noqa: E402

import common  # noqa: E402
from common import ARTIFACT_DIR, MODEL_FILES, MAX_ABS_VALUE, Preprocessor, load_json, load_schema  # noqa: E402

common.quiet_tensorflow()
ENSEMBLE_THRESHOLD_ENV = os.environ.get("NETGUARD_ENSEMBLE_THRESHOLD")
NOVELTY_SCALE = float(os.environ.get("NETGUARD_NOVELTY_SCALE", "1.0"))  # >1 makes the zero-day check less sensitive


class IpHistory:
    """The most recent flows of each source IP, so the LSTM can read behaviour over time.

    A flow that reports again (snapshot -> final) replaces its earlier entry. The window for a flow contains
    that flow and the seq_len-1 flows of the same IP that STARTED before it, exactly like the training windows."""
    KEEP = 64            # steps stored per IP (the window uses the last seq_len of them)
    MAX_IPS = int(os.environ.get("NETGUARD_MAX_TRACKED_IPS", "5000"))

    def __init__(self, seq_len):
        self.seq_len = seq_len
        self.ips = OrderedDict()   # ip -> list of (started_seconds, flow_id, z_row), oldest IP first

    def window(self, ip, flow_id, started_ms, z_row, commit):
        t = started_ms / 1000.0
        steps = [s for s in self.ips.get(ip, []) if s[1] != flow_id] if ip else []
        before = sorted((s for s in steps if s[0] <= t), key=lambda s: s[0])[-(self.seq_len - 1):]
        rows = [s[2] for s in before] + [z_row]
        times = [s[0] for s in before] + [t]
        if commit and ip:
            steps.append((t, flow_id, z_row))
            steps.sort(key=lambda s: s[0])
            self.ips[ip] = steps[-self.KEEP:]
            self.ips.move_to_end(ip)
            while len(self.ips) > self.MAX_IPS:
                self.ips.popitem(last=False)
        return common.make_window(np.array(rows), np.array(times), self.seq_len), len(rows)


class Engine:
    def __init__(self):
        import keras
        _, self.expected = load_schema()
        meta_path = ARTIFACT_DIR / "meta.json"
        if not meta_path.exists():
            raise FileNotFoundError(
                f"No trained models in {ARTIFACT_DIR}. Train them first: python ml/train.py --source captured --data <csv> "
                "(see README).")
        self.meta = load_json(meta_path)
        self.pre = Preprocessor.from_dict(load_json(ARTIFACT_DIR / "preprocess.json"))
        trained = list(self.meta["feature_names"])
        if trained != self.expected:
            missing = sorted(set(self.expected) - set(trained))[:5]
            extra = sorted(set(trained) - set(self.expected))[:5]
            raise ValueError(
                "Feature contract violation: the models were trained on "
                f"{len(trained)} features but features.json enables {len(self.expected)}"
                + (" in a different ORDER" if sorted(trained) == sorted(self.expected) else
                   f" (missing e.g. {missing}, unexpected e.g. {extra})")
                + ". Re-run train.py or restore the matching features.json.")
        if self.pre.names != trained:
            raise ValueError("preprocess.json does not match meta.json feature order")
        lstm_cfg = self.meta.get("lstm") or {"mode": "flow"}   # models trained before the per-IP LSTM have no entry
        mode = self.meta.get("lstm_mode") or lstm_cfg.get("mode") or "flow"
        if mode not in ("sequence", "flow"):
            raise ValueError(f"unknown lstm mode '{mode}' in meta.json")
        self.seq_mode = mode == "sequence"
        self.seq_len = int(lstm_cfg.get("seq_len", common.SEQ_LEN))
        self.models = {}
        for name, fname in MODEL_FILES.items():
            path = ARTIFACT_DIR / fname
            if not path.exists():
                raise FileNotFoundError(f"Model file not found: {path}")
            self.models[name] = keras.models.load_model(path, compile=False)
            if name == "lstm" and self.seq_mode:
                want = (self.seq_len, common.step_dim(len(trained)))
                if tuple(self.models[name].input_shape[1:]) != want:
                    raise ValueError(f"{fname} expects windows of shape {self.models[name].input_shape[1:]}, "
                                     f"the sequence contract is {want}")
            elif self.models[name].input_shape[-1] != len(trained):
                raise ValueError(f"{fname} expects {self.models[name].input_shape[-1]} inputs, schema has {len(trained)}")
        self.history = IpHistory(self.seq_len)
        thr = self.meta["thresholds"]
        self.ens_threshold = float(ENSEMBLE_THRESHOLD_ENV) if ENSEMBLE_THRESHOLD_ENV else float(thr["ensemble"])
        self.novelty_threshold = float(thr["novelty"]) * NOVELTY_SCALE
        import tensorflow as tf
        nets = self.models

        seq_mode = self.seq_mode

        @tf.function(reduce_retracing=True)
        def infer(z, w):  # all four networks in ONE compiled graph call (~10x faster than four eager calls)
            lstm_in = w if seq_mode else z   # per-IP window, or (legacy models) the single flow
            return nets["cnn"](z, training=False), nets["fcnn"](z, training=False), nets["lstm"](lstm_in, training=False), nets["autoencoder"](z, training=False)
        self._infer = infer
        from drift import DriftMonitor
        self.monitor = DriftMonitor(self.expected)
        self._score(np.zeros((1, len(trained)), dtype=np.float32), self._empty_window())  # warm-up: build graphs before the first flow
        self.info = {
            "feature_count": len(self.expected), "feature_names": self.expected,
            "models": {n: type(m).__name__ for n, m in self.models.items()},
            "trained_on": self.meta.get("source"), "trained_at": self.meta.get("created"),
            "holdout": self.meta.get("holdout", []),
            "lstm": {"mode": "sequence" if self.seq_mode else "flow", "seq_len": self.seq_len if self.seq_mode else 1},
            "thresholds": {"ensemble": self.ens_threshold, "novelty": self.novelty_threshold},
            "test_metrics": {k: {m: v for m, v in self.meta["metrics"][k].items() if m in ("precision", "recall", "f1", "auc")}
                             for k in ("cnn", "fcnn", "lstm", "ensemble") if k in self.meta.get("metrics", {})},
            "drift": {"detector": "ADWIN", "delta": self.monitor.delta},
            "warnings": [],
        }
        if self.meta.get("source") == "cicids":
            self.info["warnings"].append(
                "Models were trained on CICIDS2017 (CICFlowMeter features); live features are measured differently. "
                "Verdicts are indicative; prefer training on captured flows.")

    def _empty_window(self):
        d = common.step_dim(len(self.expected))
        return np.zeros((1, self.seq_len, d) if self.seq_mode else (1, 1, 1), dtype=np.float32)

    def _score(self, z, w):
        cnn, fcnn, lstm, recon = (np.asarray(o) for o in self._infer(z, w))
        probs = {"cnn": float(cnn.ravel()[0]), "fcnn": float(fcnn.ravel()[0]), "lstm": float(lstm.ravel()[0])}
        err = float(np.mean((z - recon) ** 2))
        return probs, err

    def _clean_row(self, features, allow_missing):
        if not isinstance(features, list) or len(features) != len(self.expected):
            got = len(features) if isinstance(features, list) else type(features).__name__
            raise ValueError(f"expected a list of {len(self.expected)} features, got {got}")
        row, imputed = [], 0
        for name, value in zip(self.expected, features):
            if value is None:
                if not allow_missing:
                    raise ValueError(f"feature '{name}' is missing")
                row.append(0.0)  # documented neutral fill, identical to the fill used when training; counted
                imputed += 1
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"feature '{name}' must be a finite number")
            if abs(value) > MAX_ABS_VALUE:
                raise ValueError(f"feature '{name}' is outside the supported range")
            row.append(float(value))
        return row, imputed

    @staticmethod
    def _clean_source(source):
        if not source:
            return None, None, None
        ip, fid, started = source.get("ip"), source.get("flow_id"), source.get("started_ms")
        if not isinstance(ip, str) or not ip or len(ip) > 64:
            raise ValueError("source.ip must be a non-empty string")
        fid = str(fid) if fid is not None else None
        if started is None:
            started = time.time() * 1000.0
        if isinstance(started, bool) or not isinstance(started, (int, float)) or not math.isfinite(started):
            raise ValueError("source.started_ms must be a finite number")
        return ip, fid, float(started)

    def predict(self, features, allow_missing=False, observe=False, source=None):
        row, imputed = self._clean_row(features, allow_missing)
        ip, flow_id, started_ms = self._clean_source(source)
        z = self.pre.transform(np.array([row]))
        if self.seq_mode:
            if ip is None:   # no source: the window holds just this flow (nothing is remembered)
                win, k = common.make_window(z, [0.0], self.seq_len), 1
            else:
                win, k = self.history.window(ip, flow_id, started_ms, z[0], commit=observe)
            w = win[None, ...]
        else:
            w, k = self._empty_window(), 1
        probs, err = self._score(z, w)
        p_ens = float(np.mean(list(probs.values())))
        votes = sum(1 for p in probs.values() if p >= 0.5)
        ratio = err / self.novelty_threshold
        is_attack = p_ens >= self.ens_threshold
        flag = ratio > 1.0
        events = []
        if observe:
            events = self.monitor.observe(z[0], p_ens, ratio, is_attack, is_attack or flag)
        for v in (err, ratio, p_ens):
            if not math.isfinite(v):
                raise ValueError("model produced a non-finite score")
        return {
            "models": {n: ({"probability": round(p, 6), "window": k} if n == "lstm" and self.seq_mode
                           else {"probability": round(p, 6)}) for n, p in probs.items()},
            "ensemble": {"probability": round(p_ens, 6), "label": "attack" if is_attack else "normal",
                         "votes": votes, "disagreement": round(float(np.std(list(probs.values()))), 6)},
            "novelty": {"score": round(err, 6), "threshold": round(self.novelty_threshold, 6),
                        "ratio": round(ratio, 4), "flag": bool(flag)},
            "drift": {"events": events},
            "sequence": {"mode": "sequence" if self.seq_mode else "flow", "ip": ip, "window": k,
                         "seq_len": self.seq_len if self.seq_mode else 1},
            "meta": {"imputed_count": imputed},
        }


def emit(obj):
    _PROTO.write(json.dumps(obj, allow_nan=False) + "\n")
    _PROTO.flush()


def serve():
    try:
        engine = Engine()
    except Exception as exc:  # noqa: BLE001
        emit({"ready": False, "error": f"{type(exc).__name__}: {exc}"})
        return 1
    emit({"ready": True, "info": engine.info})
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        rid = None
        try:
            req = json.loads(line)
            rid = req.get("id")
            if req.get("cmd") == "drift":
                emit({"id": rid, "ok": True, "drift_status": engine.monitor.status()})
                continue
            t0 = time.perf_counter()
            out = engine.predict(req.get("features"), bool(req.get("allow_missing")), bool(req.get("observe")), req.get("source"))
            out["meta"]["inference_ms"] = round((time.perf_counter() - t0) * 1000, 2)
            emit({"id": rid, "ok": True, **out})
        except Exception as exc:  # noqa: BLE001
            emit({"id": rid, "ok": False, "error": f"{type(exc).__name__}: {exc}"})
    return 0


def inspect():
    try:
        engine = Engine()
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, indent=2), file=_PROTO)
        return 1
    print(json.dumps({"ok": True, **engine.info}, indent=2), file=_PROTO)
    return 0


if __name__ == "__main__":
    if "--inspect" in sys.argv:
        sys.exit(inspect())
    if "--serve" in sys.argv:
        sys.exit(serve())
    print(__doc__, file=_PROTO)
    sys.exit(2)
