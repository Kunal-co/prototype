# NetGuard-AI

Web app that measures every TCP connection to its own server as a network flow, scores each flow with
**CNN, FCNN and LSTM** networks, checks it against a **FCNN autoencoder** for unseen behaviour, and watches
for model drift with **ADWIN**. Same pages, API, database and three verdicts as the prototype
(`normal`, `attack`, `possible_zero_day`).

## Quick start
```bash
npm install
pip install -r ml/requirements.txt          # TensorFlow/Keras, river, numpy (+ pandas, scikit-learn for training)
npm start                                    # http://127.0.0.1:3000
python3 ml/predict.py --inspect              # optional: verify models match features.json
npm test                                     # feature-extraction tests + end-to-end test
k```
Node 22.13+ and Python 3.10+. Windows: use `python` and set `PYTHON_BIN=python` if needed.
Models are shipped in `ml/artifacts/`, so it runs immediately.

## What changed from the prototype
| Area | Before | Now |
|---|---|---|
| Models | XGBoost + Isolation Forest (pickles) | CNN, FCNN, LSTM (Keras) + FCNN autoencoder. Nothing else except ADWIN |
| Drift | **None.** Static models, static rule, no monitoring | ADWIN monitors, alerts, DB history, warning on verdicts |
| Feature extraction | One "packet" per HTTP request/response | Real socket reads/writes, MSS-split, byte-exact, tested against an independent numpy reference |
| Logging | Sparse | Structured console log of every stage, mirrored in a live console panel |
| UI | Basic | Redesigned landing, login, dashboard (light/dark, mobile) |

Unchanged: endpoints, database tables (old `events.db` is migrated in place), sessions, blocklist, decision
statuses, manual test form.

## Pipeline
```
socket reads/writes -> flow (5-tuple) -> features -> CNN + FCNN + LSTM (P(attack)) -> mean = ensemble
                                                  -> autoencoder (how unlike normal)  -> decision.js -> events/db
                                                  -> ADWIN drift monitors (same worker) -> alerts
```
**Decision** (`backend/decision.js`): ensemble >= 0.5 -> `attack`; otherwise autoencoder error above its
threshold -> `possible_zero_day`; otherwise `normal`. The autoencoder is trained on normal traffic only; its
threshold is the 99.5th percentile of normal validation error. CNN/LSTM read the ordered feature list as a
1-D sequence (the order in `features.json` groups related features).

## Is drift accounted for? (ADWIN)
Yes now; the prototype did not. Live traffic has no labels, so ADWIN watches signals the models produce:
- **Clean-traffic streams** (flows judged normal and familiar): ensemble probability, autoencoder ratio, every model input.
- **Rate streams** (all flows): share of flows unlike the training data, share of attacks.
- Alert rules: a shift in a score stream or in the unusual-flow rate; or 3+ inputs shifting together; attack-rate shifts are notices.
  A minimum effect size per stream ignores statistically real but negligible changes.
- On an alert: logged (`[DRIFT]`), stored in `drift_events`, shown in the dashboard (chip, monitor panel, timeline marker, toast),
  and every verdict for the next 10 min (`DRIFT_ACTIVE_MS`) says drift is suspected.
- It does **not** retrain automatically (no labels; an attacker could steer it). Collect labelled flows and retrain.
- Offline proof: `python ml/drift_demo.py` (control: 0 false alerts; input shift caught ~40 observations after the change;
  concept drift caught by ADWIN on labelled error).

## Feature extraction
A flow is one TCP connection. Each socket read is a forward burst, each write a backward burst, timed with a monotonic
microsecond clock, split into 1460-byte packets (`FLOW_MSS`); a burst's packets share its timestamp (true spacing is unobservable).
Guarantees (`npm test`): forward/backward bytes equal `socket.bytesRead/bytesWritten`; ~2,500 statistic values match numpy;
unmeasurable features (flags, header lengths, window sizes, bulk) are never invented: sent as null, reported as missing, imputed 0, counted per event.
Raw per-read timing uses an internal Node flag (`FLOW_RAW_READS=false` disables it; byte totals stay exact, timing gets coarser).
Items marked `VERIFY` in `flow.js` follow CICFlowMeter conventions from memory.
Active/Idle: an active period is recorded only when an idle gap > 5 s closes it; the period still open at flow end is not added (matches CICIDS2017, where Active Max/Idle Max are 0 for ~80% of benign flows). `data/captured_flows.csv` rows captured before this fix carry the old value; recapture before retraining on them, or replay them with `python ml/diagnose_live.py --legacy-active`.

## Console logging
`[HTTP] [FLOW] [FEAT] [ML] [DECIDE] [EVENT] [BLOCK] [DRIFT] [AUTH] [DB] [PY] [SYS] [DATA]`, one line per step, also in the dashboard's Live console.
`LOG_LEVEL=debug|info|warn|error`, `LOG_FEATURES=full` (print every model input per flow), `LOG_JSON=true`.

## Training data (read this)
The shipped models are trained on **flows captured by this app's own extractor** from simulated traffic
(`tools/simulate_traffic.js`: browsing, dashboard polling, logins vs HTTP flood, login brute force, path scan, slow headers, slow POST).
`slow_headers` and `slow_post` were withheld from training to test the autoencoder.
Held-out results (`ml/artifacts/meta.json`): all three networks and the ensemble F1 = 1.0 on the simulated test split, autoencoder flags 0.2% of normal flows,
and 100% of the two withheld attack families were flagged `possible_zero_day`.
**These numbers come from easy simulated attacks and say nothing about real-world accuracy.** On live benign traffic about 1-2% of flows were flagged unusual
(low confidence, ~0.5-0.7); raise `NETGUARD_NOVELTY_SCALE` to reduce this.

Retrain on your own data:
```bash
# capture (cross-platform flags); label sources via --label-map or the X-NG-Label header
node backend/server.js --capture --dataset=data/captured_flows.csv --label-map=127.0.0.2=http_flood
python ml/train.py --source captured --data data/captured_flows.csv [--holdout name,name] [--max-per-label 5000]
# CICIDS2017 (CICFlowMeter features differ from live ones: expect a distribution shift)
python ml/train.py --source cicids --data "C:/path/MachineLearningCVE" --top 20
```
`train.py` ranks features by mutual information, prunes duplicates, trains the four networks, evaluates, saves `ml/artifacts/`
and enables exactly the chosen features in `ml/features.json`. The worker refuses to start if models and `features.json` disagree.

## Configuration
`PORT`, `HOST`, `TRUST_PROXY_HEADERS`, `BLOCK_ENFORCE`, `BLOCK_LOOPBACK`, `SESSION_IDLE_MS`, `SESSION_MAX_MS`, `NETGUARD_DB`, `PYTHON_BIN`, `PREDICT_TIMEOUT_MS`
(as before) plus: `ML_DISABLED` / `--capture`, `CAPTURE_DATASET`, `CAPTURE_LABEL_MAP`, `ADWIN_DELTA` (0.002), `DRIFT_ACTIVE_MS`,
`NETGUARD_ENSEMBLE_THRESHOLD`, `NETGUARD_NOVELTY_SCALE`, `NETGUARD_MODEL_DIR`, `FLOW_MSS`, `FLOW_INACTIVITY_MS`, `FLOW_TIMEOUT_MS`,
`FLOW_SNAPSHOT_MS`, `SNAPSHOT_EVERY_REQUESTS`, `FLOW_RAW_READS`, `LOG_*`.

## Limits
Web-server view only: no packet headers, SYN floods and scans below HTTP are out of scope. Verdicts are attack vs normal, not attack type.
Drift monitors restart empty when the server restarts. Dashboard polling is itself monitored traffic.


## User-level behaviour (backend/behavior.js)

Each flow is still judged by decision.js, but the status shown for a user comes from their history: a rolling per-entity buffer
(logged-in user, otherwise source IP; in memory, restarts empty). One unusual or ordinary attack flow only makes a user `watch`.
`possible_zero_day` / `attack` need repeated or sustained suspicious flows that also exceed the user's own baseline (older flows,
ratio gap >= `BEHAVIOR_DEVIATION`). A flow where all three networks agree with ensemble >= `BEHAVIOR_IMMEDIATE_PROB` (0.95) escalates
at once and is held `BEHAVIOR_HOLD_MS`. Blocklist entries additionally require the user status to be `attack`.
The LSTM sees the entity's own recent flows once `ml/train.py` has produced a *sequence* LSTM (needs Source IP + Timestamp columns,
e.g. the CICIDS2017 GeneratedLabelledFlows files); with the single-flow LSTM now shipped it is a per-flow vote and the dashboard says so.
API: `/api/behavior` and the `behavior` block of `/api/dashboard`. All thresholds are `BEHAVIOR_*` env vars (see the top of behavior.js).
