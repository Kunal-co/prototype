#!/usr/bin/env node
'use strict';
/**
 * simulate_traffic.js — generates labelled traffic against a running NetGuard-AI so the app's OWN
 * extractor can record training data (see README, "Training data").
 *
 *   # terminal 1: capture mode. Attack sources get their own loopback address, which is how flows are labelled.
 *   node backend/server.js --capture --dataset=data/captured_flows.csv \
 *        --label-map=127.0.0.2=http_flood,127.0.0.3=slow_headers,127.0.0.4=login_bruteforce,127.0.0.5=path_scan,127.0.0.6=slow_post
 *   # terminal 2:
 *   node tools/simulate_traffic.js --seconds 240
 *
 * Needs a platform where 127.0.0.2-6 can be bound (Linux; on macOS: sudo ifconfig lo0 alias 127.0.0.2 ...).
 * Elsewhere, point it at the server with --no-bind and label with the X-NG-Label header instead (--header-labels).
 *
 * Benign traffic imitates people and dashboards: page loads over keep-alive connections with human
 * think times, API polling, logins, occasional bursts of parallel asset requests.
 * Attacks: http_flood (rapid keep-alive GETs), slow_headers (slowloris), login_bruteforce (rapid POSTs, on one
 * connection OR a fresh connection per attempt), path_scan (rapid GETs of missing paths, same two styles),
 * slow_post (a POST body trickled in), conn_flood (traffic spike: bursts of short-lived connections),
 * conn_probe (rapid connect, junk bytes, close: the closest this single-port app sees to a port scan).
 * Every family runs from --copies different source IPs (default 3) so the per-IP LSTM sees several sources per class.
 * The label map for the server is printed at start (or alone with --print-label-map).
 */
const http = require('node:http');
const net = require('node:net');

const arg = (name, dflt) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : dflt;
};
const flag = (name) => process.argv.includes(`--${name}`);
const HOST = arg('host', '127.0.0.1');
const PORT = Number(arg('port', 3000));
const SECONDS = Number(arg('seconds', 180));
const USERS = Number(arg('users', 120));
const SLOW = Number(arg('slow', 30)); // concurrent slow-attack connections per family
const BIND = !flag('no-bind');
const HEADER_LABELS = flag('header-labels');
const FAMILIES = (arg('attacks', 'http_flood,slow_headers,login_bruteforce,path_scan,slow_post,conn_flood,conn_probe')).split(',').filter(Boolean);
const COPIES = Number(arg('copies', 3)); // source IPs per attack family
const ORDER = ['http_flood', 'slow_headers', 'login_bruteforce', 'path_scan', 'slow_post', 'conn_flood', 'conn_probe'];
// copy 0 keeps the original addresses (127.0.0.2 ...); further copies live in 127.2.<family>.<n>
const srcFor = (fam, copy) => (copy === 0 ? `127.0.0.${2 + ORDER.indexOf(fam)}` : `127.2.${ORDER.indexOf(fam)}.${copy}`);
const labelMap = () => FAMILIES.flatMap((f) => Array.from({ length: COPIES }, (_, c) => `${srcFor(f, c)}=${f}`)).join(',');
if (flag('print-label-map')) { console.log(labelMap()); process.exit(0); }
const END = Date.now() + SECONDS * 1000;
const alive = () => Date.now() < END;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const logUniform = (a, b) => Math.exp(rnd(Math.log(a), Math.log(b)));
const pick = (xs) => xs[Math.floor(Math.random() * xs.length)];
const counts = {};
const bump = (k) => { counts[k] = (counts[k] || 0) + 1; };

const AGENTS = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) Safari/605.1', 'Mozilla/5.0 (X11; Linux x86_64) Firefox/125.0', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4) Mobile Safari/604.1'];
const PAGES = ['/', '/index.html', '/login.html'];
const ASSETS = ['/style.css', '/script.js'];

function request(agent, { method = 'GET', path = '/', headers = {}, body, label } = {}) {
  return new Promise((resolve) => {
    const h = { ...headers };
    if (HEADER_LABELS && label) h['X-NG-Label'] = label;
    if (body) { h['Content-Type'] = 'application/json'; h['Content-Length'] = Buffer.byteLength(body); }
    const req = http.request({ host: HOST, port: PORT, method, path, headers: h, agent, localAddress: agent.localAddress }, (res) => {
      res.on('data', () => {}); res.on('end', () => resolve(res)); res.on('error', () => resolve(null));
    });
    req.on('error', () => resolve(null));
    req.setTimeout(15000, () => req.destroy());
    req.end(body);
  });
}
const keepAlive = (localAddress, maxSockets = 4) => Object.assign(new http.Agent({ keepAlive: true, maxSockets, keepAliveMsecs: 1000 }), { localAddress });

/* ----------------------------------------------------------------- benign */

// Each simulated person gets their own loopback address (127.1.x.y) so the server sees one IP per user,
// which is what the per-IP sequence LSTM needs. Without --no-bind everyone shares 127.0.0.1.
const userIp = (i) => `127.1.${Math.floor(i / 250)}.${1 + (i % 250)}`;

async function benignUser(index = 0) {
  const ua = pick(AGENTS);
  const cookie = { value: '' };
  const call = async (agent, o) => {
    const res = await request(agent, { ...o, headers: { 'User-Agent': ua, Cookie: cookie.value, ...(o.headers || {}) } });
    if (res && res.headers['set-cookie']) cookie.value = res.headers['set-cookie'].map((c) => c.split(';')[0]).join('; ');
    bump('benign_requests');
    return res;
  };
  while (alive()) {
    const mode = Math.random();
    const agent = keepAlive(BIND ? userIp(index) : undefined, rint(1, 6));
    try {
      if (mode < 0.48) { // browse: page, then assets in parallel, then a few more pages
        for (let v = rint(1, 5); v > 0 && alive(); v--) {
          await call(agent, { path: pick(PAGES) });
          await Promise.all(ASSETS.map((a) => call(agent, { path: a })));
          await sleep(logUniform(80, 4000));
        }
      } else if (mode < 0.75) { // dashboard user: log in, then poll the API like the dashboard does
        await call(agent, { method: 'POST', path: '/api/login', body: JSON.stringify({ username: `user${rint(1, 9999)}` }) });
        for (let k = rint(2, 8); k > 0 && alive(); k--) {
          await Promise.all(['/api/dashboard', '/api/activity?page=1', '/api/attackers', '/api/blocklist', '/api/timeline?minutes=60', '/api/drift'].map((p) => call(agent, { path: p })));
          await sleep(logUniform(400, 5000));
        }
      } else if (mode < 0.83) { // single quick visit, connection closed
        await call(agent, { path: pick(PAGES), headers: { Connection: 'close' } });
      } else if (mode < 0.93) { // cron job / health check / script: one short-lived connection per poll, seconds apart
        const poller = Object.assign(new http.Agent({ keepAlive: false }), { localAddress: BIND ? userIp(index) : undefined });
        for (let k = rint(5, 25); k > 0 && alive(); k--) {
          await call(poller, { path: pick(['/', '/api/drift', '/login.html']), headers: { Connection: 'close' } });
          await sleep(logUniform(1200, 8000));
        }
      } else { // someone mistyping a username
        await call(agent, { method: 'POST', path: '/api/login', body: JSON.stringify({ username: '!!bad name!!' }) });
        await sleep(logUniform(500, 3000));
        await call(agent, { method: 'POST', path: '/api/login', body: JSON.stringify({ username: `user${rint(1, 9999)}` }) });
      }
    } finally { agent.destroy(); }
    await sleep(logUniform(50, 1500));
  }
}

/* ---------------------------------------------------------------- attacks */

function rawSocket(ip) {
  return new Promise((resolve) => {
    const s = net.connect({ host: HOST, port: PORT, localAddress: BIND ? ip : undefined });
    s.on('error', () => resolve(null)); s.on('connect', () => resolve(s));
    s.on('data', () => {});
  });
}
const label = (fam) => (HEADER_LABELS ? `X-NG-Label: ${fam}\r\n` : '');

const fresh = (ip) => Object.assign(new http.Agent({ keepAlive: false }), { localAddress: BIND ? ip : undefined }); // new connection per request

async function httpFlood(ip) {
  const agent = keepAlive(BIND ? ip : undefined, rint(1, 4));
  const n = rint(60, 400);
  const wave = Array.from({ length: n }, () => request(agent, { path: pick(PAGES), label: 'http_flood', headers: { 'User-Agent': 'flood/1.0' } }).then(() => bump('http_flood_requests')));
  await Promise.all(wave);
  agent.destroy();
}
async function slowHeaders(ip) {
  const s = await rawSocket(ip); if (!s) return;
  s.write(`GET / HTTP/1.1\r\nHost: ${HOST}\r\n${label('slow_headers')}`);
  for (let i = rint(4, 10); i > 0 && alive(); i--) { await sleep(rnd(700, 2500)); s.write(`X-a${rint(1, 999)}: ${rint(1, 9999)}\r\n`); }
  bump('slow_headers_connections'); s.destroy();
}
async function loginBruteforce(ip) {
  const newConn = Math.random() < 0.5; // many scripts open a fresh connection per guess
  const agent = newConn ? fresh(ip) : keepAlive(BIND ? ip : undefined, 1);
  for (let i = rint(60, 300); i > 0 && alive(); i--) {
    if (newConn) await sleep(rnd(0, 40));
    await request(agent, { method: 'POST', path: '/api/login', body: JSON.stringify({ username: `admin${rint(1, 99999)}!` }), label: 'login_bruteforce' });
    bump('login_bruteforce_requests');
  }
  agent.destroy();
}
async function pathScan(ip) {
  const newConn = Math.random() < 0.5;
  const agent = newConn ? fresh(ip) : keepAlive(BIND ? ip : undefined, rint(1, 3));
  const words = ['admin', 'wp-login.php', '.env', 'backup.zip', 'phpmyadmin', 'config.json', 'api/v1/users', 'server-status', '.git/config', 'id_rsa'];
  for (let i = rint(60, 250); i > 0 && alive(); i--) {
    if (newConn) await sleep(rnd(0, 40));
    await request(agent, { path: `/${pick(words)}${rint(0, 999)}`, label: 'path_scan', headers: { 'User-Agent': 'scanner/2.1' } });
    bump('path_scan_requests');
  }
  agent.destroy();
}
async function slowPost(ip) {
  const s = await rawSocket(ip); if (!s) return;
  const len = rint(200, 600);
  s.write(`POST /api/login HTTP/1.1\r\nHost: ${HOST}\r\nContent-Type: application/json\r\nContent-Length: ${len}\r\n${label('slow_post')}\r\n`);
  for (let sent = 0; sent < len && alive(); sent += 8) { await sleep(rnd(250, 1200)); s.write('x'.repeat(Math.min(8, len - sent))); }
  bump('slow_post_connections'); s.destroy();
}
async function connFlood(ip) { // traffic spike: waves of short-lived connections, one request each
  const agent = fresh(ip);
  for (let w = rint(3, 8); w > 0 && alive(); w--) {
    await Promise.all(Array.from({ length: rint(20, 80) }, () => request(agent, { path: pick(PAGES), headers: { Connection: 'close', 'User-Agent': 'burst/1.0' }, label: 'conn_flood' }).then(() => bump('conn_flood_requests'))));
    await sleep(rnd(100, 900));
  }
}
async function connProbe(ip) { // connect, send a few junk bytes, close; over and over
  for (let i = rint(60, 250); i > 0 && alive(); i--) {
    const s = await rawSocket(ip); if (!s) { await sleep(20); continue; }
    s.write(pick(['\r\n', 'GET /\r\n\r\n', 'HEAD / HTTP/1.0\r\n\r\n', 'OPTIONS * HTTP/1.1\r\nHost: x\r\n\r\n']));
    await sleep(rnd(5, 60)); s.destroy(); bump('conn_probe_connections');
    await sleep(rnd(0, 80));
  }
}
const ATTACKS = { http_flood: httpFlood, slow_headers: slowHeaders, login_bruteforce: loginBruteforce, path_scan: pathScan, slow_post: slowPost, conn_flood: connFlood, conn_probe: connProbe };

async function attacker(fam, ip) {
  await sleep(rnd(500, 8000));
  while (alive()) { await ATTACKS[fam](ip); await sleep(logUniform(300, 4000)); }
}

(async () => {
  console.log(`label map for the server: --label-map=${labelMap()}`);
  console.log(`simulating ${USERS} benign users + attackers [${FAMILIES.join(', ')}] against ${HOST}:${PORT} for ${SECONDS}s (bind=${BIND})`);
  const tick = setInterval(() => console.log(`  ${Math.max(0, Math.round((END - Date.now()) / 1000))}s left`, JSON.stringify(counts)), 15000);
  const jobs = Array.from({ length: USERS }, (_, i) => benignUser(i));
  for (const fam of FAMILIES) {
    const slow = fam === 'slow_headers' || fam === 'slow_post';
    for (let c = 0; c < COPIES; c++) for (let i = 0; i < (slow ? Math.ceil(SLOW / COPIES) : 1); i++) jobs.push(attacker(fam, srcFor(fam, c)));
  }
  await Promise.all(jobs);
  clearInterval(tick);
  console.log('done', JSON.stringify(counts));
})();
