'use strict';
/**
 * End-to-end test: boots the real server with the real models, then drives traffic through it.
 * Run: node tests/pipeline.test.js     (needs Python + the packages in ml/requirements.txt)
 *
 * Checks: normal traffic stays normal, a flood is an attack, a slow-header connection (family withheld
 * from training in the shipped models) is a possible zero-day, drift/log/test endpoints respond with the
 * documented shape, a manual test is not stored, and the server shuts down cleanly.
 */
const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { spawn, spawnSync } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0;
const ok = (n) => console.log(`  ok   ${n}`);
const bad = (n, e) => { failures += 1; console.log(`  FAIL ${n}\n       ${e && e.message ? e.message : e}`); };
async function test(name, fn) { try { await fn(); ok(name); } catch (e) { bad(name, e); } }

function freePort() {
  return new Promise((resolve) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
}

function call(port, method, url, { body, cookie, agent } = {}) {
  return new Promise((resolve, reject) => {
    const headers = {};
    if (cookie) headers.Cookie = cookie;
    if (body) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(body); }
    const req = http.request({ host: '127.0.0.1', port, method, path: url, headers, agent: agent || false }, (res) => { // default: one connection per call
      let data = '';
      res.on('data', (d) => { data += d; });
      res.on('end', () => { let json = null; try { json = JSON.parse(data); } catch { /* not JSON */ } resolve({ status: res.statusCode, json, headers: res.headers, text: data }); });
    });
    req.on('error', reject);
    req.end(body);
  });
}

async function waitFor(fn, ms, what) {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error(`timed out waiting for ${what}`);
    await sleep(400);
  }
}

(async () => {
  const probe = spawnSync(process.env.PYTHON_BIN || 'python3', [path.join(ROOT, 'ml', 'predict.py'), '--inspect'], { encoding: 'utf8' });
  if (probe.status !== 0) { console.log(`SKIPPED: the ML engine cannot start here:\n${probe.stdout}${probe.stderr.split('\n').slice(-5).join('\n')}`); process.exit(0); }

  const port = await freePort();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ngtest-'));
  const server = spawn(process.execPath, ['--no-warnings', path.join(ROOT, 'backend', 'server.js')], {
    env: { ...process.env, PORT: String(port), NETGUARD_DB: path.join(dir, 'events.db'), LOG_LEVEL: 'info', NO_COLOR: '1', FLOW_INACTIVITY_MS: '2000', FLOW_SWEEP_MS: '500' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let out = '';
  server.stdout.on('data', (d) => { out += d; }); server.stderr.on('data', (d) => { out += d; });
  const exited = new Promise((r) => server.on('exit', (code) => r(code)));

  try {
    await waitFor(async () => /listening on/.test(out), 15000, 'server to listen');
    const login = await call(port, 'POST', '/api/login', { body: JSON.stringify({ username: 'tester' }) });
    const cookie = (login.headers['set-cookie'] || []).map((c) => c.split(';')[0]).join('; ');
    const api = (m, u, b) => call(port, m, u, { cookie, body: b && JSON.stringify(b) });

    console.log('End-to-end pipeline');
    await test('models come online', async () => {
      await waitFor(async () => (await api('GET', '/api/dashboard')).json.monitoring.engine.ready, 150000, 'models');
    });

    const counts = async () => (await api('GET', '/api/dashboard')).json.stats;

    await test('ordinary browsing is stored as normal', async () => {
      for (let i = 0; i < 6; i++) { await call(port, 'GET', i % 2 ? '/login.html' : '/'); await sleep(150); }
      const s = await waitFor(async () => { const x = await counts(); return x.totalActivity >= 4 ? x : null; }, 20000, 'normal events');
      assert.equal(s.attacks, 0, 'no attack expected from normal browsing');
    });

    await test('a request flood is classified as an attack', async () => {
      const agent = new http.Agent({ keepAlive: true, maxSockets: 1 });
      for (let i = 0; i < 260; i++) await call(port, 'GET', '/', { agent });
      agent.destroy();
      await waitFor(async () => (await counts()).attacks >= 1, 20000, 'attack event');
      const act = (await api('GET', '/api/activity?page=1')).json;
      const a = act.records.find((r) => r.status === 'attack');
      assert.ok(a && a.confidence > 0.5);
      const detail = (await api('GET', `/api/events/${a.eventId}`)).json.event;
      for (const m of ['cnn', 'fcnn', 'lstm']) assert.ok(typeof detail.models[m].probability === 'number', `${m} probability stored`);
      assert.ok(detail.models.ensemble.votes >= 2);
    });

    await test('a slow-header connection (family unseen in training) is a possible zero-day', async () => {
      let sock;
      try { sock = await new Promise((res, rej) => { const s = net.connect({ port, host: '127.0.0.1', localAddress: '127.0.0.9' }); s.once('connect', () => res(s)); s.once('error', rej); }); }
      catch (e) { console.log(`       (skipped: cannot bind 127.0.0.9 here: ${e.code})`); return; }
      sock.on('data', () => {});
      sock.write('GET / HTTP/1.1\r\nHost: x\r\n');
      for (let i = 0; i < 6; i++) { await sleep(900); sock.write(`X-a${i}: 1\r\n`); }
      sock.destroy();
      await waitFor(async () => (await counts()).possibleZeroDays >= 1, 20000, 'possible zero-day event');
    });

    await test('manual test returns the full result and is not stored', async () => {
      const feats = (await api('GET', '/api/features')).json.features;
      const before = (await counts()).totalActivity;
      const r = await api('POST', '/api/test-detection', { features: Object.fromEntries(feats.map((f) => [f.name, 0])) });
      assert.equal(r.status, 200);
      assert.equal(r.json.stored, false);
      assert.ok(['normal', 'attack', 'possible_zero_day'].includes(r.json.result.status));
      for (const m of ['cnn', 'fcnn', 'lstm', 'ensemble', 'novelty']) assert.ok(m in r.json.result.models, m);
      // The test's own HTTP requests are flows too (scored and recorded as normal traffic), and flows from earlier steps may
      // still be finalising, so allow that handful; a stored manual result would add exactly one more per call.
      await sleep(1500);
      const grew = (await counts()).totalActivity - before;
      assert.ok(grew <= 4, `a manual test must not be stored (activity grew by ${grew})`);
      const bad1 = await api('POST', '/api/test-detection', { features: { 'Not A Feature': 1 } });
      assert.equal(bad1.status, 400);
    });

    await test('drift endpoint exposes ADWIN state', async () => {
      const d = (await api('GET', '/api/drift')).json;
      assert.ok(d.summary && typeof d.summary.active === 'boolean');
      assert.ok(d.monitors && d.monitors.streams.length >= 3 && d.monitors.features.length > 0);
      assert.ok(d.monitors.streams.every((s) => typeof s.window === 'number'));
    });

    await test('timeline endpoint returns buckets', async () => {
      const t = (await api('GET', '/api/timeline?minutes=60')).json;
      assert.ok(t.buckets.length >= 10);
      assert.ok(t.buckets.some((b) => b.normal + b.attack + b.possible_zero_day > 0));
    });

    await test('console shows every pipeline stage', async () => {
      const l = (await api('GET', '/api/logs?since=0&limit=500')).json;
      const cats = new Set(l.entries.map((e) => e.cat));
      for (const c of ['HTTP', 'FLOW', 'FEAT', 'ML', 'DECIDE', 'EVENT']) assert.ok(cats.has(c), `no ${c} lines (saw ${[...cats].join(', ')})`);
      for (const c of ['HTTP', 'FLOW', 'FEAT', 'ML', 'DECIDE']) assert.ok(new RegExp(`\\[${c} *\\]`).test(out), `terminal has no ${c} lines`);
    });

    await test('login is required for protected routes', async () => {
      assert.equal((await call(port, 'GET', '/api/drift')).status, 401);
      assert.equal((await call(port, 'GET', '/api/logs')).status, 401);
    });

    await test('server shuts down cleanly on SIGINT', async () => {
      server.kill('SIGINT');
      const code = await Promise.race([exited, sleep(15000).then(() => 'timeout')]);
      assert.equal(code, 0, `exit code ${code}`);
    });
  } catch (e) { bad('setup', e); } finally {
    if (server.exitCode === null) server.kill('SIGKILL');
    if (failures) console.log(`\n--- server output (tail) ---\n${out.split('\n').slice(-40).join('\n')}`);
    fs.rmSync(dir, { recursive: true, force: true });
  }
  console.log(failures ? `\n${failures} test(s) FAILED` : '\nAll pipeline tests passed');
  process.exit(failures ? 1 : 0);
})();
