'use strict';
/** Unit tests for backend/behavior.js (user-level aggregation). Pure logic, no server, no models. */
const assert = require('node:assert/strict');
const behavior = require('../backend/behavior');

let n = 0; let failed = 0;
function test(name, fn) {
  behavior.reset();
  try { fn(); n += 1; console.log(`  ok   ${name}`); } catch (e) { failed += 1; console.log(`  FAIL ${name}\n       ${e.message}`); }
}
const MIN = 60 * 1000;
let seq = 0;
const decision = (status, { p = status === 'attack' ? 0.7 : 0.1, votes = status === 'attack' ? 2 : 0, lstm = 0.1, window } = {}) => ({
  status,
  models: { lstm: { probability: lstm, ...(window ? { window } : {}) }, ensemble: { probability: p, votes }, novelty: { ratio: status === 'possible_zero_day' ? 2.5 : 0.5 } },
});
const feed = (who, statuses, t0, step = 5000, opts) => {
  let out = null; let t = t0;
  for (const s of statuses) { out = behavior.observe({ flowId: `f${seq++}`, ...who }, decision(s, opts), t); t += step; }
  return out;
};
const U = { userId: 'user-1', sourceIp: '10.0.0.1' };
const T0 = 1_700_000_000_000;
const many = (s, k) => Array(k).fill(s);

console.log('behavior.js');
test('one possible_zero_day does not make the user a zero-day', () => {
  const r = feed(U, [...many('normal', 12), 'possible_zero_day'], T0);
  assert.equal(r.status, 'watch'); assert.equal(r.pattern, 'isolated');
});
test('one ordinary attack flow (not all models, ensemble < 0.95) only raises watch', () => {
  const r = feed(U, [...many('normal', 12), 'attack'], T0);
  assert.equal(r.status, 'watch');
});
test('immediate alert for a high-confidence attack where every model agrees, held for HOLD_MS', () => {
  feed(U, many('normal', 12), T0);
  const r = behavior.observe({ flowId: 'hc', ...U }, decision('attack', { p: 0.99, votes: 3 }), T0 + 70_000);
  assert.equal(r.status, 'attack'); assert.equal(r.pattern, 'immediate'); assert.equal(r.severity, 'critical');
  assert.equal(behavior.get('u:user-1', T0 + 70_000 + 4 * MIN).status, 'attack');
  assert.notEqual(behavior.get('u:user-1', T0 + 70_000 + 6 * MIN).status, 'attack'); // hold expired, history decides
});
test('high ensemble probability without full agreement is not immediate', () => {
  const r = feed(U, [...many('normal', 12), 'attack'], T0, 5000, { p: 0.97, votes: 2 });
  assert.equal(r.status, 'watch');
});
test('repeated zero-days that depart from the user\'s baseline escalate', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  const r = feed(U, many('possible_zero_day', 3), T0);
  assert.equal(r.status, 'possible_zero_day'); assert.equal(r.pattern, 'repeated');
});
test('sustained run escalates severity', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  const r = feed(U, many('possible_zero_day', 6), T0);
  assert.equal(r.status, 'possible_zero_day'); assert.equal(r.pattern, 'sustained'); assert.equal(r.severity, 'critical');
});
test('repeated attack flows escalate to attack without an immediate alert', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  const r = feed(U, many('attack', 4), T0);
  assert.equal(r.status, 'attack'); assert.ok(['repeated', 'sustained'].includes(r.pattern));
});
test('a user who is ALWAYS unusual is judged against their own baseline, not escalated for steady behaviour', () => {
  const mix = [];
  for (let i = 0; i < 40; i++) mix.push(i % 3 === 0 ? 'normal' : 'possible_zero_day'); // ~67% unusual, steady
  feed(U, mix, T0 - 60 * MIN, 60_000);
  const r = feed(U, mix.slice(0, 12), T0, 10_000);
  assert.equal(r.status, 'watch');
  assert.match(r.reason, /baseline/);
});
test('...but a hard ratio overrides the baseline (cannot hide an attack by poisoning it)', () => {
  const mix = [];
  for (let i = 0; i < 40; i++) mix.push(i % 3 === 0 ? 'normal' : 'possible_zero_day');
  feed(U, mix, T0 - 60 * MIN, 60_000);
  const r = feed(U, many('possible_zero_day', 8), T0, 10_000);
  assert.equal(r.status, 'possible_zero_day');
});
test('status de-escalates as normal flows accumulate and as time passes', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  feed(U, many('possible_zero_day', 4), T0);
  assert.equal(behavior.get('u:user-1', T0 + 30_000).status, 'possible_zero_day');
  const r = feed(U, many('normal', 20), T0 + 60_000);
  assert.ok(['normal', 'watch'].includes(r.status));
  assert.equal(behavior.get('u:user-1', T0 + 40 * MIN).status, 'normal'); // recent window empty
});
test('a snapshot and its final report of the same flow count once', () => {
  const f = { flowId: 'same', ...U };
  behavior.observe(f, decision('possible_zero_day'), T0);
  const r = behavior.observe(f, decision('normal'), T0 + 10_000);
  assert.equal(r.totalFlows, 1); assert.equal(r.recent.possibleZeroDay, 0); assert.equal(r.status, 'normal');
});
test('entities are independent; anonymous traffic is keyed by IP', () => {
  feed(U, many('possible_zero_day', 4), T0);
  const anon = feed({ userId: null, sourceIp: '203.0.113.9' }, ['normal'], T0);
  assert.equal(anon.key, 'ip:203.0.113.9'); assert.equal(anon.status, 'normal');
  const now = T0 + 30_000;
  assert.equal(behavior.overview({ now }).state, 'possible_zero_day');
  assert.equal(behavior.overview({ keys: ['ip:203.0.113.9'], now }).state, 'normal');
});
test('sequence LSTM votes corroborate: two unusual flows plus hostile sequence verdicts escalate', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  const r = feed(U, ['possible_zero_day', 'possible_zero_day'], T0, 5000, { lstm: 0.9, window: 8 });
  assert.equal(r.status, 'possible_zero_day'); assert.equal(r.lstm.mode, 'sequence'); assert.equal(r.lstm.corroborates, true);
});
test('single-flow LSTM is reported as such and gives no corroboration', () => {
  feed(U, many('normal', 30), T0 - 40 * MIN, 30_000);
  const r = feed(U, ['possible_zero_day', 'possible_zero_day'], T0, 5000, { lstm: 0.9 });
  assert.equal(r.status, 'watch'); assert.equal(r.lstm.mode, 'single-flow');
});
test('history is bounded', () => {
  feed(U, many('normal', behavior.CFG.historyMax + 50), T0, 1000);
  assert.ok(behavior.get('u:user-1', T0 + 1e6).totalFlows >= behavior.CFG.historyMax); // counter keeps total, buffer is capped
});

console.log(failed ? `\n${failed} behavior test(s) FAILED` : `\nAll ${n} behavior tests passed`);
process.exit(failed ? 1 : 0);
