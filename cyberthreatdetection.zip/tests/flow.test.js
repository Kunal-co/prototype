'use strict';
/**
 * Feature-extraction tests. Run: node tests/flow.test.js
 *
 *  Part A  every flow statistic vs. an independent numpy implementation (tests/feature_reference.py),
 *          on hand-built and randomised packet timelines, including edge cases.
 *  Part B  real TCP: byte totals of the measured flow must equal what a raw client really
 *          sent/received, packet counts must follow the MSS split, and (when raw reads are
 *          active) a trickled request must show its real inter-arrival gaps.
 */
process.env.LOG_LEVEL = process.env.LOG_LEVEL || 'error';
process.env.FLOW_INACTIVITY_MS = '60000';
process.env.FLOW_SNAPSHOT_MS = '600000';
const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const flow = require('../backend/flow');

const { Flow, computeFeatures, CFG } = flow._internals;
let failures = 0;
const ok = (name) => console.log(`  ok   ${name}`);
const bad = (name, err) => { failures += 1; console.log(`  FAIL ${name}\n       ${err && err.message ? err.message : err}`); };
async function test(name, fn) { try { await fn(); ok(name); } catch (e) { bad(name, e); } }

/* ------------------------------------------------------------------ Part A */

function mulberry(seed) { let a = seed; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

function scenarios() {
  const S = {};
  S.simple_exchange = [{ t: 0, d: 'f', len: 420 }, { t: 1500, d: 'b', len: 1460 }, { t: 1500, d: 'b', len: 1460 }, { t: 2100, d: 'b', len: 311 }];
  S.subflow_gap = [{ t: 0, d: 'f', len: 100 }, { t: 400, d: 'b', len: 900 }, { t: 1_600_400, d: 'f', len: 100 }, { t: 1_601_000, d: 'b', len: 50 }, { t: 3_000_000, d: 'f', len: 0 }];
  S.idle_periods = [{ t: 0, d: 'f', len: 200 }, { t: 1000, d: 'b', len: 700 }, { t: 7_000_000, d: 'f', len: 200 }, { t: 7_000_900, d: 'b', len: 500 }, { t: 20_000_000, d: 'f', len: 90 }, { t: 20_000_400, d: 'b', len: 10 }];
  S.one_direction = [{ t: 0, d: 'f', len: 300 }, { t: 90, d: 'f', len: 300 }, { t: 250, d: 'f', len: 12 }];
  S.single_packet = [{ t: 5, d: 'f', len: 77 }];
  S.zero_len_packets = [{ t: 0, d: 'f', len: 0 }, { t: 10, d: 'b', len: 0 }, { t: 20, d: 'f', len: 5 }];
  S.same_instant = [{ t: 100, d: 'f', len: 10 }, { t: 100, d: 'b', len: 20 }, { t: 100, d: 'f', len: 30 }];
  S.down_up_truncation = [{ t: 0, d: 'f', len: 10 }, { t: 5, d: 'b', len: 10 }, { t: 6, d: 'b', len: 10 }, { t: 7, d: 'b', len: 10 }, { t: 8, d: 'f', len: 10 }];
  const rnd = mulberry(1234);
  for (let k = 0; k < 40; k++) {
    const n = 2 + Math.floor(rnd() * 300);
    let t = Math.floor(rnd() * 1e6);
    const pk = [];
    for (let i = 0; i < n; i++) {
      const r = rnd();
      t += r < 0.5 ? Math.floor(rnd() * 5000) : r < 0.9 ? Math.floor(rnd() * 400000) : Math.floor(rnd() * 12_000_000);
      pk.push({ t, d: rnd() < 0.4 ? 'f' : 'b', len: rnd() < 0.15 ? 0 : Math.floor(rnd() * 1461) });
    }
    S[`random_${k}`] = pk;
  }
  return S;
}

function buildFlow(packets, dstPort) {
  const ep = { srcIp: '10.0.0.1', srcPort: 50000, dstIp: '10.0.0.2', dstPort, protocol: 'TCP' };
  const fl = new Flow('k', ep);
  for (const p of packets) fl.addPackets(p.t, p.d === 'f' ? 'fwd' : 'bwd', p.len, 1);
  return fl;
}

function close(a, b) {
  if (a === null || b === null) return a === b;
  return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b));
}

async function partA() {
  console.log('Part A: statistics vs independent numpy reference');
  const sc = scenarios();
  const input = {};
  for (const [name, packets] of Object.entries(sc)) input[name] = { packets };
  const ref = spawnSync('python3', ['-I', path.join(__dirname, 'feature_reference.py')], { input: JSON.stringify(input), maxBuffer: 1 << 26 });
  if (ref.status !== 0) throw new Error(`reference failed: ${ref.stderr}`);
  const expected = JSON.parse(ref.stdout.toString());
  let compared = 0;
  for (const [name, packets] of Object.entries(sc)) {
    await test(`scenario ${name}`, () => {
      const got = computeFeatures(buildFlow(packets, 80));
      assert.equal(got['Destination Port'], 80);
      for (const [feat, want] of Object.entries(expected[name])) {
        if (feat === 'Destination Port') continue;
        assert.ok(feat in got, `feature "${feat}" missing from extractor`);
        assert.ok(close(got[feat], want), `${feat}: extractor=${got[feat]} reference=${want}`);
        compared += 1;
      }
    });
  }
  console.log(`  ${compared} feature values compared`);
  await test('every measurable schema feature is produced', () => {
    const got = computeFeatures(buildFlow(scenarios().simple_exchange, 80));
    for (const n of flow.SCHEMA.measurable) assert.ok(n in got, `schema feature "${n}" is never computed`);
  });
  await test('Stats.addRepeated equals adding one by one', () => {
    const a = new flow._internals.Stats(); const b = new flow._internals.Stats();
    for (let i = 0; i < 37; i++) a.add(1460);
    b.addRepeated(1460, 37);
    for (const x of [5, 9, 1460, 3]) { a.add(x); b.add(x); }
    for (const k of ['n', 'sum', 'mean', 'min', 'max']) assert.ok(close(a[k], b[k]), k);
    assert.ok(close(a.stdV, b.stdV));
  });
}

/* ------------------------------------------------------------------ Part B */

function startServer() {
  const server = http.createServer((req, res) => {
    flow.captureMiddleware(req, res, () => {
      if (req.url.startsWith('/big')) { res.end(Buffer.alloc(500000, 97)); return; }
      if (req.method === 'POST') { req.resume(); req.on('end', () => res.end('ok')); return; }
      res.end('hello');
    });
  });
  server.prependListener('connection', flow.attachSocket);
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

const nextReport = () => new Promise((resolve) => flow.events.once('flow', resolve));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Open a socket, run `script(sock)`, return {sent, received, report} once the server has closed the flow. */
async function exchange(port, script) {
  const sock = net.connect(port, '127.0.0.1');
  await new Promise((r) => sock.once('connect', r));
  const st = { sent: 0, received: 0 };
  const origWrite = sock.write.bind(sock);
  sock.write = (d, ...a) => { st.sent += Buffer.byteLength(d); return origWrite(d, ...a); };
  sock.on('data', (d) => { st.received += d.length; });
  const done = nextReport();
  await script(sock);
  sock.end();
  const rep = await done;
  return { ...st, rep };
}

async function partB() {
  console.log('Part B: real TCP sockets');
  const server = await startServer();
  const port = server.address().port;
  const req = (p, extra = '') => `GET ${p} HTTP/1.1\r\nHost: x\r\n${extra}\r\n`;

  await test('three keep-alive requests: bytes match exactly', async () => {
    const r = await exchange(port, async (s) => {
      for (let i = 0; i < 3; i++) { s.write(req(`/a${i}`)); await sleep(60); }
    });
    assert.equal(r.rep.bytesFwd, r.sent, 'forward bytes vs bytes the client wrote');
    assert.equal(r.rep.bytesBwd, r.received, 'backward bytes vs bytes the client read');
    assert.equal(r.rep.requests, 3);
    assert.equal(r.rep.final, true);
  });

  await test('500 KB response: bytes exact and packets follow the MSS split', async () => {
    const r = await exchange(port, async (s) => { s.write(req('/big')); await sleep(400); });
    assert.equal(r.rep.bytesBwd, r.received);
    assert.ok(r.received > 500000);
    assert.equal(r.rep.packetsBwd >= Math.floor(r.received / CFG.mss), true, `got ${r.rep.packetsBwd} packets`);
    assert.equal(r.rep.packetsBwd <= Math.ceil(r.received / CFG.mss) + 16, true, `got ${r.rep.packetsBwd} packets`);
    assert.equal(r.rep.features['Bwd Packet Length Max'], CFG.mss);
  });

  await test('request body trickled in pieces: bytes exact, no request lost', async () => {
    const r = await exchange(port, async (s) => {
      s.write('POST /p HTTP/1.1\r\nHost: x\r\nContent-Length: 30\r\n\r\n');
      for (let i = 0; i < 3; i++) { await sleep(120); s.write('0123456789'); }
      await sleep(120);
    });
    assert.equal(r.rep.bytesFwd, r.sent);
    assert.equal(r.rep.bytesBwd, r.received);
    assert.equal(r.rep.requests, 1);
  });

  await test('slow request (header bytes trickled) shows real inter-arrival gaps', async () => {
    const r = await exchange(port, async (s) => {
      s.write('GET /s HTTP/1.1\r\n');
      await sleep(250);
      s.write('Host: x\r\n');
      await sleep(250);
      s.write('\r\n');
      await sleep(100);
    });
    assert.equal(r.rep.bytesFwd, r.sent);
    if (CFG.rawReads) {
      assert.equal(r.rep.durationUs >= 450000, true, `duration ${r.rep.durationUs}us`); // with raw reads off only totals are exact; timing is coarser by design
      const iat = r.rep.features['Fwd IAT Max'];
      assert.ok(iat >= 200000, `Fwd IAT Max ${iat}us should be >= 200ms`);
      assert.ok(r.rep.packetsFwd >= 3, `expected the 3 trickled writes as separate packets, got ${r.rep.packetsFwd}`);
    }
  });

  await test('connection that never completes a request is still measured', async () => {
    const r = await exchange(port, async (s) => { s.write('GET /never HTTP/1.1\r\nHost: x\r\n'); await sleep(80); });
    assert.equal(r.rep.bytesFwd, r.sent);
    assert.equal(r.rep.requests, 0);
  });

  await test('two connections are two separate flows', async () => {
    const a = exchange(port, async (s) => { s.write(req('/x')); await sleep(100); });
    const reps = [];
    const h = (r) => reps.push(r);
    flow.events.on('flow', h);
    const b = exchange(port, async (s) => { s.write(req('/y')); await sleep(100); });
    await Promise.all([a, b]);
    await sleep(50);
    flow.events.off('flow', h);
    assert.equal(new Set(reps.map((r) => r.flowId)).size, 2);
  });

  await new Promise((r) => server.close(r));
  server.closeAllConnections?.();
}

(async () => {
  try {
    await partA();
    await partB();
  } catch (e) { bad('test run', e); }
  flow.shutdown();
  console.log(failures ? `\n${failures} test(s) FAILED` : '\nAll feature-extraction tests passed');
  process.exit(failures ? 1 : 0);
})();
