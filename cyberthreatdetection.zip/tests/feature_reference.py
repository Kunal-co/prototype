#!/usr/bin/env python3
"""
Independent reference implementation of the flow features (numpy, written separately
from backend/flow.js). tests/flow.test.js feeds both the same packet lists and compares.

stdin : JSON  {"scenario": {"packets": [{"t": us, "d": "f"|"b", "len": n}, ...]}, ...}
stdout: JSON  {"scenario": {feature: value|null}, ...}
"""
import json
import sys

import numpy as np

ACTIVITY_TIMEOUT_US = 5_000_000
SUBFLOW_GAP_US = 1_000_000


def sd(a, ddof=1):
    return float(np.std(a, ddof=1)) if len(a) > 1 else 0.0


def var(a):
    return float(np.var(a, ddof=1)) if len(a) > 1 else 0.0


def stats(a):
    a = np.asarray(a, dtype=float)
    if a.size == 0:
        return dict(mean=0.0, std=0.0, min=0.0, max=0.0, sum=0.0)
    return dict(mean=float(a.mean()), std=sd(a), min=float(a.min()), max=float(a.max()), sum=float(a.sum()))


def active_idle(t):
    """Split the packet timeline into active periods separated by idle gaps > 5 s."""
    active, idle = [], []
    start = end = t[0]
    for x in t[1:]:
        if x - end > ACTIVITY_TIMEOUT_US:
            if end - start > 0:
                active.append(end - start)
            idle.append(x - end)
            start = end = x
        else:
            end = x
    # The period still open at the end of the flow is NOT recorded (CICFlowMeter / CICIDS2017 convention).
    return active, idle


def compute(packets):
    t = np.array([p["t"] for p in packets], dtype=float)
    d = np.array([p["d"] for p in packets])
    n = np.array([p["len"] for p in packets], dtype=float)
    f, b = d == "f", d == "b"
    tf, tb, nf, nb = t[f], t[b], n[f], n[b]

    dur = t[-1] - t[0]
    sec = dur / 1e6
    rate = lambda x: (x / sec) if sec > 0 else None

    iat_all = np.diff(t)
    iat_f, iat_b = np.diff(tf), np.diff(tb)
    gaps = int((iat_all > SUBFLOW_GAP_US).sum())
    sf = 1 + gaps
    act, idl = active_idle(t)
    A, I = stats(act), stats(idl)
    S, F, B = stats(n), stats(nf), stats(nb)
    IA, IF, IB = stats(iat_all), stats(iat_f), stats(iat_b)

    return {
        "Destination Port": None,  # supplied by the caller, not derived from packets
        "Flow Duration": float(round(dur)),
        "Total Fwd Packets": float(f.sum()), "Total Backward Packets": float(b.sum()),
        "Total Length of Fwd Packets": float(nf.sum()), "Total Length of Bwd Packets": float(nb.sum()),
        "Fwd Packet Length Max": F["max"], "Fwd Packet Length Min": F["min"],
        "Fwd Packet Length Mean": F["mean"], "Fwd Packet Length Std": F["std"],
        "Bwd Packet Length Max": B["max"], "Bwd Packet Length Min": B["min"],
        "Bwd Packet Length Mean": B["mean"], "Bwd Packet Length Std": B["std"],
        "Flow Bytes/s": rate(float(n.sum())), "Flow Packets/s": rate(float(len(n))),
        "Flow IAT Mean": IA["mean"], "Flow IAT Std": IA["std"], "Flow IAT Max": IA["max"], "Flow IAT Min": IA["min"],
        "Fwd IAT Total": IF["sum"], "Fwd IAT Mean": IF["mean"], "Fwd IAT Std": IF["std"],
        "Fwd IAT Max": IF["max"], "Fwd IAT Min": IF["min"],
        "Bwd IAT Total": IB["sum"], "Bwd IAT Mean": IB["mean"], "Bwd IAT Std": IB["std"],
        "Bwd IAT Max": IB["max"], "Bwd IAT Min": IB["min"],
        "Fwd Packets/s": rate(float(f.sum())), "Bwd Packets/s": rate(float(b.sum())),
        "Min Packet Length": S["min"], "Max Packet Length": S["max"],
        "Packet Length Mean": S["mean"], "Packet Length Std": S["std"], "Packet Length Variance": var(n),
        "Down/Up Ratio": float(int(b.sum()) // int(f.sum())) if f.sum() > 0 else 0.0,
        "Average Packet Size": S["mean"],
        "Avg Fwd Segment Size": F["mean"], "Avg Bwd Segment Size": B["mean"],
        "Subflow Fwd Packets": float(f.sum()) / sf, "Subflow Fwd Bytes": float(nf.sum()) / sf,
        "Subflow Bwd Packets": float(b.sum()) / sf, "Subflow Bwd Bytes": float(nb.sum()) / sf,
        "act_data_pkt_fwd": float((nf > 0).sum()),
        "Active Mean": A["mean"], "Active Std": A["std"], "Active Max": A["max"], "Active Min": A["min"],
        "Idle Mean": I["mean"], "Idle Std": I["std"], "Idle Max": I["max"], "Idle Min": I["min"],
    }


if __name__ == "__main__":
    scenarios = json.load(sys.stdin)
    json.dump({name: compute(sc["packets"]) for name, sc in scenarios.items()}, sys.stdout)
