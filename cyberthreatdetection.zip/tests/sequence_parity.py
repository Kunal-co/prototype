#!/usr/bin/env python3
"""
The LSTM's windows are built in two places: train.py (offline, from the whole CSV) and predict.py (live, flow by
flow). Both must produce IDENTICAL windows or the model is fed data it never saw in training. This test replays a
synthetic multi-IP flow stream through the live IpHistory and compares every window with the offline construction.

  python3 tests/sequence_parity.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))
import common  # noqa: E402
from predict import IpHistory  # noqa: E402

rng = np.random.default_rng(7)
N_FEAT, T = 6, common.SEQ_LEN
flows = []  # (ip, flow_id, start_ms, z)
for ip in ("10.0.0.1", "10.0.0.2", "10.0.0.3"):
    start = 1_700_000_000_000 + int(rng.integers(0, 5000))
    for i in range(int(rng.integers(3, 30))):
        start += int(rng.integers(1, 4000))
        flows.append((ip, f"{ip}#{i}", start, rng.normal(size=N_FEAT).astype(np.float32)))
live_order = sorted(flows, key=lambda f: f[2])   # the app sees flows interleaved across IPs, in time order

hist = IpHistory(T)
live = {}
for ip, fid, ms, z in live_order:
    win, k = hist.window(ip, fid, ms, z, commit=True)
    live[fid] = (win, k)

for ip in ("10.0.0.1", "10.0.0.2", "10.0.0.3"):
    own = sorted((f for f in flows if f[0] == ip), key=lambda f: f[2])
    Z = np.array([f[3] for f in own]); t = np.array([f[2] / 1000.0 for f in own])
    for i, f in enumerate(own):
        expect = common.make_window(Z[max(0, i - T + 1):i + 1], t[max(0, i - T + 1):i + 1], T)
        got, k = live[f[1]]
        assert got.shape == (T, N_FEAT + 2) == expect.shape, (got.shape, expect.shape)
        assert np.allclose(got, expect, atol=1e-6), f"window mismatch for {f[1]}"
        assert k == min(i + 1, T)
print("ok: live per-IP windows equal the training windows for every flow")

# a second report of the same flow (snapshot -> final) replaces it instead of adding a step
ip, fid, ms, z = live_order[-1]
before = len(hist.ips[ip])
hist.window(ip, fid, ms, z + 1.0, commit=True)
assert len(hist.ips[ip]) == before, "re-reporting a flow must not duplicate it"
# commit=False (manual tests) must leave the history untouched
snapshot = {k: list(v) for k, v in hist.ips.items()}
hist.window(ip, "brand-new", ms + 10, z, commit=False)
assert {k: list(v) for k, v in hist.ips.items()} == snapshot, "commit=False modified the history"
# a different IP never leaks into this IP's window
win, k = hist.window("192.0.2.9", "x", ms, z, commit=False)
assert k == 1 and win[:-1].sum() == 0
print("ok: snapshot replacement, no-commit mode and IP isolation")
