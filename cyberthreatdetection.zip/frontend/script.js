'use strict';
/* NetGuard-AI frontend. API calls and rendering only: no ML logic lives here. */
(() => {
  const PAGE = document.body.dataset.page;
  const $ = (id) => document.getElementById(id);
  const SVGNS = 'http://www.w3.org/2000/svg';

  /* ------------------------------------------------------------ helpers */

  // Builds DOM with textContent only, so server-supplied strings can never inject markup.
  function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'data-id') el.dataset.id = v;
      else if (k === 'style' && typeof v === 'object') for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }
  function s(tag, attrs = {}, ...kids) {
    const el = document.createElementNS(SVGNS, tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    for (const kid of kids.flat()) if (kid != null) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  }

  async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch(path, {
      method, credentials: 'same-origin',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON (e.g. 403 text) */ }
    if (res.status === 401 && PAGE === 'dashboard') { location.href = 'login.html'; throw new Error('Login required'); }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Request failed (${res.status})`);
      err.details = (data && data.details) || [];
      err.status = res.status;
      throw err;
    }
    return data;
  }

  const LABEL = { normal: 'NORMAL', watch: 'WATCH', attack: 'ATTACK DETECTED', possible_zero_day: 'POSSIBLE ZERO-DAY' };
  const TYPE = { normal: 'Normal', attack: 'Attack', possible_zero_day: 'Possible zero-day' };
  const time = (iso) => (iso ? new Date(iso).toLocaleString() : '—');
  const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '');
  const pct = (x) => (typeof x === 'number' ? `${(x * 100).toFixed(1)}%` : '—');
  const val = (x) => (x === null || x === undefined || x === '' ? '—' : x);
  const pill = (status) => h('span', { class: `pill ${status}` }, TYPE[status] || (status === 'watch' ? 'Watch' : status));
  const COLORS = { normal: 'var(--ok)', attack: 'var(--bad)', possible_zero_day: 'var(--zd)' };
  const confBar = (r) => h('span', { class: 'conf' }, h('i', { style: { '--w': `${Math.round((r.confidence || 0) * 100)}%`, '--c': COLORS[r.status] } }), pct(r.confidence));

  /* ------------------------------------------------------------ theme */

  function initTheme() {
    let saved = null;
    try { saved = localStorage.getItem('ng-theme'); } catch { /* storage blocked */ }
    if (saved === 'light' || saved === 'dark') document.documentElement.dataset.theme = saved;
    const btn = $('theme-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const dark = document.documentElement.dataset.theme
        ? document.documentElement.dataset.theme === 'dark'
        : matchMedia('(prefers-color-scheme: dark)').matches;
      const next = dark ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      try { localStorage.setItem('ng-theme', next); } catch { /* storage blocked */ }
      window.dispatchEvent(new Event('ng-theme'));
    });
  }

  /* ------------------------------------------------ stream illustration */
  /* A stylised stream of flows with an adaptive window. It is an illustration, not live data:
     the window grows while the stream is stable and snaps to the newest part after a change,
     which is how ADWIN behaves on the real signals. */

  function initStream(canvas) {
    const ctx = canvas.getContext('2d');
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const TICK = 8;
    let W = 0; let H = 0; let dpr = 1;
    let ticks = []; let n = 0; let regimeMean = 0.28; let flipAt = 150;
    let changeAt = -1; let windowStart = 0; let targetStart = 0; let windowNote = '';
    const css = () => {
      const cs = getComputedStyle(document.documentElement);
      const g = (v) => cs.getPropertyValue(v).trim();
      return { ok: g('--ok'), bad: g('--bad'), zd: g('--zd'), win: g('--window'), winLine: g('--window-line'), muted: g('--muted') };
    };
    let col = css();
    window.addEventListener('ng-theme', () => { col = css(); draw(); });

    function resize() {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      const r = canvas.getBoundingClientRect();
      W = r.width; H = r.height;
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw();
    }

    function step() {
      n += 1;
      if (n === flipAt) { regimeMean = regimeMean < 0.4 ? 0.62 : 0.28; changeAt = n; flipAt = n + 200; }
      const r = Math.random();
      const kind = r < 0.025 ? 'bad' : r < 0.045 ? 'zd' : 'ok';
      const noise = (Math.random() + Math.random() + Math.random() - 1.5) * 0.3;
      const v = Math.max(0.06, Math.min(1, kind === 'bad' ? 0.88 + Math.random() * 0.1 : kind === 'zd' ? 0.12 : regimeMean + noise));
      ticks.push({ id: n, v, kind });
      const cap = Math.ceil(W / TICK) + 2;
      if (ticks.length > cap) ticks.shift();
      if (changeAt > 0 && n - changeAt === 30) targetStart = changeAt; // ADWIN notices ~30 flows after the change
      windowStart += (targetStart - windowStart) * 0.12;
      if (Math.abs(targetStart - windowStart) < 0.5) windowStart = targetStart;
      windowNote = `window ${Math.max(1, Math.round(n - windowStart))} flows`;
    }

    function draw() {
      ctx.clearRect(0, 0, W, H);
      if (!ticks.length) return;
      const baseY = H - 22; const maxH = H - 56;
      const right = W - 4;
      const xOf = (id) => right - (n - id) * TICK;
      const x0 = Math.max(6, xOf(windowStart));
      ctx.fillStyle = col.win; ctx.globalAlpha = 0.3;
      ctx.fillRect(x0, 22, right - x0 + 2, baseY - 22 + 6);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = col.winLine; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x0, 30); ctx.lineTo(x0, 16); ctx.lineTo(right, 16); ctx.lineTo(right, 30); ctx.stroke();
      ctx.fillStyle = col.muted; ctx.font = '12px system-ui, sans-serif'; ctx.textBaseline = 'alphabetic';
      ctx.fillText(windowNote, Math.max(10, x0 + 6), 11);
      if (changeAt > 0) {
        const cx = xOf(changeAt);
        if (cx > 0) {
          ctx.setLineDash([3, 4]); ctx.strokeStyle = col.muted; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(cx, 34); ctx.lineTo(cx, baseY + 6); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillText('traffic changes', cx + 5, baseY + 18);
        }
      }
      for (const t of ticks) {
        const x = xOf(t.id);
        ctx.fillStyle = col[t.kind];
        const hh = t.v * maxH;
        ctx.fillRect(x, baseY - hh, TICK - 3, hh);
      }
      ctx.fillStyle = col.muted; ctx.fillRect(0, baseY + 1, W, 1);
    }

    resize();
    window.addEventListener('resize', resize);
    // Warm start so the first frame already shows a window and a change.
    for (let i = 0; i < 260; i += 1) step();
    if (reduce) { draw(); return; }
    let last = 0;
    const loop = (ts) => {
      if (!document.hidden && ts - last > 85) { last = ts; step(); draw(); }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  /* ------------------------------------------------------------ login */

  function initLogin() {
    const form = $('login-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      $('login-error').textContent = '';
      try {
        await api('/api/login', { method: 'POST', body: { username: $('username').value } });
        location.href = 'dashboard.html';
      } catch (err) {
        $('login-error').textContent = err.message;
      }
    });
  }

  /* -------------------------------------------------------- dashboard */

  const state = {
    page: 1, totalPages: 1, scope: 'all', features: [], timer: null,
    lastAlerts: null, logSince: 0, logPaused: false, logFilter: '', driftMarks: [],
  };

  function renderStatus(status, stats) {
    const band = $('status-band');
    band.className = `band ${status.state}`;
    $('status-text').textContent = LABEL[status.state];
    const worst = status.behavior && status.behavior.worst;
    $('status-sub').textContent = status.state === 'normal'
      ? 'Every user is behaving normally. Flow counts below are individual flows, not users.'
      : worst ? `${worst.key}: ${worst.reason}.` : `Last threat seen ${time(status.lastThreat)}.`;
    $('st-total').textContent = stats.totalActivity;
    $('st-attacks').textContent = stats.attacks;
    $('st-attack-req').textContent = stats.attacks ? `(${stats.attackRequests} requests)` : '';
    $('st-anomalies').textContent = stats.anomalies;
    $('st-zd').textContent = stats.possibleZeroDays;
  }

  /* user-level behavioural aggregation (backend/behavior.js) */
  const ratioText = (x) => (typeof x === 'number' ? `${Math.round(x * 100)}%` : '—');
  function renderBehavior(b, scope) {
    const me = $('behavior-me');
    me.replaceChildren();
    if (b.me) {
      const kv = (k, v) => h('div', { class: 'kv-item' }, h('b', {}, v), h('span', {}, k));
      me.append(pill(b.me.status), kv('flows seen', b.me.totalFlows), kv('suspicious now', ratioText(b.me.recent.suspiciousRatio)),
        kv('your baseline', b.me.baseline.available ? ratioText(b.me.baseline.suspiciousRatio) : 'learning'), kv('longest current run', b.me.recent.suspiciousRun));
    }
    $('behavior-hint').textContent = scope === 'me' ? 'Your own profile' : 'Most severe first, last 24 hours';
    const body = $('behavior-body');
    body.replaceChildren();
    if (!b.entities.length) body.append(h('tr', {}, h('td', { colspan: 13, class: 'empty' }, 'No behaviour recorded yet.')));
    for (const e of b.entities) {
      const who = e.userId ? `user ${e.userId.slice(0, 8)}${e.ip ? ` (${e.ip})` : ''}` : (e.ip || e.key);
      body.append(h('tr', {},
        h('td', {}, who), h('td', {}, pill(e.status)), h('td', {}, e.pattern === 'none' ? '—' : e.pattern),
        h('td', { class: 'num' }, e.recent.flows), h('td', { class: 'num' }, e.recent.normal),
        h('td', { class: 'num' }, e.recent.possibleZeroDay), h('td', { class: 'num' }, e.recent.attack),
        h('td', { class: 'num' }, ratioText(e.recent.suspiciousRatio)),
        h('td', { class: 'num', title: e.baseline.available ? `${e.baseline.flows} earlier flows` : `needs ${b.config.baselineMin} earlier flows` },
          e.baseline.available ? ratioText(e.baseline.suspiciousRatio) : 'learning'),
        h('td', { class: 'num' }, e.recent.suspiciousRun),
        h('td', { title: e.lstm.mode === 'sequence' ? 'LSTM reads this user\'s recent flows as a sequence' : 'LSTM currently scores each flow on its own' },
          e.lstm.mode === 'sequence' ? `sequence (${e.lstm.hostileVotes} hostile)` : 'single-flow'),
        h('td', {}, time(e.lastSeen)), h('td', { class: 'reason' }, e.reason)));
    }
  }

  function toast(text, cls = '') {
    const el = h('div', { class: `toast ${cls}`, role: 'status' }, text);
    document.body.append(el);
    setTimeout(() => el.remove(), 9000);
  }

  function renderMonitoring(m) {
    const chip = $('engine-chip');
    chip.className = `chip ${m.engine.ready ? 'on' : 'off'}`;
    chip.textContent = m.engine.ready ? 'Models: online' : 'Models: offline';
    chip.title = m.engine.error || (m.engine.info ? `CNN, FCNN, LSTM and autoencoder on ${m.engine.info.feature_count} features` : '');
    $('flows-chip').textContent = `Active flows: ${m.activeFlows}`;
    const d = m.drift;
    const dc = $('drift-chip');
    dc.className = `chip ${d.active ? 'warn' : 'on'}`;
    dc.textContent = d.active ? 'Drift suspected' : 'Drift: stable';
    dc.title = d.lastAlertAt ? `Last alert ${time(d.lastAlertAt)}` : 'ADWIN has not detected a change';
    if (state.lastAlerts !== null && d.alerts > state.lastAlerts) toast('Drift alert: the traffic no longer looks like what the models were trained on. See the drift monitor.', 'drift');
    state.lastAlerts = d.alerts;
    $('coverage-note').textContent = m.featureCoverage.unavailable
      ? `${m.featureCoverage.unavailable} of ${m.featureCoverage.total} enabled features cannot be measured from HTTP traffic and are filled with 0 live. Manual tests use exactly the values you enter.`
      : `All ${m.featureCoverage.total} model features are measured live. Manual tests use exactly the values you enter.`;
  }

  /* model bars: P(attack) from each network, then the ensemble and the novelty check */
  function modelBars(models) {
    const bar = (name, p, extra = '') => h('div', { class: `mbar ${extra}` },
      h('span', {}, name),
      h('span', { class: 'track', title: typeof p === 'number' ? `${name}: probability of attack ${p}` : '' },
        h('span', { class: `fill ${p >= 0.5 ? 'hi' : ''}`, style: { width: `${Math.round((p || 0) * 100)}%` } }), h('span', { class: 'mid' })),
      h('b', {}, typeof p === 'number' ? pct(p) : '—'));
    const rows = [bar('CNN', models.cnn.probability), bar('FCNN', models.fcnn.probability), bar('LSTM', models.lstm.probability),
      bar('Ensemble', models.ensemble.probability, 'sum')];
    const nv = models.novelty;
    const ratio = typeof nv.ratio === 'number' ? nv.ratio : null;
    rows.push(h('div', { class: 'nov' }, h('span', {}, 'Autoencoder: how unlike normal'),
      h('span', { class: `ratio ${nv.flag ? 'hi' : ''}` }, ratio === null ? '—' : `${ratio.toFixed(2)}× threshold${nv.flag ? ' (unusual)' : ''}`)));
    return rows;
  }

  function renderLatest(rec) {
    const body = $('models-body');
    if (!rec || rec.models.cnn.probability == null) {
      body.replaceChildren(h('p', { class: 'empty' }, rec ? 'This flow was scored by the earlier XGBoost / Isolation Forest models.' : 'Waiting for the first scored flow.'));
      $('mv-verdict').textContent = ''; $('mv-when').textContent = '';
      return;
    }
    body.replaceChildren(...modelBars(rec.models));
    $('mv-when').textContent = time(rec.timestamp);
    $('mv-verdict').textContent = `${TYPE[rec.status]}: ${rec.reason}`;
  }

  function renderActivity(data) {
    state.totalPages = data.totalPages;
    state.page = data.page;
    const body = $('activity-body');
    body.replaceChildren();
    if (!data.records.length) {
      body.append(h('tr', {}, h('td', { colspan: 9, class: 'empty' }, 'No activity recorded yet. Flows appear here after their connection closes.')));
    }
    for (const r of data.records) {
      body.append(h('tr', { 'data-id': r.eventId, tabindex: 0, onclick: () => showDetails(r.eventId), onkeydown: (e) => { if (e.key === 'Enter') showDetails(r.eventId); } },
        h('td', {}, pill(r.status)),
        h('td', { class: 'num' }, confBar(r)),
        h('td', {}, time(r.timestamp)),
        h('td', {}, val(r.sourceIp)), h('td', {}, val(r.destinationIp)),
        h('td', { class: 'num' }, val(r.sourcePort)), h('td', { class: 'num' }, val(r.destinationPort)),
        h('td', {}, val(r.protocol)), h('td', { class: 'num' }, val(r.length))));
    }
    $('page-info').textContent = `Page ${data.page} of ${data.totalPages} (${data.total} records)`;
    $('prev-btn').disabled = data.page <= 1;
    $('next-btn').disabled = data.page >= data.totalPages;
    if (data.page === 1) renderLatest(data.records[0]);
  }

  /* timeline: stacked bars per bucket, drift alerts as yellow markers */
  function renderTimeline(tl) {
    const svg = $('timeline-chart');
    const W = 640; const Hh = 190; const L = 30; const R = 6; const T = 8; const B = 24;
    const iw = W - L - R; const ih = Hh - T - B;
    const b = tl.buckets;
    const max = Math.max(4, ...b.map((x) => x.normal + x.attack + x.possible_zero_day));
    const bw = iw / b.length;
    const kids = [];
    kids.push(s('line', { class: 'axis', x1: L, x2: W - R, y1: T + ih, y2: T + ih }));
    kids.push(s('text', { x: L - 5, y: T + 9, 'text-anchor': 'end' }, max));
    kids.push(s('text', { x: L - 5, y: T + ih, 'text-anchor': 'end' }, 0));
    b.forEach((x, i) => {
      let y = T + ih;
      const add = (n, cls) => { if (!n) return; const hh = (n / max) * ih; y -= hh; kids.push(s('rect', { class: cls, x: L + i * bw + bw * 0.12, y, width: bw * 0.76, height: hh })); };
      add(x.normal, 'bar-normal'); add(x.possible_zero_day, 'bar-zd'); add(x.attack, 'bar-attack');
      const tot = x.normal + x.attack + x.possible_zero_day;
      if (tot) kids.push(s('rect', { x: L + i * bw, y: T, width: bw, height: ih, fill: 'transparent' }, s('title', {}, `${clock(x.t)}: ${x.normal} normal, ${x.attack} attack, ${x.possible_zero_day} possible zero-day`)));
    });
    const t0 = new Date(b[0].t).getTime(); const span = b.length * tl.bucketSeconds * 1000;
    for (const mark of state.driftMarks) {
      const f = (mark - t0) / span;
      if (f >= 0 && f <= 1) kids.push(s('rect', { class: 'win', x: L + f * iw - 1, y: T, width: 3, height: ih }, s('title', {}, `Drift alert ${time(new Date(mark).toISOString())}`)));
    }
    [0, Math.floor(b.length / 2), b.length - 1].forEach((i, k) => kids.push(s('text', { x: L + i * bw + (k === 2 ? bw : 0), y: Hh - 6, 'text-anchor': k === 0 ? 'start' : k === 2 ? 'end' : 'middle' }, clock(b[i].t))));
    svg.replaceChildren(...kids);
    $('tl-hint').textContent = `Each bar is ${tl.bucketSeconds >= 60 ? `${tl.bucketSeconds / 60} minute${tl.bucketSeconds > 60 ? 's' : ''}` : `${tl.bucketSeconds} seconds`}`;
  }

  const STREAM_NAME = {
    ensemble_probability: 'Attack score of normal-looking flows',
    novelty_ratio: 'How unusual normal-looking flows are',
    novelty_rate: 'Share of flows unlike the training data',
    attack_rate: 'Share of flows that are attacks',
  };
  const streamName = (n) => STREAM_NAME[n] || n.replace(/^feature:/, 'Input: ');

  function renderDrift(d) {
    const sum = d.summary;
    const chip = $('drift-state');
    chip.className = `chip ${sum.active ? 'warn' : 'on'}`;
    chip.textContent = sum.active ? 'Drift suspected' : 'Stable';
    $('drift-summary').textContent = `${sum.alerts} alert${sum.alerts === 1 ? '' : 's'} so far`
      + (sum.lastAlertAt ? `, last ${time(sum.lastAlertAt)}` : '')
      + (d.monitors ? ` · ${d.monitors.benignObservations} normal flows observed` : '');
    const box = $('drift-streams');
    if (!d.monitors) { box.replaceChildren(h('p', { class: 'empty' }, 'The models are offline, so no live monitors are running.')); }
    else {
      const rows = [...d.monitors.streams, ...d.monitors.features.filter((f) => f.detections > 0).slice(0, 3)];
      box.replaceChildren(...rows.map((st) => {
        const share = st.observations ? Math.min(1, st.window / st.observations) : 1;
        return h('div', { class: 'stream-row', title: `${st.name}: window ${st.window} of ${st.observations} observations, mean ${st.mean}` },
          h('span', {}, streamName(st.name)),
          h('span', { class: 'winbar' }, h('i', { style: { '--w': `${Math.round(share * 100)}%` } })),
          h('span', { class: 'n' }, `${st.detections} alert${st.detections === 1 ? '' : 's'}`));
      }));
    }
    state.driftMarks = d.events.filter((e) => e.level === 'alert').map((e) => new Date(e.detectedAt).getTime());
    const list = $('drift-events');
    if (!d.events.length) { list.replaceChildren(h('li', { class: 'notice-lv' }, 'No drift detected yet.')); return; }
    list.replaceChildren(...d.events.slice(0, 12).map((e) => h('li', { class: e.level === 'alert' ? '' : 'notice-lv' },
      h('b', {}, e.level === 'alert' ? 'Alert: ' : 'Notice: '), e.message,
      e.features ? ` (${e.features.map((f) => f.name).join(', ')})` : (e.meanBefore != null ? ` (${streamName(e.stream)}: ${(+e.meanBefore).toFixed(3)} → ${(+e.meanAfter).toFixed(3)})` : ''),
      h('time', {}, time(e.detectedAt)))));
  }

  function renderAttackers(attackers, blocks) {
    const ab = $('attackers-body');
    ab.replaceChildren();
    if (!attackers.length) ab.append(h('tr', {}, h('td', { colspan: 9, class: 'empty' }, 'No attackers recorded.')));
    for (const a of attackers) {
      ab.append(h('tr', { 'data-id': a.latestEventId, tabindex: 0, onclick: () => showDetails(a.latestEventId) },
        h('td', {}, a.identifier), h('td', {}, val(a.username)), h('td', {}, val(a.sourceIp)),
        h('td', {}, pill(a.worstStatus)), h('td', { class: 'num' }, a.events), h('td', { class: 'num' }, a.requestCount),
        h('td', { class: 'num' }, pct(a.maxConfidence)), h('td', {}, time(a.firstSeen)), h('td', {}, time(a.lastSeen))));
    }
    const bb = $('blocks-body');
    bb.replaceChildren();
    if (!blocks.length) bb.append(h('tr', {}, h('td', { colspan: 7, class: 'empty' }, 'No restrictions.')));
    for (const b of blocks) {
      bb.append(h('tr', {},
        h('td', {}, b.state), h('td', {}, val(b.userId ? b.userId.slice(0, 8) : null)), h('td', {}, val(b.ip)),
        h('td', {}, val(b.reason)), h('td', {}, time(b.createdAt)), h('td', {}, time(b.expiresAt)),
        h('td', {}, b.state === 'active' ? h('button', { class: 'btn secondary small', type: 'button', onclick: () => liftBlock(b.id) }, 'Lift') : null)));
    }
  }

  async function liftBlock(id) {
    try { await api(`/api/blocklist/${encodeURIComponent(id)}`, { method: 'DELETE' }); await refresh(); } catch (err) { alert(err.message); }
  }

  async function showDetails(id) {
    try {
      const { event: e } = await api(`/api/events/${encodeURIComponent(id)}`);
      const rows = [
        ['Status', TYPE[e.status]], ['Severity', e.severity], ['Confidence', pct(e.confidence)], ['Reason', e.reason],
        ['Attack type', e.status === 'normal' ? '—' : 'Not classified (the models report attack vs normal only)'],
        ['Votes for attack', e.models.ensemble.votes == null ? '—' : `${e.models.ensemble.votes} of 3`],
        ['Drift warning', e.driftActive ? 'Drift was suspected when this was scored' : 'None'],
        ['User', val(e.userId)], ['Session', val(e.sessionId)], ['Device', val(e.deviceId)], ['Source IP', val(e.sourceIp)],
        ['Destination', `${val(e.destinationIp)}:${val(e.destinationPort)}`],
        ['First seen', time(e.firstSeen)], ['Last seen', time(e.lastSeen)],
        ['Requests', e.requestCount], ['Detections merged', e.detectionCount], ['Bytes', e.length],
        ['Features not measurable', e.missingFeatures],
      ];
      if (e.legacy) rows.push(['Earlier models', `XGBoost ${e.legacy.xgboost.label}, Isolation Forest ${e.legacy.isolationForest.label}`]);
      if (e.flow) {
        rows.push(['Flow', `${e.flow.flowId} (ended: ${e.flow.closeReason})`],
          ['Flow duration', `${(e.flow.durationUs / 1e6).toFixed(3)} s`],
          ['Bytes forward / backward', `${e.flow.bytesForward} / ${e.flow.bytesBackward}`]);
      }
      $('detail-models').replaceChildren(...(e.models.cnn.probability == null ? [] : modelBars(e.models)));
      $('detail-body').replaceChildren(...rows.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, val(v))]));
      $('detail-panel').classList.remove('hidden');
      $('detail-close').focus();
    } catch (err) { alert(err.message); }
  }

  async function refresh() {
    try {
      const q = `scope=${state.scope}`;
      const [dash, act, att, blk, tl, dr] = await Promise.all([
        api(`/api/dashboard?${q}`), api(`/api/activity?${q}&page=${state.page}`),
        api('/api/attackers'), api('/api/blocklist'), api(`/api/timeline?${q}&minutes=60`), api('/api/drift'),
      ]);
      renderStatus(dash.status, dash.stats);
      renderBehavior(dash.behavior, dash.scope);
      renderMonitoring(dash.monitoring);
      renderActivity(act);
      renderAttackers(att.attackers, blk.blocks);
      renderDrift(dr);
      renderTimeline(tl);
      $('blocklist-title').textContent = blk.enforcing ? 'Blocklist (enforced)' : 'Blocklist (recording only: requests are not refused)';
    } catch (err) {
      if (err.message !== 'Login required') $('status-sub').textContent = `Cannot refresh: ${err.message}`;
    }
  }

  /* ------------------------------------------------------- live console */

  const MAX_LINES = 400;
  function addLogLine(e) {
    const body = $('console-body');
    const d = new Date(e.t);
    const stamp = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}.${String(d.getMilliseconds()).padStart(3, '0')}`;
    const ln = h('span', { class: `ln lv-${e.level}`, 'data-cat': e.cat },
      h('span', { class: 't' }, `${stamp} `), h('span', { class: `c c-${e.cat}` }, `[${e.cat}] `), e.msg);
    if (state.logFilter && state.logFilter !== e.cat) ln.classList.add('hidden');
    body.append(ln);
    while (body.childElementCount > MAX_LINES) body.firstElementChild.remove();
  }

  async function pollLogs() {
    if (state.logPaused || document.hidden) return;
    try {
      const data = await api(`/api/logs?since=${state.logSince}&limit=200`);
      if (data.last < state.logSince) { state.logSince = 0; return; } // server restarted
      const body = $('console-body');
      const stick = body.scrollHeight - body.scrollTop - body.clientHeight < 40;
      for (const e of data.entries) addLogLine(e);
      state.logSince = data.last;
      if (stick && data.entries.length) body.scrollTop = body.scrollHeight;
    } catch { /* transient: try again on the next tick */ }
  }

  function initConsole() {
    $('console-pause').addEventListener('click', (e) => {
      state.logPaused = !state.logPaused;
      e.target.textContent = state.logPaused ? 'Resume' : 'Pause';
    });
    $('console-clear').addEventListener('click', () => $('console-body').replaceChildren());
    $('console-filter').addEventListener('change', (e) => {
      state.logFilter = e.target.value;
      for (const ln of $('console-body').children) ln.classList.toggle('hidden', Boolean(state.logFilter) && ln.dataset.cat !== state.logFilter);
    });
    pollLogs();
    setInterval(pollLogs, 2000);
  }

  /* ----------------------------------------------------- manual testing */

  function buildFeatureForm(features) {
    const grid = $('feature-grid');
    grid.replaceChildren(...features.map((f) => h('label', { class: f.availability === 'NOT_AVAILABLE' ? 'na' : '' },
      h('span', {}, f.name),
      h('input', { type: 'number', step: 'any', 'data-feature': f.name, 'aria-label': f.name }))));
  }

  const featureInputs = () => [...document.querySelectorAll('#feature-grid input')];

  function loadJson() {
    $('test-error').textContent = '';
    let obj;
    try { obj = JSON.parse($('json-input').value); } catch { $('test-error').textContent = 'That is not valid JSON.'; return; }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) { $('test-error').textContent = 'JSON must be an object keyed by feature name.'; return; }
    const known = new Set(featureInputs().map((i) => i.dataset.feature));
    const unknown = Object.keys(obj).filter((k) => !known.has(k));
    for (const i of featureInputs()) if (i.dataset.feature in obj) i.value = obj[i.dataset.feature];
    if (unknown.length) $('test-error').textContent = `Ignored ${unknown.length} unknown key(s), for example "${unknown[0]}". "Label" is not an input.`;
  }

  function renderResult(r) {
    const box = $('test-result');
    box.replaceChildren(h('div', { class: `result ${r.status}` },
      h('div', { class: 'big' }, LABEL[r.status]),
      h('div', { class: 'models' }, ...modelBars(r.models)),
      h('dl', { class: 'kv', style: { 'margin-top': '.9rem' } },
        h('dt', {}, 'Severity'), h('dd', {}, r.severity),
        h('dt', {}, 'Confidence'), h('dd', {}, pct(r.confidence)),
        h('dt', {}, 'Reason'), h('dd', {}, r.reason)),
      h('p', { class: 'muted', style: { margin: '.75rem 0 0' } }, 'Not saved. This result is not part of the statistics, history, blocklist or drift monitors.')));
  }

  async function runTest() {
    $('test-error').textContent = '';
    $('test-result').replaceChildren();
    const features = {};
    const empty = [];
    for (const i of featureInputs()) {
      if (i.value.trim() === '') empty.push(i.dataset.feature); else features[i.dataset.feature] = Number(i.value);
    }
    if (empty.length) {
      $('test-error').textContent = `${empty.length} value(s) missing, starting with "${empty[0]}". All ${featureInputs().length} features are required.`;
      return;
    }
    $('run-test').disabled = true;
    try {
      const data = await api('/api/test-detection', { method: 'POST', body: { features } });
      renderResult(data.result);
    } catch (err) {
      $('test-error').textContent = [err.message, ...(err.details || []).slice(0, 5)].join(' — ');
    } finally {
      $('run-test').disabled = false;
    }
  }

  /* ------------------------------------------------------------- init */

  async function initDashboard() {
    const session = await api('/api/session');
    if (!session.authenticated) { location.href = 'login.html'; return; }
    $('user-name').textContent = session.user.username;

    $('scope').addEventListener('change', (e) => { state.scope = e.target.value; state.page = 1; refresh(); });
    $('prev-btn').addEventListener('click', () => { if (state.page > 1) { state.page -= 1; refresh(); } });
    $('next-btn').addEventListener('click', () => { if (state.page < state.totalPages) { state.page += 1; refresh(); } });
    $('detail-close').addEventListener('click', () => $('detail-panel').classList.add('hidden'));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('detail-panel').classList.add('hidden'); });
    $('logout-btn').addEventListener('click', async () => { await api('/api/logout', { method: 'POST' }); location.href = 'index.html'; });
    $('analyze-btn').addEventListener('click', async () => { await api('/api/analyze', { method: 'POST' }); setTimeout(refresh, 800); });
    $('run-test').addEventListener('click', runTest);
    $('json-load').addEventListener('click', loadJson);
    $('clear-test').addEventListener('click', () => { featureInputs().forEach((i) => { i.value = ''; }); $('test-result').replaceChildren(); $('test-error').textContent = ''; });
    initConsole();

    const { features } = await api('/api/features');
    buildFeatureForm(features);
    await refresh();
    state.timer = setInterval(() => { if (!document.hidden) refresh(); }, 5000);
  }

  initTheme();
  const canvas = $('stream-canvas');
  if (canvas) initStream(canvas);
  if (PAGE === 'login') initLogin();
  if (PAGE === 'dashboard') initDashboard().catch((err) => { if (err.message !== 'Login required') console.error(err); });
})();
